package com.greyside;

import net.minecraft.registry.RegistryKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

public final class RiftTravel {
	private RiftTravel() {}

	/** Переносит игрока между Обычным миром и Изнанкой в те же координаты и ставит трещину на той стороне. */
	public static void travel(ServerPlayerEntity player, BlockPos from) {
		ServerWorld src = player.getServerWorld();
		MinecraftServer server = src.getServer();

		RegistryKey<World> destKey;
		if (src.getRegistryKey() == World.OVERWORLD) destKey = ModDimensions.GREYSIDE;
		else if (src.getRegistryKey() == ModDimensions.GREYSIDE) destKey = World.OVERWORLD;
		else return;

		ServerWorld dest = server.getWorld(destKey);
		if (dest == null) return;

		BlockPos spot = findSpot(dest, from);
		dest.setBlockState(spot, ModBlocks.RIFT.getDefaultState());
		player.teleport(dest, spot.getX() + 0.5, spot.getY(), spot.getZ() + 0.5, player.getYaw(), player.getPitch());
		player.resetPortalCooldown();
		dest.playSound(null, spot, SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 1.0f, 0.5f);
	}

	private static BlockPos findSpot(ServerWorld dest, BlockPos from) {
		dest.getChunk(from); // подгружаем чанк
		boolean yOk = from.getY() > dest.getBottomY() && from.getY() < dest.getTopY() - 2;
		if (yOk && dest.getBlockState(from).isAir() && dest.getBlockState(from.up()).isAir()) {
			return from;
		}
		int top = dest.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, from.getX(), from.getZ());
		return new BlockPos(from.getX(), top, from.getZ());
	}
}

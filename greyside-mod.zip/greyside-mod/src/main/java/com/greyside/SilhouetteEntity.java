package com.greyside;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.World;

/**
 * Силуэт: чёрная фигура в форме игрока. Держится на расстоянии, пока ты на неё смотришь.
 * Стоит повернуться спиной, и спустя пару секунд она бросается в атаку. Убить можно.
 */
public class SilhouetteEntity extends HostileEntity {
	private int unwatched = 0;
	private int attackCooldown = 0;

	public SilhouetteEntity(EntityType<? extends SilhouetteEntity> type, World world) {
		super(type, world);
	}

	public static DefaultAttributeContainer.Builder createAttributes() {
		return HostileEntity.createHostileAttributes()
				.add(EntityAttributes.GENERIC_MAX_HEALTH, 24.0)
				.add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.30)
				.add(EntityAttributes.GENERIC_FOLLOW_RANGE, 48.0)
				.add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 6.0);
	}

	@Override
	public void tick() {
		super.tick();
		if (getWorld().isClient) return;
		if (attackCooldown > 0) attackCooldown--;

		PlayerEntity target = getWorld().getClosestPlayer(getX(), getY(), getZ(), 48.0, true);
		if (target == null) {
			getNavigation().stop();
			return;
		}

		double dist = distanceTo(target);
		boolean watched = GreyMobs.isLookedAt(target, this, 0.55);

		if (watched) {
			unwatched = 0;
			if (dist > 16) {
				getNavigation().startMovingTo(target, 0.9);
			} else {
				getNavigation().stop();
				getLookControl().lookAt(target, 30f, 30f);
			}
		} else {
			unwatched++;
			if (unwatched > 60) {
				getNavigation().startMovingTo(target, 1.45); // рывок
			} else if (dist > 16) {
				getNavigation().startMovingTo(target, 0.9);
			} else {
				getNavigation().stop();
			}
		}

		if (dist < 2.0 && unwatched > 20 && attackCooldown == 0) {
			tryAttack(target);
			attackCooldown = 20;
		}
	}
}

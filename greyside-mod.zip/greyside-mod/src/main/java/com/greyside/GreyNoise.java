package com.greyside;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Шина шума: игрок производит звук (шаги, бег, удары), Слушатели в радиусе его слышат.
 * Стоишь на месте или крадёшься (Shift): шума нет.
 */
public final class GreyNoise {
	private static final Map<UUID, Vec3d> LAST_POS = new HashMap<>();
	private static final Map<UUID, Double> WALKED = new HashMap<>();

	public static void init() {
		// сломал блок: громко
		PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, be) -> {
			if (world instanceof ServerWorld sw) emit(sw, Vec3d.ofCenter(pos), 24);
		});
		// ударил по блоку (начал ломать): средне
		AttackBlockCallback.EVENT.register((player, world, hand, pos, dir) -> {
			if (world instanceof ServerWorld sw && !player.isSpectator()) emit(sw, Vec3d.ofCenter(pos), 12);
			return ActionResult.PASS;
		});
		// ударил существо: громко
		AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
			if (world instanceof ServerWorld sw && !player.isSpectator()) emit(sw, player.getPos(), 18);
			return ActionResult.PASS;
		});
		ServerTickEvents.END_SERVER_TICK.register(GreyNoise::tickSteps);
		ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> forget(handler.player.getUuid()));
		ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
			LAST_POS.clear();
			WALKED.clear();
		});
	}

	private static void forget(UUID id) {
		LAST_POS.remove(id);
		WALKED.remove(id);
	}

	/** Шаги: раз в «шаг» пройденного пути, радиус зависит от бега. Крадущийся игрок бесшумен. */
	private static void tickSteps(MinecraftServer server) {
		for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
			UUID id = p.getUuid();
			Vec3d now = p.getPos();
			Vec3d prev = LAST_POS.put(id, now);
			if (prev == null || p.isSpectator() || p.hasVehicle() || p.isFallFlying()
					|| p.isSwimming() || !p.isOnGround()) continue;

			double dx = now.x - prev.x;
			double dz = now.z - prev.z;
			double d = Math.sqrt(dx * dx + dz * dz);
			if (d < 0.01 || d > 2.0) continue; // стоит или телепорт
			if (p.isSneaking()) continue;

			double acc = WALKED.merge(id, d, Double::sum);
			double stride = p.isSprinting() ? 1.6 : 1.9;
			if (acc >= stride) {
				WALKED.put(id, 0.0);
				emit(p.getServerWorld(), now, p.isSprinting() ? 16 : 9);
			}
		}
	}

	/** Сообщает всем Слушателям в радиусе, что в точке pos прозвучал шум. */
	public static void emit(ServerWorld w, Vec3d pos, double radius) {
		Box box = new Box(pos, pos).expand(radius);
		double r2 = radius * radius;
		for (ListenerEntity l : w.getEntitiesByType(ModEntities.LISTENER, box, e -> true)) {
			if (l.squaredDistanceTo(pos) <= r2) l.hear(pos);
		}
	}

	private GreyNoise() {}
}

package com.greyside;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.FluidBlock;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Тёмная копия дома.
 *
 * Дом игрока это его точка возрождения (кровать) в обычном мире или точка, заданная командой /greyside home set.
 * Вокруг неё (область {@link #HALF_XZ} по горизонтали, {@link #DOWN} вниз и {@link #UP} вверх):
 *  1. Первичное копирование: чанк за чанком сравниваем обычный мир с Изнанкой. Всё, чем постройка
 *     отличается от природы (она там и так одинаковая), переносим в тёмной версии (см. {@link DarkPalette}).
 *     Выкопанные подвалы и снесённые стены переносятся тоже.
 *  2. Дальше любое изменение блока в области обычного мира (миксин на World.setBlockState) попадает
 *     в очередь и появляется в Изнанке. Изменения самого игрока в Изнанке не затираются.
 * Содержимое сундуков, печей и текст табличек не копируется.
 */
public final class HomeMirror {
	public static final int HALF_XZ = 40;
	public static final int DOWN = 24;
	public static final int UP = 40;

	/** Обновляем слушателей, без обновления соседей: двери, факелы и вода не ломаются при копировании. */
	private static final int FLAGS = Block.NOTIFY_LISTENERS | Block.FORCE_STATE;
	private static final int REFRESH_INTERVAL = 40;
	private static final int SCAN_INTERVAL = 5;
	private static final int FLUSH_BUDGET = 1500;
	private static final int FLUSH_CHUNKS = 1;

	private static volatile List<BlockPos> homeCache = List.of();
	private static final Map<Long, BlockState> PENDING = new LinkedHashMap<>();
	private static final List<Scan> SCANS = new ArrayList<>();
	private static final Set<UUID> SEEN_HOME = new HashSet<>();

	private static final class Scan {
		final UUID owner;
		final BlockPos home;
		final List<ChunkPos> chunks = new ArrayList<>();
		int idx = 0;

		Scan(UUID owner, BlockPos home) {
			this.owner = owner;
			this.home = home;
			int x0 = (home.getX() - HALF_XZ) >> 4, x1 = (home.getX() + HALF_XZ) >> 4;
			int z0 = (home.getZ() - HALF_XZ) >> 4, z1 = (home.getZ() + HALF_XZ) >> 4;
			for (int x = x0; x <= x1; x++) for (int z = z0; z <= z1; z++) chunks.add(new ChunkPos(x, z));
			ChunkPos c = new ChunkPos(home);
			// сначала чанки ближе к дому
			chunks.sort(Comparator.comparingInt(p -> (p.x - c.x) * (p.x - c.x) + (p.z - c.z) * (p.z - c.z)));
		}
	}

	public static void init() {
		ServerLifecycleEvents.SERVER_STARTED.register(server -> {
			HomeState hs = HomeState.get(server);
			rebuildCache(hs);
			for (Map.Entry<UUID, HomeState.Home> e : hs.all().entrySet()) {
				if (!e.getValue().scanned) ensureScan(e.getKey(), e.getValue().pos);
			}
		});
		ServerLifecycleEvents.SERVER_STOPPING.register(server -> flush(server, Integer.MAX_VALUE, Integer.MAX_VALUE));
		ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
			PENDING.clear();
			SCANS.clear();
			SEEN_HOME.clear();
			homeCache = List.of();
		});
		ServerTickEvents.END_SERVER_TICK.register(HomeMirror::onTick);
	}

	// ---------- вызывается из миксина ----------

	public static void onBlockChanged(ServerWorld w, BlockPos pos, BlockState state) {
		if (w.getRegistryKey() != World.OVERWORLD) return;
		List<BlockPos> homes = homeCache;
		if (homes.isEmpty() || !w.getServer().isOnThread()) return;
		for (BlockPos h : homes) {
			if (inRegion(h, pos)) {
				// текущую воду и лаву не копируем: в Изнанке она растечётся сама
				if (state.getBlock() instanceof FluidBlock && state.get(FluidBlock.LEVEL) != 0) return;
				PENDING.put(pos.asLong(), state);
				return;
			}
		}
	}

	public static boolean inRegion(BlockPos home, BlockPos p) {
		int dy = p.getY() - home.getY();
		return Math.abs(p.getX() - home.getX()) <= HALF_XZ
				&& Math.abs(p.getZ() - home.getZ()) <= HALF_XZ
				&& dy >= -DOWN && dy <= UP;
	}

	// ---------- команды ----------

	public static void sendStatus(ServerPlayerEntity p) {
		HomeState.Home h = HomeState.get(p.getServer()).get(p.getUuid());
		if (h == null) {
			p.sendMessage(Text.translatable("message.greyside.home_none"));
			return;
		}
		p.sendMessage(Text.translatable("message.greyside.home_info",
				h.pos.getX(), h.pos.getY(), h.pos.getZ(),
				Text.translatable(h.scanned ? "message.greyside.home_state_ready" : "message.greyside.home_state_building")));
	}

	public static void setHere(ServerPlayerEntity p) {
		if (p.getWorld().getRegistryKey() != World.OVERWORLD) {
			p.sendMessage(Text.translatable("message.greyside.home_wrong_world"));
			return;
		}
		register(p.getServer(), p.getUuid(), p.getBlockPos(), true);
		p.sendMessage(Text.translatable("message.greyside.home_set"));
	}

	/** Вернуть привязку дома к кровати. */
	public static void useBed(ServerPlayerEntity p) {
		HomeState hs = HomeState.get(p.getServer());
		HomeState.Home h = hs.get(p.getUuid());
		BlockPos bed = bedHome(p);
		if (bed != null) register(p.getServer(), p.getUuid(), bed, false);
		else if (h != null) hs.put(p.getUuid(), new HomeState.Home(h.pos, h.scanned, false));
		p.sendMessage(Text.translatable(bed != null ? "message.greyside.home_bed" : "message.greyside.home_bed_none"));
	}

	public static void rescan(ServerPlayerEntity p) {
		HomeState hs = HomeState.get(p.getServer());
		HomeState.Home h = hs.get(p.getUuid());
		if (h == null) {
			p.sendMessage(Text.translatable("message.greyside.home_none"));
			return;
		}
		hs.put(p.getUuid(), new HomeState.Home(h.pos, false, h.manual));
		ensureScan(p.getUuid(), h.pos);
		p.sendMessage(Text.translatable("message.greyside.home_rescan"));
	}

	// ---------- регистрация домов ----------

	private static BlockPos bedHome(ServerPlayerEntity p) {
		BlockPos sp = p.getSpawnPointPosition();
		if (sp != null && p.getSpawnPointDimension() == World.OVERWORLD) return sp;
		return null;
	}

	private static void register(MinecraftServer server, UUID id, BlockPos pos, boolean manual) {
		HomeState hs = HomeState.get(server);
		HomeState.Home cur = hs.get(id);
		if (cur != null && cur.pos.equals(pos) && cur.manual == manual) {
			if (!cur.scanned) ensureScan(id, pos);
			return;
		}
		hs.put(id, new HomeState.Home(pos, false, manual));
		rebuildCache(hs);
		ensureScan(id, pos);
	}

	private static void rebuildCache(HomeState hs) {
		List<BlockPos> list = new ArrayList<>();
		for (HomeState.Home h : hs.all().values()) list.add(h.pos);
		homeCache = List.copyOf(list);
	}

	private static void ensureScan(UUID owner, BlockPos home) {
		for (Scan s : SCANS) if (s.owner.equals(owner) && s.home.equals(home)) return;
		SCANS.removeIf(s -> s.owner.equals(owner));
		SCANS.add(new Scan(owner, home));
	}

	// ---------- тик ----------

	private static void onTick(MinecraftServer server) {
		int t = server.getTicks();
		if (t % REFRESH_INTERVAL == 0) refreshPlayers(server);
		if (!SCANS.isEmpty() && t % SCAN_INTERVAL == 0) stepScan(server);
		if (!PENDING.isEmpty()) flush(server, FLUSH_BUDGET, FLUSH_CHUNKS);
	}

	private static void refreshPlayers(MinecraftServer server) {
		HomeState hs = HomeState.get(server);
		for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
			World w = p.getWorld();
			if (w.getRegistryKey() == World.OVERWORLD) {
				SEEN_HOME.remove(p.getUuid());
				HomeState.Home cur = hs.get(p.getUuid());
				if (cur != null && cur.manual) {
					if (!cur.scanned) ensureScan(p.getUuid(), cur.pos);
					continue;
				}
				BlockPos bed = bedHome(p);
				if (bed != null) register(server, p.getUuid(), bed, false);
			} else if (w.getRegistryKey() == ModDimensions.GREYSIDE) {
				HomeState.Home h = hs.get(p.getUuid());
				boolean near = h != null && h.scanned && inRegion(h.pos, p.getBlockPos());
				if (near && SEEN_HOME.add(p.getUuid())) {
					p.sendMessage(Text.translatable("message.greyside.home_here"), true);
				} else if (!near) {
					SEEN_HOME.remove(p.getUuid());
				}
			}
		}
	}

	private static void stepScan(MinecraftServer server) {
		ServerWorld src = server.getWorld(World.OVERWORLD);
		ServerWorld dest = server.getWorld(ModDimensions.GREYSIDE);
		if (src == null || dest == null) return;

		Scan s = SCANS.get(0);
		if (s.idx < s.chunks.size()) scanChunk(src, dest, s.home, s.chunks.get(s.idx++));
		if (s.idx >= s.chunks.size()) {
			SCANS.remove(0);
			HomeState.get(server).markScanned(s.owner, s.home);
		}
	}

	private static void scanChunk(ServerWorld src, ServerWorld dest, BlockPos home, ChunkPos cp) {
		WorldChunk sc = src.getChunk(cp.x, cp.z);
		WorldChunk dc = dest.getChunk(cp.x, cp.z);

		int x0 = Math.max(cp.getStartX(), home.getX() - HALF_XZ), x1 = Math.min(cp.getEndX(), home.getX() + HALF_XZ);
		int z0 = Math.max(cp.getStartZ(), home.getZ() - HALF_XZ), z1 = Math.min(cp.getEndZ(), home.getZ() + HALF_XZ);
		int y0 = Math.max(Math.max(src.getBottomY(), dest.getBottomY()), home.getY() - DOWN);
		int y1 = Math.min(Math.min(src.getTopY(), dest.getTopY()) - 1, home.getY() + UP);

		BlockPos.Mutable m = new BlockPos.Mutable();
		for (int x = x0; x <= x1; x++) {
			for (int z = z0; z <= z1; z++) {
				for (int y = y0; y <= y1; y++) {
					m.set(x, y, z);
					BlockState s = sc.getBlockState(m);
					BlockState g = dc.getBlockState(m);
					if (s == g) continue; // природа совпадает, копировать нечего
					if (isFlowingFluid(s)) continue;
					BlockState d = DarkPalette.darken(s);
					if (d == g) continue;
					dest.setBlockState(m.toImmutable(), d, FLAGS);
				}
			}
		}
	}

	private static boolean isFlowingFluid(BlockState s) {
		return s.getBlock() instanceof FluidBlock && s.get(FluidBlock.LEVEL) != 0;
	}

	/** Переносит накопленные изменения в Изнанку. Чанки Изнанки, которых нет в памяти, подгружаем не больше chunkBudget за раз. */
	private static void flush(MinecraftServer server, int budget, int chunkBudget) {
		ServerWorld dest = server.getWorld(ModDimensions.GREYSIDE);
		if (dest == null) return;
		int visited = 0;
		int visitLimit = budget == Integer.MAX_VALUE ? Integer.MAX_VALUE : budget * 3;

		Iterator<Map.Entry<Long, BlockState>> it = PENDING.entrySet().iterator();
		while (it.hasNext() && budget > 0 && visited++ < visitLimit) {
			Map.Entry<Long, BlockState> e = it.next();
			BlockPos pos = BlockPos.fromLong(e.getKey());
			if (!dest.isChunkLoaded(pos)) {
				if (chunkBudget <= 0) continue; // оставляем в очереди до следующего тика
				chunkBudget--;
			}
			dest.getChunk(pos); // подгружаем или генерируем чанк
			BlockState d = DarkPalette.darken(e.getValue());
			if (dest.getBlockState(pos) != d) dest.setBlockState(pos, d, FLAGS);
			it.remove();
			budget--;
		}
	}

	private HomeMirror() {}
}

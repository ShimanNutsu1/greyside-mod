package com.greyside;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.StringIdentifiable;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Difficulty;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;

/**
 * Постамент масок на арене Иона. У каждого своя маска (Безмолвия, Наблюдателя или Пустоты).
 * ПКМ с нужной маской: маска ложится в гнездо. Когда заняты все три, за спиной игрока появляется Ион.
 * Постаменты не ломаются в выживании.
 */
public class MaskPedestalBlock extends Block {
	public enum Slot implements StringIdentifiable {
		SILENCE("silence", MaskItem.Kind.SILENCE),
		WATCHER("watcher", MaskItem.Kind.WATCHER),
		VOID("void", MaskItem.Kind.VOID);

		private final String id;
		public final MaskItem.Kind mask;

		Slot(String id, MaskItem.Kind mask) {
			this.id = id;
			this.mask = mask;
		}

		@Override
		public String asString() {
			return id;
		}
	}

	public static final EnumProperty<Slot> KIND = EnumProperty.of("kind", Slot.class);
	public static final BooleanProperty FILLED = BooleanProperty.of("filled");

	public MaskPedestalBlock(Settings settings) {
		super(settings);
		setDefaultState(getStateManager().getDefaultState().with(KIND, Slot.SILENCE).with(FILLED, false));
	}

	@Override
	protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
		builder.add(KIND, FILLED);
	}

	public static Item maskFor(Slot slot) {
		return switch (slot) {
			case SILENCE -> ModItems.MASK_SILENCE;
			case WATCHER -> ModItems.MASK_WATCHER;
			case VOID -> ModItems.MASK_VOID;
		};
	}

	@Override
	public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
		if (world.isClient) return ActionResult.SUCCESS;
		if (state.get(FILLED)) {
			player.sendMessage(Text.translatable("message.greyside.pedestal_full"), true);
			return ActionResult.CONSUME;
		}
		ItemStack held = player.getStackInHand(hand);
		MaskItem.Kind need = state.get(KIND).mask;
		if (!(held.getItem() instanceof MaskItem m) || m.kind() != need) {
			player.sendMessage(Text.translatable("message.greyside.pedestal_wrong"), true);
			return ActionResult.CONSUME;
		}
		if (world.getDifficulty() == Difficulty.PEACEFUL) {
			player.sendMessage(Text.translatable("message.greyside.ion_peaceful"), true);
			return ActionResult.CONSUME;
		}
		if (!player.isCreative()) held.decrement(1);
		world.setBlockState(pos, state.with(FILLED, true), Block.NOTIFY_ALL);
		world.playSound(null, pos, SoundEvents.BLOCK_RESPAWN_ANCHOR_CHARGE, SoundCategory.BLOCKS, 1.0f, 0.6f);
		if (world instanceof ServerWorld sw) trySummon(sw, pos, player);
		return ActionResult.CONSUME;
	}

	/** Если рядом заняты все три разных постамента и Иона ещё нет, он появляется за спиной игрока. */
	private static void trySummon(ServerWorld w, BlockPos around, PlayerEntity player) {
		EnumSet<Slot> found = EnumSet.noneOf(Slot.class);
		List<BlockPos> list = new ArrayList<>();
		for (BlockPos p : BlockPos.iterate(around.add(-18, -3, -18), around.add(18, 3, 18))) {
			BlockState s = w.getBlockState(p);
			if (s.isOf(ModBlocks.MASK_PEDESTAL) && s.get(FILLED) && found.add(s.get(KIND))) {
				list.add(p.toImmutable());
			}
		}
		if (found.size() < Slot.values().length) return;
		if (!w.getEntitiesByType(ModEntities.ION, new Box(around).expand(90), e -> true).isEmpty()) return;

		Vec3d look = player.getRotationVec(1.0f);
		Vec3d flat = new Vec3d(look.x, 0.0, look.z);
		if (flat.lengthSquared() < 1.0e-4) flat = new Vec3d(0.0, 0.0, 1.0);
		flat = flat.normalize();
		Vec3d at = player.getPos().subtract(flat.multiply(4.0));

		IonEntity ion = ModEntities.ION.create(w);
		if (ion == null) return;
		ion.refreshPositionAndAngles(at.x, at.y, at.z, player.getYaw(), 0.0f);
		ion.setPedestals(list);
		ion.initialize(w, w.getLocalDifficulty(BlockPos.ofFloored(at)), SpawnReason.EVENT, null, null);
		w.spawnEntity(ion);
		ion.setTarget(player);

		player.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 60, 0, false, false, false));
		w.playSound(null, at.x, at.y, at.z, SoundEvents.ENTITY_WARDEN_EMERGE, SoundCategory.HOSTILE, 3.0f, 0.6f);
	}
}

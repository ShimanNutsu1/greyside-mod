package com.greyside;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.Difficulty;
import net.minecraft.world.World;

/**
 * Лицо в окне. Безликий, который просто стоит снаружи и смотрит. Не атакует, не двигается,
 * не трогается ударами и не мешает курсору. Появляется в обычном мире при высокой Серости
 * (см. {@code GreyEvents.spawnPeeker}).
 *
 * Пропадает, стоит отвернуться: через 3 тика после того, как его перестали видеть
 * (видят и через стекло). Если так и не заметили, исчезает сам через 30 секунд.
 * Если подойти ближе 5 блоков, тоже пропадает.
 */
public class PeekerEntity extends MobEntity {
	private static final int UNSEEN_LIFE = 600;
	private static final int LOST_TO_VANISH = 3;
	private static final int MAX_STARE = 160; // дольше 8 секунд не стоит: «моргнул» и нет

	private int seenTicks = 0;
	private int lostTicks = 0;

	public PeekerEntity(EntityType<? extends PeekerEntity> type, World world) {
		super(type, world);
		this.setPersistent();
		this.setAiDisabled(true);
		this.setInvulnerable(true);
	}

	@Override
	public boolean damage(DamageSource source, float amount) {
		if (source.isIn(DamageTypeTags.BYPASSES_INVULNERABILITY)) return super.damage(source, amount);
		return false;
	}

	@Override
	public boolean isPushable() {
		return false;
	}

	/** Призрак: по нему нельзя прицелиться, удар проходит насквозь. */
	@Override
	public boolean canHit() {
		return false;
	}

	@Override
	public boolean canImmediatelyDespawn(double distanceSquared) {
		return false;
	}

	@Override
	public void tick() {
		super.tick();
		if (getWorld().isClient || !(getWorld() instanceof ServerWorld sw)) return;

		PlayerEntity p = sw.getClosestPlayer(this, 48.0);
		if (p == null || sw.getDifficulty() == Difficulty.PEACEFUL) {
			discard();
			return;
		}

		// всегда лицом к игроку
		double dx = p.getX() - getX();
		double dz = p.getZ() - getZ();
		float yaw = (float) (MathHelper.atan2(dz, dx) * 57.29577951308232) - 90.0f;
		setYaw(yaw);
		setBodyYaw(yaw);
		setHeadYaw(yaw);
		setVelocity(0, getVelocity().y, 0);

		boolean watched = GreyMobs.isSeenThrough(p, this, 0.80);
		if (watched) {
			if (seenTicks == 0) {
				sw.playSound(null, p.getBlockPos(), ModSounds.WHISPER, SoundCategory.AMBIENT, 0.6f, 0.6f);
			}
			seenTicks++;
			lostTicks = 0;
			if (seenTicks > MAX_STARE || distanceTo(p) < 5.0f) vanish(sw);
		} else if (seenTicks > 0) {
			if (++lostTicks >= LOST_TO_VANISH) vanish(sw);
		} else if (age > UNSEEN_LIFE) {
			discard();
		}
	}

	private void vanish(ServerWorld sw) {
		sw.spawnParticles(ParticleTypes.LARGE_SMOKE, getX(), getY() + 1.5, getZ(), 20, 0.3, 0.8, 0.3, 0.01);
		discard();
	}
}

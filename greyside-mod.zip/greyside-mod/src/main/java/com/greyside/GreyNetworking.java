package com.greyside;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

public final class GreyNetworking {
	public static final Identifier LEVEL_PACKET = GreysideMod.id("grey_level");

	public static void send(ServerPlayerEntity player, int level) {
		PacketByteBuf buf = PacketByteBufs.create();
		buf.writeInt(level);
		ServerPlayNetworking.send(player, LEVEL_PACKET, buf);
	}

	private GreyNetworking() {}
}

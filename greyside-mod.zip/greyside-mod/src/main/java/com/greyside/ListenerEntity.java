package com.greyside;

import net.minecraft.block.BlockState;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Слушатель: слепой. Не видит, только слышит.
 * Пока тихо, стоит неподвижно. Услышал шаги, бег, удар по блоку или по мобу, бежит к источнику звука.
 * Бьёт, только если рядом с ним только что был шум. Замри или иди крадучись (Shift), и он потеряет тебя.
 */
public class ListenerEntity extends HostileEntity {
	/** Сколько тиков он помнит последний звук и бежит к нему (6 секунд). */
	private static final int MEMORY = 120;
	/** Звук считается «свежим» первые 1.5 секунды: только тогда он бьёт. */
	private static final int FRESH = 30;

	private Vec3d noisePos;
	private int noiseTicks = 0;
	private int attackCooldown = 0;
	private int alertCooldown = 0;

	public ListenerEntity(EntityType<? extends ListenerEntity> type, World world) {
		super(type, world);
	}

	public static DefaultAttributeContainer.Builder createAttributes() {
		return HostileEntity.createHostileAttributes()
				.add(EntityAttributes.GENERIC_MAX_HEALTH, 30.0)
				.add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.30)
				.add(EntityAttributes.GENERIC_FOLLOW_RANGE, 32.0)
				.add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 7.0);
	}

	@Override
	protected void initGoals() {
		this.goalSelector.add(0, new SwimGoal(this));
	}

	/** Вызывается шиной шума (GreyNoise), когда рядом что-то прозвучало. */
	public void hear(Vec3d pos) {
		if (noiseTicks <= 0 && alertCooldown <= 0) {
			getWorld().playSound(null, getBlockPos(), ModSounds.LISTENER_ALERT, SoundCategory.HOSTILE,
					1.0f, 0.9f + random.nextFloat() * 0.2f);
			alertCooldown = 60;
		}
		noisePos = pos;
		noiseTicks = MEMORY;
	}

	@Override
	public void tick() {
		super.tick();
		if (getWorld().isClient) return;
		if (attackCooldown > 0) attackCooldown--;
		if (alertCooldown > 0) alertCooldown--;

		if (noiseTicks <= 0) {
			// тихо: замирает на месте
			getNavigation().stop();
			return;
		}
		noiseTicks--;

		if (noisePos != null) {
			getLookControl().lookAt(noisePos.x, noisePos.y, noisePos.z);
			if (squaredDistanceTo(noisePos) > 2.25) {
				if (age % 10 == 0 || getNavigation().isIdle()) {
					getNavigation().startMovingTo(noisePos.x, noisePos.y, noisePos.z, 1.5);
				}
			} else {
				getNavigation().stop();
			}
		}

		// бьёт только на свежий звук: застыл рядом, и он тебя не заметит
		if (noiseTicks > MEMORY - FRESH && attackCooldown == 0) {
			PlayerEntity victim = getWorld().getClosestPlayer(getX(), getY(), getZ(), 1.8, true);
			if (victim != null && !victim.isSpectator()) {
				tryAttack(victim);
				attackCooldown = 20;
			}
		}
	}

	@Override
	protected SoundEvent getAmbientSound() {
		return ModSounds.LISTENER_IDLE;
	}

	@Override
	protected SoundEvent getHurtSound(DamageSource source) {
		return ModSounds.LISTENER_HURT;
	}

	@Override
	protected SoundEvent getDeathSound() {
		return ModSounds.LISTENER_DEATH;
	}

	/** Ступает бесшумно: слышно только дыхание. */
	@Override
	protected void playStepSound(BlockPos pos, BlockState state) {}
}

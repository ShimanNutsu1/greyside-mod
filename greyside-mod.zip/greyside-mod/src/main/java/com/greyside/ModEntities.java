package com.greyside;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.mob.AbstractSkeletonEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public final class ModEntities {
	public static final EntityType<ShadowEntity> SHADOW = Registry.register(Registries.ENTITY_TYPE,
			GreysideMod.id("shadow"),
			FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, ShadowEntity::new)
					.dimensions(EntityDimensions.fixed(0.6f, 1.95f))
					.trackRangeBlocks(8)
					.build());

	public static final EntityType<FacelessEntity> FACELESS = Registry.register(Registries.ENTITY_TYPE,
			GreysideMod.id("faceless"),
			FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, FacelessEntity::new)
					.dimensions(EntityDimensions.fixed(0.6f, 2.9f))
					.trackRangeBlocks(12)
					.build());

	public static final EntityType<SilhouetteEntity> SILHOUETTE = Registry.register(Registries.ENTITY_TYPE,
			GreysideMod.id("silhouette"),
			FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, SilhouetteEntity::new)
					.dimensions(EntityDimensions.fixed(0.6f, 1.8f))
					.trackRangeBlocks(10)
					.build());

	public static final EntityType<GreyPhantomEntity> GREY_PHANTOM = Registry.register(Registries.ENTITY_TYPE,
			GreysideMod.id("grey_phantom"),
			FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, GreyPhantomEntity::new)
					.dimensions(EntityDimensions.fixed(0.9f, 0.5f))
					.fireImmune()
					.trackRangeBlocks(8)
					.build());

	public static final EntityType<ShadeArcherEntity> SHADE_ARCHER = Registry.register(Registries.ENTITY_TYPE,
			GreysideMod.id("shade_archer"),
			FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, ShadeArcherEntity::new)
					.dimensions(EntityDimensions.fixed(0.6f, 1.99f))
					.fireImmune()
					.trackRangeBlocks(8)
					.build());

	public static final EntityType<ListenerEntity> LISTENER = Registry.register(Registries.ENTITY_TYPE,
			GreysideMod.id("listener"),
			FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, ListenerEntity::new)
					.dimensions(EntityDimensions.fixed(0.6f, 1.95f))
					.trackRangeBlocks(10)
					.build());

	public static final EntityType<PeekerEntity> PEEKER = Registry.register(Registries.ENTITY_TYPE,
			GreysideMod.id("peeker"),
			FabricEntityTypeBuilder.create(SpawnGroup.MISC, PeekerEntity::new)
					.dimensions(EntityDimensions.fixed(0.6f, 2.9f))
					.trackRangeBlocks(16)
					.build());

	public static void init() {
		FabricDefaultAttributeRegistry.register(SHADOW, ShadowEntity.createShadowAttributes());
		FabricDefaultAttributeRegistry.register(FACELESS, FacelessEntity.createAttributes());
		FabricDefaultAttributeRegistry.register(SILHOUETTE, SilhouetteEntity.createAttributes());
		FabricDefaultAttributeRegistry.register(GREY_PHANTOM, HostileEntity.createHostileAttributes());
		FabricDefaultAttributeRegistry.register(SHADE_ARCHER, AbstractSkeletonEntity.createAbstractSkeletonAttributes());
		FabricDefaultAttributeRegistry.register(LISTENER, ListenerEntity.createAttributes());
		FabricDefaultAttributeRegistry.register(PEEKER, MobEntity.createMobAttributes());
	}

	private ModEntities() {}
}

package com.greyside;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.IntProperty;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

/**
 * Трещина между мирами. Живёт 5 минут. Последние 30 секунд дрожит: частицы и звук нарастают,
 * потом она схлопывается. Свойство age: 0 = стабильна, 1..30 = идут секунды предупреждения.
 */
public class RiftBlock extends Block {
	public static final int LIFETIME_TICKS = 6000;
	public static final int WARNING_SECONDS = 30;
	public static final IntProperty AGE = IntProperty.of("age", 0, WARNING_SECONDS);

	public RiftBlock(Settings settings) {
		super(settings);
		setDefaultState(getStateManager().getDefaultState().with(AGE, 0));
	}

	@Override
	protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
		builder.add(AGE);
	}

	@Override
	public void onBlockAdded(BlockState state, World world, BlockPos pos, BlockState oldState, boolean notify) {
		// смена свойства age тоже вызывает onBlockAdded: таймер ставим только для новой трещины
		if (world.isClient || oldState.isOf(this)) return;
		world.scheduleBlockTick(pos, this, LIFETIME_TICKS - WARNING_SECONDS * 20);
	}

	@Override
	public void scheduledTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
		int age = state.get(AGE);
		if (age >= WARNING_SECONDS) {
			collapse(world, pos);
			return;
		}
		int next = age + 1;
		world.setBlockState(pos, state.with(AGE, next), Block.NOTIFY_LISTENERS);
		if (next == 1) announce(world, pos);
		warn(world, pos, next);
		world.scheduleBlockTick(pos, this, 20);
	}

	private static void announce(ServerWorld world, BlockPos pos) {
		for (ServerPlayerEntity p : world.getPlayers(pl -> pl.squaredDistanceTo(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) < 24 * 24)) {
			p.sendMessage(Text.translatable("message.greyside.rift_closing"), true);
		}
	}

	private static void warn(ServerWorld world, BlockPos pos, int age) {
		double x = pos.getX() + 0.5, y = pos.getY() + 0.5, z = pos.getZ() + 0.5;
		world.spawnParticles(ParticleTypes.REVERSE_PORTAL, x, y, z, 3 + age, 0.35, 0.6, 0.35, 0.04);
		if (age > 20) {
			world.spawnParticles(ParticleTypes.SMOKE, x, y, z, age - 18, 0.3, 0.5, 0.3, 0.02);
		}
		// сначала редкие звуки (каждая 3-я секунда), в последние 10 секунд каждую секунду, тон растёт
		if (age > 20 || age % 3 == 1) {
			world.playSound(null, pos, ModSounds.RIFT_WARNING, SoundCategory.BLOCKS, 1.0f, 0.7f + age * 0.02f);
		}
	}

	private static void collapse(ServerWorld world, BlockPos pos) {
		double x = pos.getX() + 0.5, y = pos.getY() + 0.5, z = pos.getZ() + 0.5;
		world.spawnParticles(ParticleTypes.LARGE_SMOKE, x, y, z, 20, 0.3, 0.5, 0.3, 0.03);
		world.spawnParticles(ParticleTypes.REVERSE_PORTAL, x, y, z, 40, 0.4, 0.6, 0.4, 0.2);
		world.playSound(null, pos, ModSounds.RIFT_COLLAPSE, SoundCategory.BLOCKS, 1.2f, 1.0f);
		world.removeBlock(pos, false);
	}

	@Override
	public void onEntityCollision(BlockState state, World world, BlockPos pos, Entity entity) {
		if (world.isClient || !(entity instanceof ServerPlayerEntity player)) return;
		// как у портала в Незер: пока стоишь внутри, кулдаун продлевается, чтобы не прыгать туда-сюда
		if (player.hasPortalCooldown()) {
			player.resetPortalCooldown();
			return;
		}
		RiftTravel.travel(player, pos);
	}
}

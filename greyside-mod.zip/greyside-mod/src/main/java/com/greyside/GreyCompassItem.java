package com.greyside;

import com.mojang.datafixers.util.Pair;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.entry.RegistryEntryList;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.Structure;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

/**
 * Серый компас. Работает только в Изнанке.
 * ПКМ: найти ближайшую структуру Изнанки выбранного вида (радиус 48 чанков).
 * Shift+ПКМ: сменить вид цели (всё / деревня / башня / колодец / поляна / логово).
 * Пока компас в руке, в экшн-баре стрелка относительно взгляда и расстояние.
 */
public class GreyCompassItem extends Item {
	private static final String[] MODES = {"any", "village", "tower", "pit", "grove", "lair"};
	private static final String[] ARROWS = {"↑", "↗", "→", "↘", "↓", "↙", "←", "↖"};
	private static final int SEARCH_RADIUS_CHUNKS = 48;
	private static final int COOLDOWN_TICKS = 60;

	public GreyCompassItem(Settings settings) {
		super(settings);
	}

	@Override
	public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
		ItemStack stack = user.getStackInHand(hand);
		if (!(world instanceof ServerWorld sw) || !(user instanceof ServerPlayerEntity sp)) {
			return TypedActionResult.success(stack, world.isClient());
		}
		NbtCompound nbt = stack.getOrCreateNbt();

		// смена цели
		if (user.isSneaking()) {
			int m = (nbt.getInt("mode") + 1) % MODES.length;
			nbt.putInt("mode", m);
			nbt.remove("has");
			sp.sendMessage(Text.translatable("message.greyside.compass_mode",
					Text.translatable("compass.greyside.kind." + MODES[m])), true);
			return TypedActionResult.success(stack, false);
		}

		if (sw.getRegistryKey() != ModDimensions.GREYSIDE) {
			sp.sendMessage(Text.translatable("message.greyside.compass_silent"), true);
			return TypedActionResult.success(stack, false);
		}
		if (sp.getItemCooldownManager().isCoolingDown(this)) return TypedActionResult.fail(stack);
		sp.getItemCooldownManager().set(this, COOLDOWN_TICKS);

		Registry<Structure> reg = sw.getRegistryManager().get(RegistryKeys.STRUCTURE);
		List<RegistryEntry<Structure>> targets = new ArrayList<>();
		int mode = nbt.getInt("mode");
		for (int i = 1; i < MODES.length; i++) {
			if (mode != 0 && mode != i) continue;
			reg.getEntry(RegistryKey.of(RegistryKeys.STRUCTURE, GreysideMod.id("grey_" + MODES[i])))
					.ifPresent(targets::add);
		}

		Pair<BlockPos, RegistryEntry<Structure>> found = targets.isEmpty() ? null
				: sw.getChunkManager().getChunkGenerator()
						.locateStructure(sw, RegistryEntryList.of(targets), sp.getBlockPos(), SEARCH_RADIUS_CHUNKS, false);

		if (found == null) {
			nbt.remove("has");
			sp.sendMessage(Text.translatable("message.greyside.compass_none"), true);
			return TypedActionResult.success(stack, false);
		}

		String kind = found.getSecond().getKey()
				.map(k -> k.getValue().getPath().replace("grey_", "")).orElse("any");
		nbt.putInt("tx", found.getFirst().getX());
		nbt.putInt("tz", found.getFirst().getZ());
		nbt.putString("kind", kind);
		nbt.putBoolean("has", true);
		sp.sendMessage(Text.translatable("message.greyside.compass_found",
				Text.translatable("compass.greyside.kind." + kind)), true);
		return TypedActionResult.success(stack, false);
	}

	@Override
	public void appendTooltip(ItemStack stack, @Nullable World world, List<Text> tooltip, TooltipContext context) {
		NbtCompound nbt = stack.getNbt();
		int mode = nbt == null ? 0 : nbt.getInt("mode");
		tooltip.add(Text.translatable("item.greyside.grey_compass.tooltip.mode",
				Text.translatable("compass.greyside.kind." + MODES[Math.floorMod(mode, MODES.length)]))
				.formatted(Formatting.GRAY));
		tooltip.add(Text.translatable("item.greyside.grey_compass.tooltip.use").formatted(Formatting.DARK_GRAY));
	}

	/** Стрелка в экшн-баре, пока компас в руке и цель найдена. */
	public static void initTicker() {
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			if (server.getTicks() % 5 != 0) return;
			for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
				if (p.getWorld().getRegistryKey() != ModDimensions.GREYSIDE) continue;
				ItemStack s = p.getMainHandStack();
				if (!(s.getItem() instanceof GreyCompassItem)) s = p.getOffHandStack();
				if (!(s.getItem() instanceof GreyCompassItem)) continue;
				NbtCompound n = s.getNbt();
				if (n == null || !n.getBoolean("has")) continue;

				double dx = n.getInt("tx") + 0.5 - p.getX();
				double dz = n.getInt("tz") + 0.5 - p.getZ();
				double dist = Math.sqrt(dx * dx + dz * dz);
				if (dist < 12) {
					p.sendMessage(Text.translatable("message.greyside.compass_here"), true);
					continue;
				}
				float yawTo = (float) (MathHelper.atan2(dz, dx) * 57.29577951308232) - 90.0f;
				float rel = MathHelper.wrapDegrees(yawTo - p.getYaw());
				int idx = Math.floorMod(Math.round(rel / 45.0f), 8);
				p.sendMessage(Text.translatable("message.greyside.compass_pointer", ARROWS[idx],
						Text.translatable("compass.greyside.kind." + n.getString("kind")), (int) dist), true);
			}
		});
	}
}

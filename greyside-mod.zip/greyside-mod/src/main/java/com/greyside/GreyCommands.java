package com.greyside;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntryList;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.Heightmap;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

/** Отладочные команды (нужен оп-уровень 2). */
public final class GreyCommands {
	public static void init() {
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
				dispatcher.register(CommandManager.literal("greyside")
						.requires(src -> src.hasPermissionLevel(2))
						// /greyside travel : туда/обратно без мотыги
						.then(CommandManager.literal("travel").executes(ctx -> {
							ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
							RiftTravel.travel(p, p.getBlockPos());
							return 1;
						}))
						// /greyside peeker : показать себе «Лицо в окне» (ищет подходящее место рядом)
						.then(CommandManager.literal("peeker").executes(ctx -> {
							ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
							boolean ok = GreyEvents.spawnPeeker(p, 5, true);
							ctx.getSource().sendFeedback(() -> Text.literal(ok ? "Peeker spawned" : "No suitable spot found"), false);
							return ok ? 1 : 0;
						}))
						// /greyside faceless : позвать бродячего Безликого
						.then(CommandManager.literal("faceless").executes(ctx -> {
							GreyEvents.spawnFacelessNear(ctx.getSource().getPlayerOrThrow());
							return 1;
						}))
						// /greyside arena : телепорт к ближайшей Арене Иона в Изнанке (поиск до 100 чанков)
						.then(CommandManager.literal("arena").executes(ctx -> {
							ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
							ServerWorld grey = ctx.getSource().getServer().getWorld(ModDimensions.GREYSIDE);
							if (grey == null) return 0;
							var entry = grey.getRegistryManager().get(RegistryKeys.STRUCTURE)
									.getEntry(RegistryKey.of(RegistryKeys.STRUCTURE, GreysideMod.id("grey_arena")));
							if (entry.isEmpty()) return 0;
							var found = grey.getChunkManager().getChunkGenerator()
									.locateStructure(grey, RegistryEntryList.of(entry.get()), p.getBlockPos(), 100, false);
							if (found == null) {
								ctx.getSource().sendFeedback(() -> Text.translatable("message.greyside.arena_none"), false);
								return 0;
							}
							int x = found.getFirst().getX();
							int z = found.getFirst().getZ();
							int y = grey.getTopY(Heightmap.Type.MOTION_BLOCKING, x, z);
							p.teleport(grey, x + 0.5, y, z + 0.5, p.getYaw(), p.getPitch());
							return 1;
						}))
						// /greyside level <0-5> : выставить уровень Серости
						.then(CommandManager.literal("level")
								.then(CommandManager.argument("n", IntegerArgumentType.integer(0, 5)).executes(ctx -> {
									int n = IntegerArgumentType.getInteger(ctx, "n");
									GreyState st = GreyState.get(ctx.getSource().getServer());
									st.set(n == 0 ? 0 : GreyState.THRESHOLDS[n - 1]);
									ctx.getSource().sendFeedback(() -> Text.literal("Grey level = " + n), true);
									return 1;
								})))));
	}

	private GreyCommands() {}
}

package com.greyside;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

/** Отладочные команды (нужен оп-уровень 2). */
public final class GreyCommands {
	public static void init() {
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
				dispatcher.register(CommandManager.literal("greyside")
						.requires(src -> src.hasPermissionLevel(2))
						// /greyside travel : туда/обратно без мотыги
						.then(CommandManager.literal("travel").executes(ctx -> {
							ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
							RiftTravel.travel(p, p.getBlockPos());
							return 1;
						}))
						// /greyside peeker : показать себе «Лицо в окне» (ищет подходящее место рядом)
						.then(CommandManager.literal("peeker").executes(ctx -> {
							ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
							boolean ok = GreyEvents.spawnPeeker(p, 5, true);
							ctx.getSource().sendFeedback(() -> Text.literal(ok ? "Peeker spawned" : "No suitable spot found"), false);
							return ok ? 1 : 0;
						}))
						// /greyside faceless : позвать бродячего Безликого
						.then(CommandManager.literal("faceless").executes(ctx -> {
							GreyEvents.spawnFacelessNear(ctx.getSource().getPlayerOrThrow());
							return 1;
						}))
						// /greyside level <0-5> : выставить уровень Серости
						.then(CommandManager.literal("level")
								.then(CommandManager.argument("n", IntegerArgumentType.integer(0, 5)).executes(ctx -> {
									int n = IntegerArgumentType.getInteger(ctx, "n");
									GreyState st = GreyState.get(ctx.getSource().getServer());
									st.set(n == 0 ? 0 : GreyState.THRESHOLDS[n - 1]);
									ctx.getSource().sendFeedback(() -> Text.literal("Grey level = " + n), true);
									return 1;
								})))));
	}

	private GreyCommands() {}
}

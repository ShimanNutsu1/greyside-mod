package com.greyside;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

/** Команды: /greyside home для всех, travel и level для опов (уровень 2). */
public final class GreyCommands {
	public static void init() {
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
				dispatcher.register(CommandManager.literal("greyside")
						// /greyside home [set|bed|rescan] : тёмная копия дома (доступно всем игрокам)
						.then(CommandManager.literal("home")
								.executes(ctx -> {
									HomeMirror.sendStatus(ctx.getSource().getPlayerOrThrow());
									return 1;
								})
								.then(CommandManager.literal("set").executes(ctx -> {
									HomeMirror.setHere(ctx.getSource().getPlayerOrThrow());
									return 1;
								}))
								.then(CommandManager.literal("bed").executes(ctx -> {
									HomeMirror.useBed(ctx.getSource().getPlayerOrThrow());
									return 1;
								}))
								.then(CommandManager.literal("rescan").executes(ctx -> {
									HomeMirror.rescan(ctx.getSource().getPlayerOrThrow());
									return 1;
								})))
						// /greyside travel : туда/обратно без мотыги
						.then(CommandManager.literal("travel").requires(src -> src.hasPermissionLevel(2)).executes(ctx -> {
							ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
							RiftTravel.travel(p, p.getBlockPos());
							return 1;
						}))
						// /greyside level <0-5> : выставить уровень Серости
						.then(CommandManager.literal("level").requires(src -> src.hasPermissionLevel(2))
								.then(CommandManager.argument("n", IntegerArgumentType.integer(0, 5)).executes(ctx -> {
									int n = IntegerArgumentType.getInteger(ctx, "n");
									GreyState st = GreyState.get(ctx.getSource().getServer());
									st.set(n == 0 ? 0 : GreyState.THRESHOLDS[n - 1]);
									ctx.getSource().sendFeedback(() -> Text.literal("Grey level = " + n), true);
									return 1;
								})))));
	}

	private GreyCommands() {}
}

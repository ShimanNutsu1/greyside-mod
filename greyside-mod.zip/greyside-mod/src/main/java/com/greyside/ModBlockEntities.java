package com.greyside;

import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public final class ModBlockEntities {
	public static final BlockEntityType<DawnAltarBlockEntity> DAWN_ALTAR = Registry.register(
			Registries.BLOCK_ENTITY_TYPE, GreysideMod.id("dawn_altar"),
			FabricBlockEntityTypeBuilder.create(DawnAltarBlockEntity::new, ModBlocks.DAWN_ALTAR).build());

	public static final BlockEntityType<AnchorBlockEntity> ANCHOR = Registry.register(
			Registries.BLOCK_ENTITY_TYPE, GreysideMod.id("anchor"),
			FabricBlockEntityTypeBuilder.create(AnchorBlockEntity::new, ModBlocks.ANCHOR).build());

	public static void init() {}

	private ModBlockEntities() {}
}

package com.greyside;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.world.World;

/** Безмолвник: чёрный крипер, который не шипит перед взрывом. */
public class SilentCreeperEntity extends CreeperEntity {
	public SilentCreeperEntity(EntityType<? extends SilentCreeperEntity> type, World world) {
		super(type, world);
		this.setSilent(true);
	}
}

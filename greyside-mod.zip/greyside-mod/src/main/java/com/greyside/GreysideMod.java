package com.greyside;

import com.greyside.worldgen.ModStructures;
import net.fabricmc.api.ModInitializer;
import net.minecraft.util.Identifier;

public class GreysideMod implements ModInitializer {
	public static final String MOD_ID = "greyside";

	public static Identifier id(String path) {
		return new Identifier(MOD_ID, path);
	}

	@Override
	public void onInitialize() {
		ModSounds.init();
		ModBlocks.init();
		ModBlockEntities.init();
		ModItems.init();
		ModEntities.init();
		ModStructures.init();
		GreyEvents.init();
		MaskItem.initTicker();
		FacelessEntity.initEvents();
		GreyNoise.init();
		GreyCommands.init();
	}
}

package com.greyside;

import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * Жезл Шага. Делается из осколков пустоты и серой пыли (дроп мобов Изнанки).
 *  ПКМ: шаг сквозь пространство на {@link #STEP_RANGE} блоков по взгляду. На месте, откуда ушёл, остаётся эхо:
 *       Слушатели в радиусе 20 блоков бегут туда, а не к тебе.
 *  Shift + ПКМ: только эхо, без шага. Бросает шум в точку, на которую смотришь (до 16 блоков), и уводит Слушателей.
 */
public class StepRodItem extends Item {
	public static final int DURABILITY = 64;
	public static final double STEP_RANGE = 10.0;
	public static final double ECHO_RANGE = 16.0;
	public static final int STEP_COOLDOWN = 100;
	public static final int ECHO_COOLDOWN = 60;

	public StepRodItem(Settings settings) {
		super(settings);
	}

	@Override
	public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
		ItemStack stack = player.getStackInHand(hand);
		if (world.isClient) return TypedActionResult.success(stack);
		if (!(world instanceof ServerWorld sw)) return TypedActionResult.pass(stack);

		boolean ok = player.isSneaking() ? echo(sw, player) : step(sw, player);
		if (!ok) return TypedActionResult.fail(stack);

		stack.damage(1, player, p -> p.sendToolBreakStatus(hand));
		return TypedActionResult.success(stack, true);
	}

	private boolean step(ServerWorld sw, PlayerEntity player) {
		Vec3d eye = player.getEyePos();
		Vec3d far = eye.add(player.getRotationVec(1.0f).multiply(STEP_RANGE));
		BlockHitResult hit = sw.raycast(new RaycastContext(eye, far,
				RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, player));
		Vec3d delta = hit.getPos().subtract(eye);

		// ищем самую дальнюю точку по лучу, где игрок помещается
		Vec3d start = player.getPos();
		Vec3d dest = null;
		for (double t = 1.0; t >= 0.15; t -= 0.05) {
			Vec3d d = delta.multiply(t);
			Box box = player.getBoundingBox().offset(d);
			if (sw.isSpaceEmpty(player, box)) {
				dest = start.add(d);
				break;
			}
		}
		if (dest == null || dest.squaredDistanceTo(start) < 2.25) {
			player.sendMessage(Text.translatable("message.greyside.step_no_room"), true);
			sw.playSound(null, player.getBlockPos(), ModSounds.ANCHOR_DENY, SoundCategory.PLAYERS, 0.7f, 1.2f);
			return false;
		}

		// эхо там, где стоял
		GreyNoise.emit(sw, start, 20);
		sw.spawnParticles(ParticleTypes.SOUL, start.x, start.y + 1.0, start.z, 25, 0.3, 0.6, 0.3, 0.02);
		sw.playSound(null, player.getBlockPos(), ModSounds.ANCHOR_ACTIVATE, SoundCategory.PLAYERS, 0.8f, 1.5f);

		player.requestTeleport(dest.x, dest.y, dest.z);
		player.fallDistance = 0;

		sw.spawnParticles(ParticleTypes.PORTAL, dest.x, dest.y + 1.0, dest.z, 30, 0.3, 0.6, 0.3, 0.3);
		sw.playSound(null, player.getBlockPos(), ModSounds.ANCHOR_ACTIVATE, SoundCategory.PLAYERS, 0.6f, 1.9f);
		player.getItemCooldownManager().set(this, STEP_COOLDOWN);
		return true;
	}

	private boolean echo(ServerWorld sw, PlayerEntity player) {
		Vec3d eye = player.getEyePos();
		Vec3d far = eye.add(player.getRotationVec(1.0f).multiply(ECHO_RANGE));
		BlockHitResult hit = sw.raycast(new RaycastContext(eye, far,
				RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, player));
		Vec3d spot = hit.getPos();

		GreyNoise.emit(sw, spot, 26);
		sw.spawnParticles(ParticleTypes.SOUL, spot.x, spot.y + 0.2, spot.z, 30, 0.4, 0.4, 0.4, 0.03);
		sw.playSound(null, player.getBlockPos(), ModSounds.ANCHOR_ACTIVATE, SoundCategory.PLAYERS, 0.5f, 1.2f);
		sw.playSound(null, net.minecraft.util.math.BlockPos.ofFloored(spot), ModSounds.WHISPER, SoundCategory.PLAYERS, 1.0f, 1.0f);
		player.getItemCooldownManager().set(this, ECHO_COOLDOWN);
		return true;
	}

	@Override
	public boolean canRepair(ItemStack stack, ItemStack ingredient) {
		return ingredient.isOf(ModItems.VOID_SHARD);
	}

	@Override
	public void appendTooltip(ItemStack stack, @Nullable World world, List<Text> tooltip, TooltipContext context) {
		tooltip.add(Text.translatable("item.greyside.step_rod.tip1").formatted(Formatting.GRAY));
		tooltip.add(Text.translatable("item.greyside.step_rod.tip2").formatted(Formatting.GRAY));
	}
}

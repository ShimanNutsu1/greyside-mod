package com.greyside;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;

/** Резец Иона: сильный меч, каждый удар замедляет цель на 3 секунды. */
public class IonChiselItem extends SwordItem {
	public IonChiselItem(Settings settings) {
		super(IonToolMaterial.INSTANCE, 3, -2.2f, settings);
	}

	@Override
	public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
		target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 1), attacker);
		return super.postHit(stack, target, attacker);
	}
}

package com.greyside;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.FlowerBlock;
import net.minecraft.registry.Registries;
import net.minecraft.state.property.Property;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

/**
 * «Тёмная версия» блока: то, во что превращается постройка игрока в Изнанке.
 * Дерево становится тёмным дубом, камень глубинным сланцем и чернокамнем, цветные блоки чёрными,
 * факелы синими (душевыми), стекло тонированным, цветы увядшими розами.
 * Блоки без пары и чужих модов остаются как есть. Свойства (направление, половинка двери и т. п.) переносятся.
 */
public final class DarkPalette {
	private static final Map<Block, Block> CACHE = new HashMap<>();
	private static final Map<String, String> EXACT = new HashMap<>();

	private static final String[] COLORS = {
			"white", "orange", "magenta", "light_blue", "yellow", "lime", "pink", "gray",
			"light_gray", "cyan", "purple", "blue", "brown", "green", "red", "black"
	};
	private static final Set<String> COLOR_PARTS = Set.of(
			"wool", "carpet", "concrete", "concrete_powder", "terracotta", "glazed_terracotta",
			"stained_glass", "stained_glass_pane", "bed", "banner", "wall_banner", "candle", "candle_cake", "shulker_box");

	private static final String[] WOODS = {
			"oak", "spruce", "birch", "jungle", "acacia", "cherry", "mangrove", "bamboo", "crimson", "warped"
	};
	private static final Set<String> WOOD_PARTS = Set.of(
			"planks", "log", "wood", "stripped_log", "stripped_wood", "stairs", "slab", "fence", "fence_gate",
			"door", "trapdoor", "button", "pressure_plate", "sign", "wall_sign", "hanging_sign", "wall_hanging_sign", "leaves");

	static {
		// камень
		EXACT.put("stone", "deepslate");
		EXACT.put("cobblestone", "cobbled_deepslate");
		EXACT.put("mossy_cobblestone", "cobbled_deepslate");
		EXACT.put("stone_bricks", "deepslate_bricks");
		EXACT.put("mossy_stone_bricks", "deepslate_bricks");
		EXACT.put("cracked_stone_bricks", "cracked_deepslate_bricks");
		EXACT.put("chiseled_stone_bricks", "chiseled_deepslate");
		EXACT.put("smooth_stone", "polished_deepslate");
		for (String p : new String[]{"cobblestone", "mossy_cobblestone", "stone"}) {
			EXACT.put(p + "_stairs", "cobbled_deepslate_stairs");
			EXACT.put(p + "_slab", "cobbled_deepslate_slab");
		}
		EXACT.put("cobblestone_wall", "cobbled_deepslate_wall");
		EXACT.put("mossy_cobblestone_wall", "cobbled_deepslate_wall");
		for (String p : new String[]{"stone_brick", "mossy_stone_brick"}) {
			EXACT.put(p + "_stairs", "deepslate_brick_stairs");
			EXACT.put(p + "_slab", "deepslate_brick_slab");
			EXACT.put(p + "_wall", "deepslate_brick_wall");
		}
		EXACT.put("smooth_stone_slab", "polished_deepslate_slab");
		// андезит, диорит, гранит
		for (String p : new String[]{"andesite", "diorite", "granite"}) {
			EXACT.put(p, "blackstone");
			EXACT.put("polished_" + p, "polished_blackstone");
			EXACT.put(p + "_stairs", "blackstone_stairs");
			EXACT.put(p + "_slab", "blackstone_slab");
			EXACT.put(p + "_wall", "blackstone_wall");
			EXACT.put("polished_" + p + "_stairs", "polished_blackstone_stairs");
			EXACT.put("polished_" + p + "_slab", "polished_blackstone_slab");
		}
		// кирпич
		EXACT.put("bricks", "polished_blackstone_bricks");
		EXACT.put("brick_stairs", "polished_blackstone_brick_stairs");
		EXACT.put("brick_slab", "polished_blackstone_brick_slab");
		EXACT.put("brick_wall", "polished_blackstone_brick_wall");
		// песчаник и кварц
		for (String p : new String[]{"sandstone", "red_sandstone"}) {
			EXACT.put(p, "blackstone");
			EXACT.put("cut_" + p, "polished_blackstone");
			EXACT.put("smooth_" + p, "polished_blackstone");
			EXACT.put("chiseled_" + p, "chiseled_polished_blackstone");
			EXACT.put(p + "_stairs", "blackstone_stairs");
			EXACT.put("smooth_" + p + "_stairs", "blackstone_stairs");
			EXACT.put(p + "_slab", "blackstone_slab");
			EXACT.put("cut_" + p + "_slab", "blackstone_slab");
			EXACT.put("smooth_" + p + "_slab", "blackstone_slab");
			EXACT.put(p + "_wall", "blackstone_wall");
		}
		EXACT.put("quartz_block", "blackstone");
		EXACT.put("smooth_quartz", "polished_blackstone");
		EXACT.put("quartz_stairs", "blackstone_stairs");
		EXACT.put("smooth_quartz_stairs", "blackstone_stairs");
		EXACT.put("quartz_slab", "blackstone_slab");
		EXACT.put("smooth_quartz_slab", "blackstone_slab");
		// стекло и свет
		EXACT.put("glass", "tinted_glass");
		EXACT.put("glass_pane", "black_stained_glass_pane");
		EXACT.put("torch", "soul_torch");
		EXACT.put("wall_torch", "soul_wall_torch");
		EXACT.put("lantern", "soul_lantern");
		EXACT.put("campfire", "soul_campfire");
	}

	private DarkPalette() {}

	/** Тёмный двойник состояния блока. Для воздуха и блоков без пары возвращает то же состояние. */
	public static BlockState darken(BlockState s) {
		if (s.isAir()) return s;
		Block b = s.getBlock();
		Block target = CACHE.computeIfAbsent(b, DarkPalette::resolve);
		return target == b ? s : transfer(s, target);
	}

	private static Block resolve(Block b) {
		Identifier id = Registries.BLOCK.getId(b);
		if (!"minecraft".equals(id.getNamespace())) return b;
		String path = id.getPath();

		String to = EXACT.get(path);
		if (to == null) to = byColor(path);
		if (to == null) to = byWood(path);
		if (to != null) {
			Optional<Block> o = Registries.BLOCK.getOrEmpty(new Identifier("minecraft", to));
			if (o.isPresent()) return o.get();
		}
		if (b instanceof FlowerBlock) return Blocks.WITHER_ROSE;
		return b;
	}

	private static String byColor(String path) {
		for (String c : COLORS) {
			String prefix = c + "_";
			if (path.startsWith(prefix) && COLOR_PARTS.contains(path.substring(prefix.length()))) {
				return "black_" + path.substring(prefix.length());
			}
		}
		return null;
	}

	private static String byWood(String path) {
		for (String w : WOODS) {
			String prefix = w + "_";
			if (path.startsWith(prefix) && WOOD_PARTS.contains(path.substring(prefix.length()))) {
				return "dark_oak_" + path.substring(prefix.length());
			}
		}
		return null;
	}

	private static BlockState transfer(BlockState from, Block to) {
		BlockState r = to.getDefaultState();
		for (Property<?> p : from.getProperties()) r = copy(p, from, r);
		return r;
	}

	private static <T extends Comparable<T>> BlockState copy(Property<T> p, BlockState from, BlockState to) {
		return to.contains(p) ? to.with(p, from.get(p)) : to;
	}
}

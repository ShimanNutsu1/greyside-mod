package com.greyside;

import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** Хранит ссылку на парный Якорь в другом мире. */
public class AnchorBlockEntity extends BlockEntity {
	private RegistryKey<World> linkWorld;
	private BlockPos linkPos;

	public AnchorBlockEntity(BlockPos pos, BlockState state) {
		super(ModBlockEntities.ANCHOR, pos, state);
	}

	public RegistryKey<World> getLinkWorld() { return linkWorld; }
	public BlockPos getLinkPos() { return linkPos; }

	public void setLink(RegistryKey<World> world, BlockPos pos) {
		this.linkWorld = world;
		this.linkPos = pos.toImmutable();
		markDirty();
	}

	@Override
	protected void writeNbt(NbtCompound nbt) {
		super.writeNbt(nbt);
		if (linkWorld != null && linkPos != null) {
			nbt.putString("linkWorld", linkWorld.getValue().toString());
			nbt.putLong("linkPos", linkPos.asLong());
		}
	}

	@Override
	public void readNbt(NbtCompound nbt) {
		super.readNbt(nbt);
		if (nbt.contains("linkWorld") && nbt.contains("linkPos")) {
			Identifier id = Identifier.tryParse(nbt.getString("linkWorld"));
			if (id != null) {
				linkWorld = RegistryKey.of(RegistryKeys.WORLD, id);
				linkPos = BlockPos.fromLong(nbt.getLong("linkPos"));
			}
		}
	}
}

package com.greyside;

import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

/** Собственные звуки мода. Файлы лежат в assets/greyside/sounds, описание в sounds.json. */
public final class ModSounds {
	public static final SoundEvent RIFT_WARNING = register("rift_warning");
	public static final SoundEvent RIFT_COLLAPSE = register("rift_collapse");
	public static final SoundEvent ANCHOR_ACTIVATE = register("anchor_activate");
	public static final SoundEvent ANCHOR_DENY = register("anchor_deny");
	public static final SoundEvent LISTENER_IDLE = register("listener_idle");
	public static final SoundEvent LISTENER_ALERT = register("listener_alert");
	public static final SoundEvent LISTENER_HURT = register("listener_hurt");
	public static final SoundEvent LISTENER_DEATH = register("listener_death");
	public static final SoundEvent WHISPER = register("whisper");

	private static SoundEvent register(String name) {
		Identifier id = GreysideMod.id(name);
		return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
	}

	public static void init() {}

	private ModSounds() {}
}

package com.greyside;

import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * Якорь Изнанки: постоянный переход между мирами.
 * ПКМ: платишь осколком пустоты (или серой пылью) и оказываешься у парного Якоря в другом мире.
 * Парный Якорь создаётся сам при первом переходе.
 */
public class AnchorBlock extends BlockWithEntity {
	public AnchorBlock(Settings settings) {
		super(settings);
	}

	@Override
	public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
		return new AnchorBlockEntity(pos, state);
	}

	@Override
	public BlockRenderType getRenderType(BlockState state) {
		return BlockRenderType.MODEL;
	}

	@Override
	public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
		if (world.isClient) return ActionResult.SUCCESS;
		if (world instanceof ServerWorld sw && player instanceof ServerPlayerEntity sp) {
			AnchorTravel.activate(sw, pos, sp);
		}
		return ActionResult.SUCCESS;
	}
}

package com.greyside;

import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

import java.util.List;

public class DawnAltarBlockEntity extends BlockEntity {
	public static final int DURATION = 1800;      // 90 секунд
	public static final int MAX_INTEGRITY = 20;
	public static final String RITUAL_TAG = "greyside_ritual";

	private boolean active = false;
	private int remaining = 0;
	private int integrity = MAX_INTEGRITY;
	private int wave = 0;

	public DawnAltarBlockEntity(BlockPos pos, BlockState state) {
		super(ModBlockEntities.DAWN_ALTAR, pos, state);
	}

	public boolean isActive() { return active; }

	public void start() {
		active = true;
		remaining = DURATION;
		integrity = MAX_INTEGRITY;
		wave = 0;
		markDirty();
	}

	@Override
	protected void writeNbt(NbtCompound nbt) {
		super.writeNbt(nbt);
		nbt.putBoolean("active", active);
		nbt.putInt("remaining", remaining);
		nbt.putInt("integrity", integrity);
		nbt.putInt("wave", wave);
	}

	@Override
	public void readNbt(NbtCompound nbt) {
		super.readNbt(nbt);
		active = nbt.getBoolean("active");
		remaining = nbt.getInt("remaining");
		integrity = nbt.contains("integrity") ? nbt.getInt("integrity") : MAX_INTEGRITY;
		wave = nbt.getInt("wave");
	}

	public static void tick(World world, BlockPos pos, BlockState state, DawnAltarBlockEntity be) {
		if (!(world instanceof ServerWorld sw) || !be.active) return;

		be.remaining--;
		long time = world.getTime();
		Vec3d center = Vec3d.ofCenter(pos);

		if (time % 5 == 0) {
			sw.spawnParticles(ParticleTypes.END_ROD, center.x, center.y + 0.8, center.z, 2, 0.3, 0.6, 0.3, 0.02);
		}

		// новая волна каждые 7.5 секунд (первая через ~5 секунд)
		if (be.remaining % 150 == 0 && be.remaining < DURATION - 60 && be.remaining > 100) {
			be.wave++;
			be.spawnWave(sw);
		}

		// раз в секунду: притягиваем мобов к алтарю, считаем урон, показываем статус
		if (time % 20 == 0) {
			int near = 0;
			Box area = new Box(pos).expand(40);
			List<MobEntity> mobs = sw.getEntitiesByClass(MobEntity.class, area,
					m -> m.getCommandTags().contains(RITUAL_TAG));
			for (MobEntity m : mobs) {
				if (m.getTarget() == null) {
					m.getNavigation().startMovingTo(center.x, pos.getY(), center.z, 1.0);
				}
				if (m.squaredDistanceTo(center) < 12) near++;
			}
			be.integrity -= Math.min(near, 4);
			if (near > 0) {
				sw.playSound(null, pos, SoundEvents.BLOCK_ANVIL_LAND, SoundCategory.BLOCKS, 0.4f, 0.6f);
			}
			// игрок рядом помогает алтарю держаться
			boolean defended = !sw.getPlayers(p -> p.squaredDistanceTo(center) < 36).isEmpty();
			if (defended && be.integrity < MAX_INTEGRITY && time % 60 == 0) be.integrity++;

			for (ServerPlayerEntity p : sw.getPlayers(pl -> pl.squaredDistanceTo(center) < 900)) {
				p.sendMessage(Text.translatable("message.greyside.ritual_status",
						Math.max(be.remaining, 0) / 20, Math.max(be.integrity, 0)), true);
			}
			be.markDirty();
		}

		if (be.integrity <= 0) {
			be.fail(sw, pos, center);
		} else if (be.remaining <= 0) {
			be.succeed(sw, pos, center);
		}
	}

	private void spawnWave(ServerWorld w) {
		Random r = w.random;
		int count = Math.min(2 + wave, 8);
		for (int i = 0; i < count; i++) {
			EntityType<? extends MobEntity> type = ModEntities.SHADOW;
			int roll = r.nextInt(100);
			if (wave >= 3 && roll < 40) type = ModEntities.SHADE_ARCHER;

			double ang = r.nextDouble() * Math.PI * 2;
			double dist = 12 + r.nextInt(5);
			int x = pos.getX() + (int) (Math.cos(ang) * dist);
			int z = pos.getZ() + (int) (Math.sin(ang) * dist);
			if (!w.isChunkLoaded(new BlockPos(x, 0, z))) continue;
			BlockPos ground = GreyMobs.findGround(w, x, z, pos.getY());
			if (ground == null) continue;
			MobEntity m = GreyMobs.spawnAt(type, w, ground);
			if (m != null) {
				m.addCommandTag(RITUAL_TAG);
				m.setPersistent();
			}
		}
		w.playSound(null, pos, SoundEvents.ENTITY_WARDEN_NEARBY_CLOSER, SoundCategory.HOSTILE, 1.0f, 0.7f);
	}

	private void succeed(ServerWorld w, BlockPos pos, Vec3d center) {
		active = false;
		GreyState.get(w.getServer()).reduceLevel();
		clearRitualMobs(w, pos, true);
		w.spawnParticles(ParticleTypes.END_ROD, center.x, center.y + 1, center.z, 80, 1.0, 1.5, 1.0, 0.1);
		w.playSound(null, pos, SoundEvents.BLOCK_BEACON_ACTIVATE, SoundCategory.BLOCKS, 1.5f, 1.0f);
		for (ServerPlayerEntity p : w.getPlayers(pl -> pl.squaredDistanceTo(center) < 900)) {
			p.sendMessage(Text.translatable("message.greyside.ritual_success"), true);
		}
		w.removeBlock(pos, false);
	}

	private void fail(ServerWorld w, BlockPos pos, Vec3d center) {
		active = false;
		GreyState.get(w.getServer()).add(3600); // +3 минуты Серости
		w.createExplosion(null, center.x, center.y, center.z, 2.0f, World.ExplosionSourceType.NONE);
		for (ServerPlayerEntity p : w.getPlayers(pl -> pl.squaredDistanceTo(center) < 900)) {
			p.sendMessage(Text.translatable("message.greyside.ritual_failed"), true);
		}
		w.removeBlock(pos, false);
	}

	private void clearRitualMobs(ServerWorld w, BlockPos pos, boolean particles) {
		for (MobEntity m : w.getEntitiesByClass(MobEntity.class, new Box(pos).expand(60),
				e -> e.getCommandTags().contains(RITUAL_TAG))) {
			if (particles) w.spawnParticles(ParticleTypes.SMOKE, m.getX(), m.getY() + 1, m.getZ(), 10, 0.3, 0.5, 0.3, 0.02);
			m.discard();
		}
	}
}

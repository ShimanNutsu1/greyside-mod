package com.greyside;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** ПКМ по земле: мотыга ломается и открывает трещину в Изнанку (или обратно). */
public class RiftHoeItem extends Item {
	public RiftHoeItem(Settings settings) {
		super(settings);
	}

	@Override
	public ActionResult useOnBlock(ItemUsageContext ctx) {
		World world = ctx.getWorld();
		if (world.isClient) return ActionResult.SUCCESS;

		PlayerEntity player = ctx.getPlayer();
		if (player == null) return ActionResult.PASS;

		boolean valid = world.getRegistryKey() == World.OVERWORLD || world.getRegistryKey() == ModDimensions.GREYSIDE;
		if (!valid) {
			player.sendMessage(Text.translatable("message.greyside.bad_dimension"), true);
			return ActionResult.FAIL;
		}

		BlockPos pos = ctx.getBlockPos().offset(ctx.getSide());
		if (!world.getBlockState(pos).isReplaceable()) {
			player.sendMessage(Text.translatable("message.greyside.no_space"), true);
			return ActionResult.FAIL;
		}

		world.setBlockState(pos, ModBlocks.RIFT.getDefaultState());
		world.playSound(null, pos, SoundEvents.ITEM_SHIELD_BREAK, SoundCategory.PLAYERS, 1.0f, 0.6f);
		world.playSound(null, pos, SoundEvents.BLOCK_END_PORTAL_SPAWN, SoundCategory.BLOCKS, 0.4f, 1.6f);
		if (world instanceof ServerWorld sw) {
			sw.spawnParticles(ParticleTypes.SMOKE, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 30, 0.4, 0.4, 0.4, 0.02);
		}
		if (!player.isCreative()) {
			ctx.getStack().decrement(1); // мотыга ломается
		}
		return ActionResult.SUCCESS;
	}
}

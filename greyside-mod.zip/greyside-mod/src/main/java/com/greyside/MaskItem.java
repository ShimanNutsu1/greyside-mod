package com.greyside;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.ItemStack;
import net.minecraft.recipe.Ingredient;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * Маски Безликого. Надеваются в слот шлема. У каждой есть дар и цена:
 * <ul>
 *   <li><b>Безмолвия</b>: шаги не слышны Слушателям. Цена: Слабость I.</li>
 *   <li><b>Наблюдателя</b>: Безликий замирает в более широком конусе взгляда (0.72 вместо 0.90).
 *       Цена: Серость копится вдвое быстрее, пока маска на тебе.</li>
 *   <li><b>Иона</b> (награда за босса): ночное зрение в Изнанке и иммунитет к «Страху», без цены.</li>
 *   <li><b>Пустоты</b>: ночное зрение в Изнанке и иммунитет к «Страху» Безликого. Цена: Голод I.</li>
 * </ul>
 * Касание Безликого срывает часть прочности маски (см. {@link FacelessEntity}).
 */
public class MaskItem extends ArmorItem {
	public enum Kind {
		SILENCE("mask_silence"), WATCHER("mask_watcher"), VOID("mask_void"), ION("mask_ion");

		public final String id;

		Kind(String id) {
			this.id = id;
		}
	}

	public static final int DURABILITY = 120;
	/** Сколько прочности снимает касание Безликого. */
	public static final int FACELESS_DAMAGE = 60;

	private final Kind kind;

	public MaskItem(Kind kind, Settings settings) {
		super(new Material(kind), Type.HELMET, settings);
		this.kind = kind;
	}

	public Kind kind() {
		return kind;
	}

	public static boolean wearing(LivingEntity e, Kind k) {
		ItemStack s = e.getEquippedStack(EquipmentSlot.HEAD);
		return s.getItem() instanceof MaskItem m && m.kind == k;
	}

	public static boolean wearingAny(LivingEntity e) {
		return e.getEquippedStack(EquipmentSlot.HEAD).getItem() instanceof MaskItem;
	}

	@Override
	public void appendTooltip(ItemStack stack, @Nullable World world, List<Text> tooltip, TooltipContext context) {
		tooltip.add(Text.translatable("item.greyside." + kind.id + ".boon").formatted(Formatting.GRAY));
		tooltip.add(Text.translatable("item.greyside." + kind.id + ".price").formatted(Formatting.DARK_RED));
		tooltip.add(Text.translatable("item.greyside.mask.warning").formatted(Formatting.DARK_GRAY));
	}

	/** Постоянные эффекты масок. Раз в секунду, длительность с запасом, без частиц. */
	public static void initTicker() {
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			if (server.getTicks() % 20 != 0) return;
			for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
				if (p.isSpectator()) continue;
				if (wearing(p, Kind.SILENCE)) {
					p.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 60, 0, true, false, false));
				}
				if (wearing(p, Kind.ION) && p.getWorld().getRegistryKey() == ModDimensions.GREYSIDE) {
					p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 260, 0, true, false, false));
				}
				if (wearing(p, Kind.VOID)) {
					p.addStatusEffect(new StatusEffectInstance(StatusEffects.HUNGER, 60, 0, true, false, false));
					if (p.getWorld().getRegistryKey() == ModDimensions.GREYSIDE) {
						p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 260, 0, true, false, false));
					}
				}
			}
		});
	}

	/** Материал «брони»: защиты нет, это только маска. Имя = имя текстуры в minecraft:textures/models/armor. */
	private record Material(Kind kind) implements ArmorMaterial {
		@Override public int getDurability(Type type) { return DURABILITY; }
		@Override public int getProtection(Type type) { return 0; }
		@Override public int getEnchantability() { return 8; }
		@Override public SoundEvent getEquipSound() { return SoundEvents.ITEM_ARMOR_EQUIP_LEATHER; }
		@Override public Ingredient getRepairIngredient() { return Ingredient.ofItems(ModItems.VOID_SHARD); }
		@Override public String getName() { return "greyside_" + kind.id; }
		@Override public float getToughness() { return 0.0f; }
		@Override public float getKnockbackResistance() { return 0.0f; }
	}
}

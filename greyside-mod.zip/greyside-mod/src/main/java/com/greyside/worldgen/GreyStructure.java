package com.greyside.worldgen;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.structure.StructurePiece;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.Heightmap;
import net.minecraft.world.gen.structure.Structure;
import net.minecraft.world.gen.structure.StructureType;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Одна структура Изнанки. Какая именно, задаёт поле "kind" в json:
 * village / tower / pit / grove / lair. Расстановка кусков считается здесь (по высотам рельефа),
 * а сами блоки ставит {@link GreyPiece}.
 */
public class GreyStructure extends Structure {
	public static final Codec<GreyStructure> CODEC = RecordCodecBuilder.create(instance -> instance.group(
			configCodecBuilder(instance),
			Codec.STRING.fieldOf("kind").forGetter(s -> s.kind)
	).apply(instance, GreyStructure::new));

	private final String kind;

	public GreyStructure(Structure.Config config, String kind) {
		super(config);
		this.kind = kind;
	}

	@Override
	public StructureType<?> getType() {
		return ModStructures.STRUCTURE_TYPE;
	}

	@Override
	protected Optional<StructurePosition> getStructurePosition(Context ctx) {
		ChunkPos cp = ctx.chunkPos();
		int cx = cp.getCenterX();
		int cz = cp.getCenterZ();
		Random r = ctx.random();
		long seed = r.nextLong();

		if (!dry(ctx, cx, cz)) return Optional.empty();
		int cy = height(ctx, cx, cz);

		List<StructurePiece> pieces = new ArrayList<>();
		boolean ok;
		switch (kind) {
			case "village" -> ok = village(ctx, r, seed, cx, cy, cz, pieces);
			case "tower" -> ok = tower(ctx, r, seed, cx, cz, pieces);
			case "pit" -> ok = pit(ctx, r, seed, cx, cy, cz, pieces);
			case "grove" -> ok = grove(ctx, r, seed, cx, cy, cz, pieces);
			case "lair" -> ok = lair(ctx, r, seed, cx, cz, pieces);
			default -> ok = false;
		}
		if (!ok || pieces.isEmpty()) return Optional.empty();

		return Optional.of(new StructurePosition(new BlockPos(cx, cy, cz), collector -> {
			for (StructurePiece p : pieces) collector.addPiece(p);
		}));
	}

	// ---------- разбор рельефа ----------

	private static int height(Context c, int x, int z) {
		return c.chunkGenerator().getHeight(x, z, Heightmap.Type.WORLD_SURFACE_WG, c.world(), c.noiseConfig());
	}

	private static int floor(Context c, int x, int z) {
		return c.chunkGenerator().getHeight(x, z, Heightmap.Type.OCEAN_FLOOR_WG, c.world(), c.noiseConfig());
	}

	/** Сухая земля: сверху нет воды. */
	private static boolean dry(Context c, int x, int z) {
		return height(c, x, z) == floor(c, x, z);
	}

	private static int maxH(Context c, int x, int z, int d) {
		int m = height(c, x, z);
		m = Math.max(m, height(c, x + d, z + d));
		m = Math.max(m, height(c, x - d, z + d));
		m = Math.max(m, height(c, x + d, z - d));
		m = Math.max(m, height(c, x - d, z - d));
		return m;
	}

	private static int minH(Context c, int x, int z, int d) {
		int m = height(c, x, z);
		m = Math.min(m, height(c, x + d, z + d));
		m = Math.min(m, height(c, x - d, z + d));
		m = Math.min(m, height(c, x + d, z - d));
		m = Math.min(m, height(c, x - d, z - d));
		return m;
	}

	private static int slope(Context c, int x, int z, int d) {
		return maxH(c, x, z, d) - minH(c, x, z, d);
	}

	private static boolean dryAround(Context c, int x, int z, int d) {
		return dry(c, x + d, z + d) && dry(c, x - d, z + d) && dry(c, x + d, z - d) && dry(c, x - d, z - d);
	}

	// ---------- деревня ----------

	private boolean village(Context c, Random r, long seed, int cx, int cy, int cz, List<StructurePiece> out) {
		if (slope(c, cx, cz, 6) > 6 || !dryAround(c, cx, cz, 6)) return false;

		List<StructurePiece> paths = new ArrayList<>();
		List<StructurePiece> houses = new ArrayList<>();
		List<int[]> placed = new ArrayList<>();
		int want = 5 + r.nextInt(5);

		for (int attempt = 0; attempt < 70 && placed.size() < want; attempt++) {
			double ang = r.nextDouble() * Math.PI * 2;
			double rad = 10 + r.nextDouble() * 16;
			int bx = (int) Math.round(cx + Math.cos(ang) * rad);
			int bz = (int) Math.round(cz + Math.sin(ang) * rad);

			boolean close = false;
			for (int[] p : placed) {
				if (Math.abs(p[0] - bx) < 10 && Math.abs(p[1] - bz) < 10) { close = true; break; }
			}
			if (close || !dry(c, bx, bz) || !dryAround(c, bx, bz, 3) || slope(c, bx, bz, 3) > 3) continue;
			int by = maxH(c, bx, bz, 3);
			if (Math.abs(by - cy) > 7) continue;

			int dx = bx - cx, dz = bz - cz;
			int rot;
			if (Math.abs(dz) >= Math.abs(dx)) rot = dz > 0 ? 0 : 2;
			else rot = dx > 0 ? 3 : 1;

			boolean big = r.nextInt(10) < 3;
			int hw = big ? 3 : 2 + r.nextInt(2);
			int hd = big ? 3 + r.nextInt(2) : 2 + r.nextInt(2);
			int h = big ? 7 : 3 + r.nextInt(2);
			int ruin = 25 + r.nextInt(55);

			houses.add(new GreyPiece(GreyPiece.HOUSE, bx, by, bz, rot, hw, hd, h, ruin, seed ^ (placed.size() * 7919L + 13)));
			paths.add(new GreyPiece(GreyPiece.PATH, cx, cy, cz, 0, bx, bz, 0, 0, seed ^ (placed.size() * 104729L + 5)));
			placed.add(new int[]{bx, bz});
		}
		if (placed.size() < 3) return false;

		out.add(new GreyPiece(GreyPiece.WELL, cx, cy, cz, 0, 0, 0, 0, 0, seed));
		out.addAll(paths);
		out.addAll(houses);
		return true;
	}

	// ---------- одинокая башня ----------

	private boolean tower(Context c, Random r, long seed, int cx, int cz, List<StructurePiece> out) {
		if (slope(c, cx, cz, 5) > 5 || !dryAround(c, cx, cz, 5)) return false;
		int by = maxH(c, cx, cz, 5);
		int h = 13 + r.nextInt(7);
		out.add(new GreyPiece(GreyPiece.TOWER, cx, by, cz, 0, h, 0, 0, 0, seed));
		return true;
	}

	// ---------- яма с колодцем ----------

	private boolean pit(Context c, Random r, long seed, int cx, int cy, int cz, List<StructurePiece> out) {
		if (slope(c, cx, cz, 6) > 4 || !dryAround(c, cx, cz, 6)) return false;
		int radius = 8 + r.nextInt(3);
		int shaft = 22 + r.nextInt(10);
		out.add(new GreyPiece(GreyPiece.PIT, cx, cy, cz, 0, radius, shaft, 0, 0, seed));
		return true;
	}

	// ---------- поляна Тёмных Древ ----------

	private boolean grove(Context c, Random r, long seed, int cx, int cy, int cz, List<StructurePiece> out) {
		if (slope(c, cx, cz, 8) > 6 || !dryAround(c, cx, cz, 8)) return false;

		out.add(new GreyPiece(GreyPiece.CLEARING, cx, cy, cz, 0, 12, 0, 0, 0, seed));
		// большое древо в центре, у корней сундук
		out.add(new GreyPiece(GreyPiece.TREE, cx, cy, cz, 0, 3, 20 + r.nextInt(6), 1, 0, seed ^ 31L));

		List<int[]> trees = new ArrayList<>();
		int want = 5 + r.nextInt(4);
		for (int attempt = 0; attempt < 40 && trees.size() < want; attempt++) {
			double ang = r.nextDouble() * Math.PI * 2;
			double rad = 6 + r.nextDouble() * 5;
			int tx = (int) Math.round(cx + Math.cos(ang) * rad);
			int tz = (int) Math.round(cz + Math.sin(ang) * rad);
			boolean close = false;
			for (int[] t : trees) {
				if (Math.abs(t[0] - tx) < 5 && Math.abs(t[1] - tz) < 5) { close = true; break; }
			}
			if (close || !dry(c, tx, tz) || !dry(c, tx + 1, tz + 1)) continue;
			int ty = maxH(c, tx, tz, 1);
			if (Math.abs(ty - cy) > 6) continue;
			trees.add(new int[]{tx, tz});
			out.add(new GreyPiece(GreyPiece.TREE, tx, ty, tz, 0, 2, 11 + r.nextInt(7), 0, 0, seed ^ (trees.size() * 977L + 3)));
		}
		return true;
	}

	// ---------- логово Безликого ----------

	private boolean lair(Context c, Random r, long seed, int cx, int cz, List<StructurePiece> out) {
		if (slope(c, cx, cz, 8) > 4 || !dryAround(c, cx, cz, 8)) return false;
		int by = minH(c, cx, cz, 8); // самая низкая точка вокруг: потолок зала гарантированно под землёй
		int rot = r.nextInt(4);

		// вход на локальной оси -z, 16 блоков от центра: должен быть на суше и не слишком высоко
		int ex = cx + (rot == 1 ? 16 : rot == 3 ? -16 : 0);
		int ez = cz + (rot == 0 ? -16 : rot == 2 ? 16 : 0);
		if (!dry(c, ex, ez) || Math.abs(height(c, ex, ez) - by) > 6) return false;

		out.add(new GreyPiece(GreyPiece.LAIR, cx, by, cz, rot, 0, 0, 0, 0, seed));
		return true;
	}
}

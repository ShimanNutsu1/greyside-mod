package com.greyside.worldgen;

import com.greyside.GreysideMod;
import com.mojang.serialization.Codec;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.structure.StructurePieceType;
import net.minecraft.world.gen.structure.Structure;
import net.minecraft.world.gen.structure.StructureType;

/** Регистрация типа структуры и типа куска. Сами структуры описаны в data/greyside/worldgen. */
public final class ModStructures {
	public static StructurePieceType PIECE;
	public static StructureType<GreyStructure> STRUCTURE_TYPE;

	public static void init() {
		PIECE = Registry.register(Registries.STRUCTURE_PIECE, GreysideMod.id("grey_piece"),
				(StructurePieceType) (context, nbt) -> new GreyPiece(nbt));
		STRUCTURE_TYPE = registerType("grey_structure", GreyStructure.CODEC);
	}

	private static <S extends Structure> StructureType<S> registerType(String id, Codec<S> codec) {
		return Registry.register(Registries.STRUCTURE_TYPE, GreysideMod.id(id), () -> codec);
	}

	private ModStructures() {}
}

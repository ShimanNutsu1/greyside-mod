package com.greyside.worldgen;

import com.greyside.FacelessEntity;
import com.greyside.GreysideMod;
import com.greyside.MaskPedestalBlock;
import com.greyside.ModBlocks;
import com.greyside.ModDimensions;
import com.greyside.ModEntities;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.CarvedPumpkinBlock;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.LanternBlock;
import net.minecraft.block.LadderBlock;
import net.minecraft.block.entity.LootableContainerBlockEntity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.structure.StructureContext;
import net.minecraft.structure.StructurePiece;
import net.minecraft.util.math.BlockBox;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.Heightmap;
import net.minecraft.world.StructureWorldAccess;
import net.minecraft.world.gen.StructureAccessor;
import net.minecraft.world.gen.chunk.ChunkGenerator;

/**
 * Универсальный кусок структур Изнанки. Все решения «случайности» берутся из хэша
 * (seed, x, y, z), поэтому кусок выглядит одинаково, в каком бы порядке ни генерировались чанки.
 * Блоки ставятся только внутри chunkBox.
 *
 * Локальные координаты домов: -z = «фасад» (смотрит на центр деревни), поворот rot по часовой.
 * oy = первый свободный блок над землёй (высота WORLD_SURFACE_WG), земля лежит на oy - 1.
 */
public class GreyPiece extends StructurePiece {
	public static final int HOUSE = 0, WELL = 1, PATH = 2, TOWER = 3, PIT = 4, CLEARING = 5, TREE = 6, LAIR = 7, ARENA = 8;

	/** Стороны по часовой от севера: индекс 0..3. */
	private static final Direction[] CW = {Direction.NORTH, Direction.EAST, Direction.SOUTH, Direction.WEST};
	private static final int N = 0, E = 1, S = 2, W = 3;
	private static final int[] DX = {1, 1, 0, -1, -1, -1, 0, 1};
	private static final int[] DZ = {0, 1, 1, 1, 0, -1, -1, -1};

	private static final BlockState AIR = Blocks.AIR.getDefaultState();
	private static final BlockState COBBLE = Blocks.COBBLESTONE.getDefaultState();
	private static final BlockState MOSSY = Blocks.MOSSY_COBBLESTONE.getDefaultState();
	private static final BlockState BRICKS = Blocks.STONE_BRICKS.getDefaultState();
	private static final BlockState MOSSY_BRICKS = Blocks.MOSSY_STONE_BRICKS.getDefaultState();
	private static final BlockState CRACKED = Blocks.CRACKED_STONE_BRICKS.getDefaultState();
	private static final BlockState ANDESITE = Blocks.ANDESITE.getDefaultState();
	private static final BlockState PLANKS = Blocks.DARK_OAK_PLANKS.getDefaultState();
	private static final BlockState LOG = Blocks.DARK_OAK_LOG.getDefaultState();
	private static final BlockState WOOD = Blocks.DARK_OAK_WOOD.getDefaultState();
	private static final BlockState COBWEB = Blocks.COBWEB.getDefaultState();
	private static final BlockState COARSE = Blocks.COARSE_DIRT.getDefaultState();
	private static final BlockState PODZOL = Blocks.PODZOL.getDefaultState();

	private final int kind, ox, oy, oz, rot, a, b, c, d;
	private final long seed;

	public GreyPiece(int kind, int ox, int oy, int oz, int rot, int a, int b, int c, int d, long seed) {
		super(ModStructures.PIECE, 0, makeBox(kind, ox, oy, oz, rot, a, b, c));
		this.kind = kind;
		this.ox = ox;
		this.oy = oy;
		this.oz = oz;
		this.rot = rot;
		this.a = a;
		this.b = b;
		this.c = c;
		this.d = d;
		this.seed = seed;
	}

	public GreyPiece(NbtCompound nbt) {
		super(ModStructures.PIECE, nbt);
		this.kind = nbt.getInt("k");
		this.ox = nbt.getInt("ox");
		this.oy = nbt.getInt("oy");
		this.oz = nbt.getInt("oz");
		this.rot = nbt.getInt("rot");
		this.a = nbt.getInt("a");
		this.b = nbt.getInt("b");
		this.c = nbt.getInt("c");
		this.d = nbt.getInt("d");
		this.seed = nbt.getLong("seed");
	}

	@Override
	protected void writeNbt(StructureContext context, NbtCompound nbt) {
		nbt.putInt("k", kind);
		nbt.putInt("ox", ox);
		nbt.putInt("oy", oy);
		nbt.putInt("oz", oz);
		nbt.putInt("rot", rot);
		nbt.putInt("a", a);
		nbt.putInt("b", b);
		nbt.putInt("c", c);
		nbt.putInt("d", d);
		nbt.putLong("seed", seed);
	}

	// ---------- габариты ----------

	private static int rx(int rot, int lx, int lz) {
		return switch (rot & 3) {
			case 0 -> lx;
			case 1 -> -lz;
			case 2 -> -lx;
			default -> lz;
		};
	}

	private static int rz(int rot, int lx, int lz) {
		return switch (rot & 3) {
			case 0 -> lz;
			case 1 -> lx;
			case 2 -> -lz;
			default -> -lx;
		};
	}

	private static BlockBox makeBox(int kind, int ox, int oy, int oz, int rot, int a, int b, int c) {
		switch (kind) {
			case HOUSE: {
				int hw = a + 1, hd = b + 1;
				int x1 = rx(rot, -hw, -hd), x2 = rx(rot, hw, hd), x3 = rx(rot, -hw, hd), x4 = rx(rot, hw, -hd);
				int z1 = rz(rot, -hw, -hd), z2 = rz(rot, hw, hd), z3 = rz(rot, -hw, hd), z4 = rz(rot, hw, -hd);
				return new BlockBox(
						ox + Math.min(Math.min(x1, x2), Math.min(x3, x4)), oy - 12,
						oz + Math.min(Math.min(z1, z2), Math.min(z3, z4)),
						ox + Math.max(Math.max(x1, x2), Math.max(x3, x4)), oy + c + 6,
						oz + Math.max(Math.max(z1, z2), Math.max(z3, z4)));
			}
			case WELL:
				return new BlockBox(ox - 3, oy - 12, oz - 3, ox + 3, oy + 8, oz + 3);
			case PATH:
				return new BlockBox(Math.min(ox, a) - 2, oy - 24, Math.min(oz, b) - 2,
						Math.max(ox, a) + 2, oy + 24, Math.max(oz, b) + 2);
			case TOWER:
				return new BlockBox(ox - 8, oy - 14, oz - 8, ox + 8, oy + a + 4, oz + 8);
			case PIT:
				return new BlockBox(ox - a - 3, oy - 90, oz - a - 3, ox + a + 3, oy + 14, oz + a + 3);
			case CLEARING:
				return new BlockBox(ox - a - 4, oy - 12, oz - a - 4, ox + a + 4, oy + 40, oz + a + 4);
			case LAIR:
				return new BlockBox(ox - 18, oy - 22, oz - 18, ox + 18, oy + 14, oz + 18);
			case ARENA:
				return new BlockBox(ox - a - 6, oy - 16, oz - a - 6, ox + a + 6, oy + 22, oz + a + 6);
			default:
				return new BlockBox(ox - 12, oy - 10, oz - 12, ox + 12, oy + b + 12, oz + 12);
		}
	}

	// ---------- генерация ----------

	@Override
	public void generate(StructureWorldAccess world, StructureAccessor structureAccessor, ChunkGenerator chunkGenerator,
						 Random random, BlockBox box, ChunkPos chunkPos, BlockPos pivot) {
		// Те же структуры формально «стартуют» и в обычном мире (общий сид и биомы),
		// но блоков там не ставят: они существуют только в Изнанке.
		if (world.toServerWorld().getRegistryKey() != ModDimensions.GREYSIDE) return;

		switch (kind) {
			case HOUSE -> house(world, box);
			case WELL -> well(world, box);
			case PATH -> path(world, box);
			case TOWER -> tower(world, box);
			case PIT -> pit(world, box);
			case CLEARING -> clearing(world, box);
			case TREE -> tree(world, box);
			case LAIR -> lair(world, box);
			case ARENA -> arena(world, box);
			default -> {}
		}
	}

	// ---------- утилиты ----------

	private static long mix(long z) {
		z = (z ^ (z >>> 30)) * 0xBF58476D1CE4E5B9L;
		z = (z ^ (z >>> 27)) * 0x94D049BB133111EBL;
		return z ^ (z >>> 31);
	}

	/** Детерминированное «случайное» число 0..1 для точки. */
	private float rnd(int x, int y, int z, int salt) {
		long h = mix(seed ^ mix(x * 0x9E3779B97F4A7C15L + z * 0xC2B2AE3D27D4EB4FL + y * 0x165667B19E3779F9L + salt));
		return (h >>> 40) / 16777216f;
	}

	private int wx(int lx, int lz) { return ox + rx(rot, lx, lz); }

	private int wz(int lx, int lz) { return oz + rz(rot, lx, lz); }

	/** Локальная сторона (N/E/S/W дома) -> мировая. */
	private Direction dirL(int local) { return CW[(local + rot) & 3]; }

	private static boolean inCol(BlockBox box, int x, int z) {
		return x >= box.getMinX() && x <= box.getMaxX() && z >= box.getMinZ() && z <= box.getMaxZ();
	}

	private static boolean put(StructureWorldAccess w, BlockBox box, int x, int y, int z, BlockState s) {
		if (!box.contains(x, y, z)) return false;
		w.setBlockState(new BlockPos(x, y, z), s, Block.NOTIFY_LISTENERS);
		return true;
	}

	private static BlockState at(StructureWorldAccess w, int x, int y, int z) {
		return w.getBlockState(new BlockPos(x, y, z));
	}

	private static void clear(StructureWorldAccess w, BlockBox box, int x, int y, int z) {
		if (!box.contains(x, y, z)) return;
		if (!at(w, x, y, z).isAir()) w.setBlockState(new BlockPos(x, y, z), AIR, Block.NOTIFY_LISTENERS);
	}

	private static boolean fillable(BlockState s) {
		return s.isAir() || !s.getFluidState().isEmpty() || s.isReplaceable()
				|| s.isIn(BlockTags.LEAVES) || s.isIn(BlockTags.LOGS);
	}

	/** Подпорка вниз, пока под фундаментом пусто. */
	private static void fillDown(StructureWorldAccess w, BlockBox box, int x, int y, int z, BlockState s, int max) {
		for (int i = 0; i < max; i++) {
			int yy = y - i;
			if (yy <= w.getBottomY() || !box.contains(x, yy, z)) return;
			if (!fillable(at(w, x, yy, z))) return;
			w.setBlockState(new BlockPos(x, yy, z), s, Block.NOTIFY_LISTENERS);
		}
	}

	/** Верхний блок настоящей земли (мимо деревьев, травы и воздуха; вода считается землёй). */
	private static int ground(StructureWorldAccess w, int x, int z) {
		int y = w.getTopY(Heightmap.Type.WORLD_SURFACE, x, z) - 1;
		int min = w.getBottomY() + 1;
		while (y > min) {
			BlockState s = at(w, x, y, z);
			boolean soft = s.isAir() || s.isIn(BlockTags.LEAVES) || s.isIn(BlockTags.LOGS)
					|| (s.isReplaceable() && s.getFluidState().isEmpty());
			if (!soft) break;
			y--;
		}
		return y;
	}

	private BlockState wall(float r) {
		if (r < 0.38f) return COBBLE;
		if (r < 0.58f) return MOSSY;
		if (r < 0.78f) return BRICKS;
		if (r < 0.90f) return CRACKED;
		return ANDESITE;
	}

	private BlockState brick(float r) {
		if (r < 0.5f) return BRICKS;
		if (r < 0.8f) return MOSSY_BRICKS;
		return CRACKED;
	}

	private void chest(StructureWorldAccess w, BlockBox box, int x, int y, int z, Direction face, String table) {
		if (!box.contains(x, y, z)) return;
		BlockPos p = new BlockPos(x, y, z);
		w.setBlockState(p, Blocks.CHEST.getDefaultState().with(ChestBlock.FACING, face), Block.NOTIFY_LISTENERS);
		LootableContainerBlockEntity.setLootTable(w, Random.create(mix(seed ^ p.asLong())), p,
				GreysideMod.id("chests/" + table));
	}

	private void barrel(StructureWorldAccess w, BlockBox box, int x, int y, int z, String table) {
		if (!box.contains(x, y, z)) return;
		BlockPos p = new BlockPos(x, y, z);
		w.setBlockState(p, Blocks.BARREL.getDefaultState(), Block.NOTIFY_LISTENERS);
		LootableContainerBlockEntity.setLootTable(w, Random.create(mix(seed ^ p.asLong())), p,
				GreysideMod.id("chests/" + table));
	}

	/** Ставит постоянного моба (не исчезает), только если точка внутри текущего чанка. */
	private void spawn(StructureWorldAccess w, BlockBox box, EntityType<? extends MobEntity> type, int x, int y, int z) {
		if (!box.contains(x, y, z)) return;
		MobEntity m = type.create(w.toServerWorld());
		if (m == null) return;
		BlockPos p = new BlockPos(x, y, z);
		m.refreshPositionAndAngles(x + 0.5, y, z + 0.5, rnd(x, y, z, 77) * 360f, 0f);
		m.setPersistent();
		m.initialize(w, w.getLocalDifficulty(p), SpawnReason.STRUCTURE, null, null);
		w.spawnEntityAndPassengers(m);
	}

	private static void ladder(StructureWorldAccess w, BlockBox box, int x, int y, int z, Direction face) {
		put(w, box, x, y, z, Blocks.LADDER.getDefaultState().with(LadderBlock.FACING, face));
	}

	// ---------- разрушенный дом ----------

	private void house(StructureWorldAccess w, BlockBox box) {
		final int hw = a, hd = b, H = c;
		final float ruin = d / 100f;
		final int base = oy - 1;
		final boolean two = H >= 6;
		final int mid = 4;

		for (int lx = -hw; lx <= hw; lx++) {
			for (int lz = -hd; lz <= hd; lz++) {
				int x = wx(lx, lz), z = wz(lx, lz);
				if (!inCol(box, x, z)) continue;
				boolean edge = Math.abs(lx) == hw || Math.abs(lz) == hd;
				boolean corner = Math.abs(lx) == hw && Math.abs(lz) == hd;

				fillDown(w, box, x, base - 1, z, COBBLE, 10);
				for (int ly = 1; ly <= H + 4; ly++) clear(w, box, x, base + ly, z);

				// пол или цоколь
				if (edge) {
					put(w, box, x, base, z, wall(rnd(x, base, z, 0)));
				} else {
					float f = rnd(x, base, z, 1);
					if (f >= 0.18f) put(w, box, x, base, z, f < 0.8f ? PLANKS : COBBLE);
				}

				if (edge) {
					for (int ly = 1; ly <= H; ly++) {
						if (lz == -hd && lx == 0 && ly <= 2) continue; // дверной проём
						boolean window = ly == 2 && ((lx == hw && lz == 0) || (lz == hd && Math.abs(lx) == 1));
						if (window) continue;
						float p = ruin * (0.25f + 0.22f * (ly - 1));
						if (corner) p *= 0.35f;
						if (rnd(x, base + ly, z, 2) < p) continue; // обвалилось
						put(w, box, x, base + ly, z, corner ? LOG : wall(rnd(x, base + ly, z, 3)));
					}
				} else {
					// паутина под потолком и в углах
					if (rnd(x, base + H, z, 4) < 0.14f) put(w, box, x, base + H, z, COBWEB);
					if (Math.abs(lx) == hw - 1 && Math.abs(lz) == hd - 1 && rnd(x, base + 1, z, 5) < 0.25f)
						put(w, box, x, base + 1, z, COBWEB);
				}

				// второй этаж
				if (two && !edge) {
					boolean ladderCol = lx == -hw + 1 && lz == 0;
					if (!ladderCol && rnd(x, base + mid, z, 6) >= 0.25f + ruin * 0.5f)
						put(w, box, x, base + mid, z, PLANKS);
					if (ladderCol) {
						for (int ly = 1; ly <= mid + 1; ly++) {
							if (ly > 1 && rnd(x, base + ly, z, 7) < 0.12f) continue;
							ladder(w, box, x, base + ly, z, dirL(E));
						}
					}
				}

				// остатки крыши
				if (rnd(x, base + H + 1, z, 8) < 0.62f - 0.6f * ruin) put(w, box, x, base + H + 1, z, PLANKS);
			}
		}

		// содержимое
		if (rnd(ox, 0, oz, 50) < 0.6f)
			chest(w, box, wx(hw - 1, hd - 1), base + 1, wz(hw - 1, hd - 1), dirL(N), "village_house");
		if (rnd(ox, 0, oz, 51) < 0.35f)
			barrel(w, box, wx(-(hw - 1), hd - 1), base + 1, wz(-(hw - 1), hd - 1), "village_house");
		if (rnd(ox, 0, oz, 52) < 0.30f)
			put(w, box, wx(hw - 1, -(hd - 1)), base + 1, wz(hw - 1, -(hd - 1)), Blocks.CAULDRON.getDefaultState());
		if (rnd(ox, 0, oz, 53) < 0.25f)
			put(w, box, wx(-(hw - 1), -(hd - 1)), base + 1, wz(-(hw - 1), -(hd - 1)), Blocks.CRAFTING_TABLE.getDefaultState());
		if (rnd(ox, 0, oz, 55) < 0.40f)
			spawn(w, box, ModEntities.SHADOW, wx(0, 0), base + 1, wz(0, 0));
		if (two && rnd(ox, 0, oz, 56) < 0.35f)
			spawn(w, box, ModEntities.SHADOW, wx(0, 1), base + 1, wz(0, 1));
		if (two && rnd(ox, 0, oz, 54) < 0.7f) {
			int x = wx(hw - 1, hd - 1), z = wz(hw - 1, hd - 1);
			put(w, box, x, base + mid, z, PLANKS);
			chest(w, box, x, base + mid + 1, z, dirL(N), "village_house");
		}
	}

	// ---------- колодец деревни ----------

	private void well(StructureWorldAccess w, BlockBox box) {
		final int base = oy - 1;
		for (int lx = -2; lx <= 2; lx++) {
			for (int lz = -2; lz <= 2; lz++) {
				int x = ox + lx, z = oz + lz;
				if (!inCol(box, x, z)) continue;
				boolean ring = Math.abs(lx) == 2 || Math.abs(lz) == 2;
				boolean corner = Math.abs(lx) == 2 && Math.abs(lz) == 2;
				fillDown(w, box, x, base - 1, z, COBBLE, 10);
				for (int ly = 1; ly <= 5; ly++) clear(w, box, x, base + ly, z);

				if (ring) {
					for (int y = base - 7; y <= base; y++) put(w, box, x, y, z, rnd(x, y, z, 1) < 0.5f ? MOSSY : COBBLE);
					if (rnd(x, base + 1, z, 2) < 0.75f) put(w, box, x, base + 1, z, wall(rnd(x, base + 1, z, 3)));
					if (corner) {
						for (int ly = 2; ly <= 4; ly++) {
							if (rnd(x, base + ly, z, 4) < 0.35f * ly - 0.2f) break;
							put(w, box, x, base + ly, z, LOG);
						}
					}
				} else {
					for (int y = base - 3; y <= base; y++) put(w, box, x, y, z, AIR);
					put(w, box, x, base - 7, z, COBBLE);
					put(w, box, x, base - 6, z, COBBLE);
					put(w, box, x, base - 5, z, Blocks.WATER.getDefaultState());
					put(w, box, x, base - 4, z, Blocks.WATER.getDefaultState());
				}
			}
		}
	}

	// ---------- тропинки ----------

	private void path(StructureWorldAccess w, BlockBox box) {
		int dx = a - ox, dz = b - oz;
		int n = Math.max(Math.abs(dx), Math.abs(dz));
		if (n == 0) return;
		boolean alongX = Math.abs(dx) >= Math.abs(dz);
		for (int i = 0; i <= n; i++) {
			int px = ox + (int) Math.round(dx * (double) i / n);
			int pz = oz + (int) Math.round(dz * (double) i / n);
			for (int k = 0; k < 2; k++) {
				int x = px + (alongX ? 0 : k);
				int z = pz + (alongX ? k : 0);
				if (!inCol(box, x, z)) continue;
				int g = ground(w, x, z);
				BlockState s = at(w, x, g, z);
				if (!(s.isIn(BlockTags.DIRT) || s.isIn(BlockTags.SAND))) continue;
				float f = rnd(x, 0, z, 1);
				BlockState p = f < 0.4f ? COARSE : (f < 0.7f ? Blocks.GRAVEL.getDefaultState() : Blocks.DIRT_PATH.getDefaultState());
				put(w, box, x, g, z, p);
				if (at(w, x, g + 1, z).isReplaceable()) put(w, box, x, g + 1, z, AIR);
			}
		}
	}

	// ---------- одинокая башня ----------

	private int towerWallHeight(int x, int z) {
		float n = rnd(x >> 1, 0, z >> 1, 5);
		return Math.max(3, a - (int) (n * n * 9));
	}

	private void tower(StructureWorldAccess w, BlockBox box) {
		final int H = a;
		final int base = oy - 1;
		final int floor1 = 5, floor2 = 10;

		for (int lx = -7; lx <= 7; lx++) {
			for (int lz = -7; lz <= 7; lz++) {
				int x = ox + lx, z = oz + lz;
				if (!inCol(box, x, z)) continue;
				int d2 = lx * lx + lz * lz;

				if (d2 > 20) {
					// россыпь камней вокруг
					if (d2 <= 49 && rnd(x, 0, z, 1) < 0.10f) {
						int g = ground(w, x, z);
						if (at(w, x, g + 1, z).isAir() || at(w, x, g + 1, z).isReplaceable())
							put(w, box, x, g + 1, z, rnd(x, 1, z, 2) < 0.6f ? COBBLE : MOSSY);
					}
					continue;
				}

				boolean wall = d2 >= 12;
				fillDown(w, box, x, base - 1, z, COBBLE, 12);
				for (int ly = 1; ly <= H + 3; ly++) clear(w, box, x, base + ly, z);

				if (wall) {
					put(w, box, x, base, z, brick(rnd(x, base, z, 3)));
					int hc = towerWallHeight(x, z);
					for (int ly = 1; ly <= hc; ly++) {
						if (lz > 0 && lx == 0 && ly <= 2) continue; // дверь
						boolean slit = (ly == 7 || ly == 12) && ((lx == 0 && lz == -4) || (lz == 0 && Math.abs(lx) == 4));
						if (slit) continue;
						if (rnd(x, base + ly, z, 4) < 0.05f + 0.012f * ly) continue;
						put(w, box, x, base + ly, z, rnd(x, base + ly, z, 5) < 0.55f ? brick(rnd(x, base + ly, z, 6)) : wall(rnd(x, base + ly, z, 7)));
					}
				} else {
					put(w, box, x, base, z, rnd(x, base, z, 8) < 0.5f ? MOSSY_BRICKS : COBBLE);
					boolean ladderCol = lx == 0 && lz == -3;
					if (!ladderCol) {
						if (H > floor1 && rnd(x, base + floor1, z, 9) < 0.72f) put(w, box, x, base + floor1, z, PLANKS);
						if (H > floor2 + 2 && rnd(x, base + floor2, z, 10) < 0.55f) put(w, box, x, base + floor2, z, PLANKS);
					}
					for (int ly = 1; ly <= H; ly++) {
						if (!ladderCol && rnd(x, base + ly, z, 11) < 0.045f) put(w, box, x, base + ly, z, COBWEB);
					}
				}
			}
		}

		// лестница вдоль северной стены
		int lh = towerWallHeight(ox, oz - 4);
		for (int ly = 1; ly <= Math.min(H - 1, lh); ly++) {
			if (ly > 2 && rnd(ox, base + ly, oz, 12) < 0.07f) continue;
			ladder(w, box, ox, base + ly, oz - 3, Direction.SOUTH);
		}

		// добыча: внизу и на этаже
		chest(w, box, ox + 2, base + 1, oz - 2, Direction.WEST, "tower");
		if (H > floor1) {
			put(w, box, ox - 2, base + floor1, oz + 2, PLANKS);
			chest(w, box, ox - 2, base + floor1 + 1, oz + 2, Direction.EAST, "tower");
		}
		spawn(w, box, ModEntities.SILHOUETTE, ox - 2, base + 1, oz + 1);
		if (H > floor1 && rnd(ox, 0, oz, 61) < 0.5f)
			spawn(w, box, ModEntities.SILHOUETTE, ox + 1, base + floor1 + 1, oz - 1);
		if (H > floor2 + 2 && rnd(ox, 0, oz, 60) < 0.5f) {
			put(w, box, ox + 2, base + floor2, oz + 2, PLANKS);
			chest(w, box, ox + 2, base + floor2 + 1, oz + 2, Direction.WEST, "tower");
		}
	}

	// ---------- яма с колодцем ----------

	private void pit(StructureWorldAccess w, BlockBox box) {
		final int R = a;
		final int base = oy - 1;
		final int floor0 = base - 5;

		// воронка
		for (int lx = -(R + 1); lx <= R + 1; lx++) {
			for (int lz = -(R + 1); lz <= R + 1; lz++) {
				int x = ox + lx, z = oz + lz;
				if (!inCol(box, x, z)) continue;
				double r = Math.sqrt(lx * lx + lz * lz);
				if (r > R + 0.5) continue;

				int depth;
				if (r < 3.2) depth = 5;
				else depth = Math.max(0, Math.round((float) (5 * (1 - r / R)) + (rnd(x, 0, z, 1) - 0.5f) * 1.2f));
				int g = ground(w, x, z);
				int floorY = base - depth;

				if (g > floorY) {
					int top = w.getTopY(Heightmap.Type.WORLD_SURFACE, x, z);
					for (int y = floorY + 1; y < top; y++) clear(w, box, x, y, z);
					float f = rnd(x, 0, z, 2);
					BlockState s = f < 0.35f ? COARSE : (f < 0.6f ? MOSSY : (f < 0.8f ? PODZOL : Blocks.GRAVEL.getDefaultState()));
					put(w, box, x, floorY, z, s);
				} else if (r > R - 2 && rnd(x, 0, z, 3) < 0.22f) {
					put(w, box, x, g + 1, z, rnd(x, 1, z, 4) < 0.5f ? BRICKS : MOSSY_BRICKS);
				}
			}
		}

		// шахта колодца
		final int yBot = Math.max(floor0 - b, w.getBottomY() + 10);

		for (int lx = -4; lx <= 4; lx++) {
			for (int lz = -4; lz <= 4; lz++) {
				int x = ox + lx, z = oz + lz;
				if (!inCol(box, x, z)) continue;
				int ax = Math.abs(lx), az = Math.abs(lz);
				boolean shaft = ax <= 1 && az <= 1;
				boolean liningRing = Math.max(ax, az) == 2;
				boolean chamber = ax <= 3 && az <= 3;
				boolean chamberWall = Math.max(ax, az) == 4;

				// камера внизу
				if (chamber) {
					put(w, box, x, yBot - 3, z, BRICKS);
					if (shaft) {
						put(w, box, x, yBot - 2, z, Blocks.WATER.getDefaultState());
						put(w, box, x, yBot - 1, z, Blocks.WATER.getDefaultState());
					} else {
						put(w, box, x, yBot - 2, z, BRICKS);
						put(w, box, x, yBot - 1, z, rnd(x, yBot, z, 5) < 0.5f ? brick(rnd(x, yBot, z, 6)) : COBBLE);
					}
					for (int y = yBot; y <= yBot + 3; y++) put(w, box, x, y, z, AIR);
					if (!shaft) {
						put(w, box, x, yBot + 4, z, rnd(x, yBot + 4, z, 7) < 0.92f ? brick(rnd(x, yBot, z, 8)) : AIR);
					}
				} else if (chamberWall) {
					for (int y = yBot - 3; y <= yBot + 4; y++) put(w, box, x, y, z, brick(rnd(x, y, z, 9)));
				}

				// сама шахта
				if (shaft) {
					for (int y = yBot + 4; y <= floor0; y++) put(w, box, x, y, z, AIR);
				}
				if (liningRing) {
					for (int y = yBot + 5; y <= floor0 - 1; y++) put(w, box, x, y, z, brick(rnd(x, y, z, 10)));
					// оголовок колодца
					put(w, box, x, floor0, z, brick(rnd(x, floor0, z, 11)));
					if (rnd(x, floor0 + 1, z, 12) < 0.8f) put(w, box, x, floor0 + 1, z, brick(rnd(x, floor0 + 1, z, 13)));
					if (rnd(x, floor0 + 2, z, 14) < 0.35f) put(w, box, x, floor0 + 2, z, MOSSY_BRICKS);
				}
			}
		}

		// лестница с дырами
		for (int y = yBot + 4; y <= floor0 - 1; y++) {
			if (y > yBot + 6 && rnd(ox, y, oz, 20) < 0.13f) continue;
			ladder(w, box, ox, y, oz - 1, Direction.SOUTH);
		}

		// ниша с сундуком на полпути
		int ny = floor0 - Math.max(6, (floor0 - yBot) / 2);
		if (ny > yBot + 6) {
			put(w, box, ox + 1, ny - 1, oz, BRICKS);
			put(w, box, ox + 1, ny - 1, oz - 1, BRICKS);
			put(w, box, ox + 2, ny, oz, AIR);
			put(w, box, ox + 2, ny + 1, oz, AIR);
			put(w, box, ox + 3, ny - 1, oz, COBBLE);
			put(w, box, ox + 3, ny + 1, oz, COBBLE);
			put(w, box, ox + 4, ny, oz, COBBLE);
			chest(w, box, ox + 3, ny, oz, Direction.WEST, "pit");
		}

		// колонны и добыча в камере
		for (int sx = -1; sx <= 1; sx += 2) {
			for (int sz = -1; sz <= 1; sz += 2) {
				for (int y = yBot; y <= yBot + 3; y++) put(w, box, ox + 2 * sx, y, oz + 2 * sz, rnd(ox, y, oz + sx, 15 + sz) < 0.85f ? brick(0.1f) : AIR);
				if (rnd(ox + sx, yBot, oz + sz, 16) < 0.5f) put(w, box, ox + 3 * sx, yBot + 3, oz + 3 * sz, COBWEB);
			}
		}
		chest(w, box, ox - 3, yBot, oz - 3, Direction.SOUTH, "pit");
		chest(w, box, ox + 3, yBot, oz + 3, Direction.NORTH, "pit");
		barrel(w, box, ox + 3, yBot, oz - 3, "pit");
		spawn(w, box, ModEntities.LISTENER, ox + 2, yBot, oz);
		if (rnd(ox, 0, oz, 70) < 0.35f) spawn(w, box, ModEntities.LISTENER, ox - 2, yBot, oz);
	}

	// ---------- поляна ----------

	private void clearing(StructureWorldAccess w, BlockBox box) {
		final int R = a;
		for (int lx = -(R + 3); lx <= R + 3; lx++) {
			for (int lz = -(R + 3); lz <= R + 3; lz++) {
				int x = ox + lx, z = oz + lz;
				if (!inCol(box, x, z)) continue;
				double r = Math.sqrt(lx * lx + lz * lz);
				double rr = R * (0.8 + 0.35 * rnd(x >> 2, 0, z >> 2, 9));
				if (r > rr) continue;

				int g = ground(w, x, z);
				BlockState gs = at(w, x, g, z);
				if (!gs.getFluidState().isEmpty()) continue;

				int top = w.getTopY(Heightmap.Type.WORLD_SURFACE, x, z);
				for (int y = g + 1; y < top; y++) clear(w, box, x, y, z);

				if (gs.isOf(Blocks.GRASS_BLOCK) || gs.isOf(Blocks.DIRT)) {
					float f = rnd(x, 0, z, 10);
					BlockState s = f < 0.35f ? PODZOL : (f < 0.6f ? COARSE : gs);
					if (s != gs) put(w, box, x, g, z, s);
					if (s != gs && rnd(x, 1, z, 11) < 0.07f) put(w, box, x, g + 1, z, Blocks.DEAD_BUSH.getDefaultState());
				}
			}
		}
	}

	// ---------- Логово Безликого ----------

	private BlockState dark(float r) {
		if (r < 0.45f) return Blocks.POLISHED_BLACKSTONE_BRICKS.getDefaultState();
		if (r < 0.70f) return Blocks.CRACKED_POLISHED_BLACKSTONE_BRICKS.getDefaultState();
		if (r < 0.90f) return Blocks.DEEPSLATE_BRICKS.getDefaultState();
		return Blocks.CRACKED_DEEPSLATE_BRICKS.getDefaultState();
	}

	/** Постоянный Безликий, привязанный к логову. На мирной сложности пропадёт сам (как любой враждебный). */
	private void spawnLairFaceless(StructureWorldAccess w, BlockBox box, int x, int y, int z, BlockPos chestPos) {
		if (!box.contains(x, y, z)) return;
		FacelessEntity f = ModEntities.FACELESS.create(w.toServerWorld());
		if (f == null) return;
		BlockPos p = new BlockPos(x, y, z);
		f.refreshPositionAndAngles(x + 0.5, y, z + 0.5, rnd(x, y, z, 78) * 360f, 0f);
		f.setPersistent();
		f.setLair(p, chestPos);
		f.initialize(w, w.getLocalDifficulty(p), SpawnReason.STRUCTURE, null, null);
		w.spawnEntityAndPassengers(f);
	}

	/**
	 * Зал радиусом 6 под землёй, потолок под слоем породы. Вход: лестница на 9 блоков вниз по локальной оси -z
	 * (первые 6 ступеней открытой траншеей, последние 3 крытым ходом). Все координаты локальные, поворот rot.
	 * oy - 1 = верхний блок земли, пол зала на 10 ниже, потолок на 7 выше пола.
	 */
	private void lair(StructureWorldAccess w, BlockBox box) {
		final int base = oy - 1;
		final int y0 = base - 10;
		final BlockState deep = Blocks.DEEPSLATE_BRICKS.getDefaultState();

		// --- зал: пол, стены, потолок
		for (int lx = -8; lx <= 8; lx++) {
			for (int lz = -8; lz <= 8; lz++) {
				int x = wx(lx, lz), z = wz(lx, lz);
				if (!inCol(box, x, z)) continue;
				int d2 = lx * lx + lz * lz;
				if (d2 > 56) continue;

				fillDown(w, box, x, y0 - 1, z, deep, 8);
				if (d2 <= 36) {
					float f = rnd(x, y0, z, 1);
					BlockState floor;
					if (d2 <= 1) floor = Blocks.CHISELED_POLISHED_BLACKSTONE.getDefaultState();
					else if (d2 >= 9 && d2 <= 12) floor = Blocks.CHISELED_POLISHED_BLACKSTONE.getDefaultState();
					else if (f < 0.5f) floor = Blocks.POLISHED_BLACKSTONE.getDefaultState();
					else if (f < 0.8f) floor = Blocks.DEEPSLATE_TILES.getDefaultState();
					else floor = Blocks.CRACKED_DEEPSLATE_TILES.getDefaultState();
					put(w, box, x, y0, z, floor);
					for (int y = y0 + 1; y <= y0 + 6; y++) clear(w, box, x, y, z);
					put(w, box, x, y0 + 7, z, dark(rnd(x, y0 + 7, z, 2)));
					if (rnd(x, y0 + 6, z, 3) < 0.06f) put(w, box, x, y0 + 6, z, COBWEB);
					if (rnd(x, y0 + 1, z, 4) < 0.03f) put(w, box, x, y0 + 1, z, COBWEB);
				} else {
					for (int y = y0; y <= y0 + 7; y++) put(w, box, x, y, z, dark(rnd(x, y, z, 5)));
				}
			}
		}

		// --- колонны
		final int[][] pillars = {{3, 3}, {3, -3}, {-3, 3}, {-3, -3}, {4, 0}, {-4, 0}};
		for (int[] pc : pillars) {
			int x = wx(pc[0], pc[1]), z = wz(pc[0], pc[1]);
			for (int ly = 1; ly <= 6; ly++) {
				if (ly >= 4 && rnd(x, y0 + ly, z, 20) < 0.22f * (ly - 3)) {
					if (rnd(x, y0 + ly, z, 21) < 0.5f) put(w, box, x, y0 + ly, z, Blocks.SKELETON_SKULL.getDefaultState());
					break;
				}
				put(w, box, x, y0 + ly, z, dark(rnd(x, y0 + ly, z, 22)));
			}
		}

		// --- лица на стенах: резные тыквы, повёрнутые к центру
		for (int lx = -6; lx <= 6; lx++) {
			for (int lz = -6; lz <= 6; lz++) {
				int d2 = lx * lx + lz * lz;
				if (d2 < 29 || d2 > 36) continue;
				if (Math.abs(lx) <= 1 && lz <= -5) continue; // дверь
				if (Math.abs(lx) <= 2 && lz >= 4) continue;  // помост
				int x = wx(lx, lz), z = wz(lx, lz);
				int toCenter = Math.abs(lx) > Math.abs(lz) ? (lx > 0 ? W : E) : (lz > 0 ? N : S);
				BlockState face = Blocks.CARVED_PUMPKIN.getDefaultState().with(CarvedPumpkinBlock.FACING, dirL(toCenter));
				if (rnd(x, y0 + 3, z, 30) < 0.30f) put(w, box, x, y0 + 3, z, face);
				if (rnd(x, y0 + 4, z, 31) < 0.12f) put(w, box, x, y0 + 4, z, face);
			}
		}

		// --- подвесные фонари (гаснут, когда он рядом)
		final int[][] lamps = {{2, 3}, {-2, 3}, {2, -3}, {-2, -3}};
		for (int[] lc : lamps) {
			put(w, box, wx(lc[0], lc[1]), y0 + 6, wz(lc[0], lc[1]),
					Blocks.SOUL_LANTERN.getDefaultState().with(LanternBlock.HANGING, true));
		}

		// --- помост и сундук
		for (int lx = -2; lx <= 2; lx++) {
			for (int lz = 4; lz <= 5; lz++) {
				put(w, box, wx(lx, lz), y0 + 1, wz(lx, lz), Blocks.POLISHED_BLACKSTONE_BRICKS.getDefaultState());
			}
		}
		final int chestX = wx(0, 5), chestZ = wz(0, 5), chestY = y0 + 2;
		chest(w, box, chestX, chestY, chestZ, dirL(N), "lair");

		// --- вход: лестница вниз
		for (int j = 0; j <= 9; j++) {
			int lz = -16 + j;
			int feet = base - j;
			boolean covered = j >= 6;
			for (int lx = -2; lx <= 2; lx++) {
				int x = wx(lx, lz), z = wz(lx, lz);
				if (!inCol(box, x, z)) continue;
				boolean side = Math.abs(lx) == 2;
				if (side) {
					int topWall = covered ? feet + 3 : Math.max(base, feet + 1);
					for (int y = feet - 1; y <= topWall; y++) put(w, box, x, y, z, dark(rnd(x, y, z, 40)));
					continue;
				}
				fillDown(w, box, x, feet - 2, z, deep, 4);
				if (covered) {
					for (int y = feet; y <= feet + 2; y++) clear(w, box, x, y, z);
					put(w, box, x, feet + 3, z, dark(rnd(x, feet + 3, z, 41)));
				} else {
					int top = w.getTopY(Heightmap.Type.WORLD_SURFACE, x, z);
					for (int y = feet; y < Math.max(top, base + 4); y++) clear(w, box, x, y, z);
				}
				// ступень (последняя вровень с полом зала)
				if (j < 9) {
					put(w, box, x, feet - 1, z, Blocks.STONE_BRICK_STAIRS.getDefaultState()
							.with(net.minecraft.block.StairsBlock.FACING, dirL(N)));
				} else {
					put(w, box, x, feet - 1, z, dark(rnd(x, feet - 1, z, 42)));
				}
			}
		}
		// проём в стене зала
		for (int lx = -1; lx <= 1; lx++) {
			for (int y = y0 + 1; y <= y0 + 3; y++) clear(w, box, wx(lx, -6), y, wz(lx, -6));
		}

		// --- врата на поверхности: два столба, перемычка и лицо над входом
		for (int sx = -2; sx <= 2; sx += 4) {
			int x = wx(sx, -16), z = wz(sx, -16);
			for (int y = base + 1; y <= base + 3; y++) put(w, box, x, y, z, dark(rnd(x, y, z, 43)));
		}
		for (int lx = -2; lx <= 2; lx++) {
			put(w, box, wx(lx, -16), base + 3, wz(lx, -16), dark(rnd(lx, base + 3, 0, 44)));
		}
		put(w, box, wx(0, -16), base + 4, wz(0, -16),
				Blocks.CARVED_PUMPKIN.getDefaultState().with(CarvedPumpkinBlock.FACING, dirL(N)));

		// --- хозяин: стоит в зале лицом ко входу, пока никого нет
		spawnLairFaceless(w, box, wx(0, 1), y0 + 1, wz(0, 1), new BlockPos(chestX, chestY, chestZ));
	}

	// ---------- Арена Иона ----------

	/**
	 * Большая чёрная арена радиусом a (32) с троном в центре. Локальные оси: вход с южной стороны (+z),
	 * трон смотрит на вход (сидящий смотрит на +z). oy - 1 = уровень пола; рельеф срезается и подсыпается.
	 * Три постамента масок (MaskPedestalBlock) по кругу: Безмолвия, Наблюдателя, Пустоты.
	 */
	private void arena(StructureWorldAccess w, BlockBox box) {
		final int R = a;
		final int base = oy - 1;
		final BlockState bs = Blocks.BLACKSTONE.getDefaultState();
		final BlockState pb = Blocks.POLISHED_BLACKSTONE.getDefaultState();
		final BlockState pbb = Blocks.POLISHED_BLACKSTONE_BRICKS.getDefaultState();
		final BlockState chi = Blocks.CHISELED_POLISHED_BLACKSTONE.getDefaultState();
		final BlockState cracked = Blocks.CRACKED_POLISHED_BLACKSTONE_BRICKS.getDefaultState();
		final BlockState tiles = Blocks.DEEPSLATE_TILES.getDefaultState();
		final BlockState stairs = Blocks.POLISHED_BLACKSTONE_BRICK_STAIRS.getDefaultState();
		final BlockState slab = Blocks.POLISHED_BLACKSTONE_BRICK_SLAB.getDefaultState();
		final BlockState lantern = Blocks.SOUL_LANTERN.getDefaultState().with(LanternBlock.HANGING, false);

		// --- пол, срез рельефа, подсыпка, стена по краю
		for (int lx = -R - 5; lx <= R + 5; lx++) {
			for (int lz = -R - 5; lz <= R + 5; lz++) {
				int x = wx(lx, lz), z = wz(lx, lz);
				if (!inCol(box, x, z)) continue;
				int d2 = lx * lx + lz * lz;
				boolean apron = lz > R - 3 && lz <= R + 4 && Math.abs(lx) <= 3;
				boolean disk = d2 <= (R + 0.2) * (R + 0.2);
				if (!disk && !apron) continue;

				double r = Math.sqrt(d2);
				BlockState floor;
				if (apron) {
					floor = pb;
				} else if ((r >= 10 && r < 11) || (r >= 20 && r < 21) || (r >= 29 && r < 30)) {
					floor = pbb;
				} else if (lx == 0 || lz == 0 || Math.abs(lx) == Math.abs(lz)) {
					floor = pb;
				} else {
					float f = rnd(x, base, z, 60);
					floor = f < 0.08f ? cracked : (f < 0.15f ? tiles : bs);
				}
				fillDown(w, box, x, base - 1, z, bs, 14);
				put(w, box, x, base, z, floor);
				for (int y = base + 1; y <= base + 20; y++) clear(w, box, x, y, z);

				// стена по краю, в южной стороне проход шириной 7
				boolean gate = lz > 0 && Math.abs(lx) <= 3;
				if (!apron && !gate && r >= R - 1.8 && r <= R + 0.2) {
					for (int y = base + 1; y <= base + 3; y++) put(w, box, x, y, z, pbb);
					put(w, box, x, base + 4, z, slab);
				}
			}
		}

		// --- помост трона: два яруса и лестницы с четырёх сторон (подъём к центру)
		for (int lx = -7; lx <= 7; lx++) {
			for (int lz = -7; lz <= 7; lz++) {
				int d2 = lx * lx + lz * lz;
				int x = wx(lx, lz), z = wz(lx, lz);
				if (d2 <= 52) put(w, box, x, base + 1, z, pbb);
				if (d2 <= 21) put(w, box, x, base + 2, z, pb);
			}
		}
		for (int k = -1; k <= 1; k++) {
			put(w, box, wx(k, -7), base + 1, wz(k, -7), stairs.with(net.minecraft.block.StairsBlock.FACING, dirL(S)));
			put(w, box, wx(k, 7), base + 1, wz(k, 7), stairs.with(net.minecraft.block.StairsBlock.FACING, dirL(N)));
			put(w, box, wx(-7, k), base + 1, wz(-7, k), stairs.with(net.minecraft.block.StairsBlock.FACING, dirL(E)));
			put(w, box, wx(7, k), base + 1, wz(7, k), stairs.with(net.minecraft.block.StairsBlock.FACING, dirL(W)));
			put(w, box, wx(k, -4), base + 2, wz(k, -4), stairs.with(net.minecraft.block.StairsBlock.FACING, dirL(S)));
			put(w, box, wx(k, 4), base + 2, wz(k, 4), stairs.with(net.minecraft.block.StairsBlock.FACING, dirL(N)));
			put(w, box, wx(-4, k), base + 2, wz(-4, k), stairs.with(net.minecraft.block.StairsBlock.FACING, dirL(E)));
			put(w, box, wx(4, k), base + 2, wz(4, k), stairs.with(net.minecraft.block.StairsBlock.FACING, dirL(W)));
		}

		// --- трон: сиденье, высокая спинка с севера, подлокотники
		final int ty = base + 3;
		put(w, box, wx(0, 0), ty, wz(0, 0), stairs.with(net.minecraft.block.StairsBlock.FACING, dirL(N)));
		for (int lx = -1; lx <= 1; lx++) {
			for (int y = ty; y <= ty + 3; y++) put(w, box, wx(lx, -1), y, wz(lx, -1), pbb);
		}
		for (int y = ty + 4; y <= ty + 5; y++) put(w, box, wx(0, -1), y, wz(0, -1), pbb);
		put(w, box, wx(0, -1), ty + 6, wz(0, -1), Blocks.CRYING_OBSIDIAN.getDefaultState());
		put(w, box, wx(-1, -1), ty + 4, wz(-1, -1), chi);
		put(w, box, wx(1, -1), ty + 4, wz(1, -1), chi);
		put(w, box, wx(-2, -1), ty, wz(-2, -1), chi);
		put(w, box, wx(2, -1), ty, wz(2, -1), chi);
		put(w, box, wx(-1, 0), ty, wz(-1, 0), slab);
		put(w, box, wx(1, 0), ty, wz(1, 0), slab);

		// --- три постамента масок по кругу, радиус 13
		final int[] angles = {-90, 30, 150};
		final MaskPedestalBlock.Slot[] slots = MaskPedestalBlock.Slot.values();
		for (int i = 0; i < angles.length; i++) {
			int lx = (int) Math.round(13 * Math.cos(Math.toRadians(angles[i])));
			int lz = (int) Math.round(13 * Math.sin(Math.toRadians(angles[i])));
			int x = wx(lx, lz), z = wz(lx, lz);
			put(w, box, x, base + 1, z, pbb);
			put(w, box, x, base + 2, z, ModBlocks.MASK_PEDESTAL.getDefaultState().with(MaskPedestalBlock.KIND, slots[i]));
		}

		// --- 12 колонн по кольцу, радиус 27, с фонарём на верхушке
		for (int i = 0; i < 12; i++) {
			double ang = Math.toRadians(i * 30 + 15);
			int lx = (int) Math.round(27 * Math.cos(ang));
			int lz = (int) Math.round(27 * Math.sin(ang));
			for (int dx = -1; dx <= 1; dx++) {
				for (int dz = -1; dz <= 1; dz++) {
					int x = wx(lx + dx, lz + dz), z = wz(lx + dx, lz + dz);
					put(w, box, x, base + 1, z, chi);
					put(w, box, x, base + 2, z, pbb);
					put(w, box, x, base + 11, z, chi);
				}
			}
			int cx = wx(lx, lz), cz = wz(lx, lz);
			for (int y = base + 3; y <= base + 10; y++) put(w, box, cx, y, cz, dark(rnd(cx, y, cz, 61)));
			put(w, box, cx, base + 12, cz, lantern);
		}
	}

	// ---------- Тёмное Древо ----------

	private static boolean airy(BlockState s) {
		return s.isAir() || s.isReplaceable() || s.isIn(BlockTags.LEAVES);
	}

	private void tree(StructureWorldAccess w, BlockBox box) {
		final int t = a, h = b;
		final int base = oy - 1;
		final int taper = (int) (h * 0.72f);

		// ствол: толстый внизу, выше тонкая «свеча»
		for (int dx = 0; dx < t; dx++) {
			for (int dz = 0; dz < t; dz++) {
				int x = ox + dx, z = oz + dz;
				if (!inCol(box, x, z)) continue;
				fillDown(w, box, x, base - 1, z, WOOD, 8);
				int top = (dx == 0 && dz == 0) ? h : taper;
				for (int y = base; y <= base + top; y++) put(w, box, x, y, z, WOOD);
			}
		}
		for (int y = base + h + 1; y <= base + h + 2; y++) put(w, box, ox, y, oz, WOOD);

		// корни по четырём сторонам
		int[][] rootStart = {{ox + t - 1, oz + t - 1, 1, 0}, {ox, oz + t - 1, 0, 1}, {ox, oz, -1, 0}, {ox + t - 1, oz, 0, -1}};
		for (int k = 0; k < 4; k++) {
			int len = (t == 3 ? 3 : 2) + (rnd(ox, k, oz, 20 + k) < 0.5f ? 1 : 0);
			for (int i = 1; i <= len; i++) {
				int x = rootStart[k][0] + rootStart[k][2] * i;
				int z = rootStart[k][1] + rootStart[k][3] * i;
				int y = base + Math.max(0, 3 - i);
				if (!inCol(box, x, z)) continue;
				BlockState cur = at(w, x, y, z);
				if (airy(cur) || cur.isIn(BlockTags.DIRT)) put(w, box, x, y, z, WOOD);
			}
		}

		// ветви
		int nb = 3 + (t == 3 ? 3 : 0) + (int) (rnd(ox, 0, oz, 30) * 3);
		for (int k = 0; k < nb; k++) {
			int sy = base + (int) (h * (0.42f + 0.5f * rnd(ox, k, oz, 31)));
			int sx = ox, sz = oz;
			if (sy - base <= taper) {
				sx = ox + (int) (rnd(ox, k, oz, 32) * t);
				sz = oz + (int) (rnd(ox, k, oz, 33) * t);
			}
			int dir = (int) (rnd(ox, k, oz, 34) * 8) & 7;
			int len = (t == 3 ? 6 : 4) + (int) (rnd(ox, k, oz, 35) * 4);
			int x = sx, y = sy, z = sz;
			for (int i = 1; i <= len; i++) {
				x += DX[dir];
				z += DZ[dir];
				if (i % 2 == 0 || rnd(ox, k * 16 + i, oz, 36) < 0.25f) y++;
				if (inCol(box, x, z) && airy(at(w, x, y, z))) put(w, box, x, y, z, WOOD);
				if (i == len / 2 && rnd(ox, k, oz, 37) < 0.7f) {
					int pd = (dir + 2) & 7;
					for (int j = 1; j <= 2; j++) put(w, box, x + DX[pd] * j, y + j - 1, z + DZ[pd] * j, WOOD);
				}
			}
			if (rnd(ox, k, oz, 38) < 0.4f && box.contains(x, y - 1, z) && at(w, x, y - 1, z).isAir())
				put(w, box, x, y - 1, z, COBWEB);
		}

		// сундук, спрятанный между корнями
		if (c == 1) chest(w, box, ox - 1, base + 1, oz - 1, Direction.NORTH, "grove");
	}
}

package com.greyside;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;

public final class ModItems {
	public static final Item RIFT_HOE = register("rift_hoe", new RiftHoeItem(new FabricItemSettings().maxCount(1)));
	public static final Item GREY_DUST = register("grey_dust", new Item(new FabricItemSettings()));
	public static final Item VOID_SHARD = register("void_shard", new Item(new FabricItemSettings()));
	public static final Item GREY_BLADE = register("grey_blade",
			new SwordItem(GreyToolMaterial.INSTANCE, 3, -2.4f, new FabricItemSettings()));

	public static final Item MASK_SILENCE = register("mask_silence", new MaskItem(MaskItem.Kind.SILENCE, new FabricItemSettings()));
	public static final Item MASK_WATCHER = register("mask_watcher", new MaskItem(MaskItem.Kind.WATCHER, new FabricItemSettings()));
	public static final Item MASK_VOID = register("mask_void", new MaskItem(MaskItem.Kind.VOID, new FabricItemSettings()));

	public static final Item MASK_ION = register("mask_ion", new MaskItem(MaskItem.Kind.ION, new FabricItemSettings()));
	public static final Item ION_CHISEL = register("ion_chisel", new IonChiselItem(new FabricItemSettings().maxCount(1)));

	public static final Item GREY_COMPASS = register("grey_compass", new GreyCompassItem(new FabricItemSettings().maxCount(1)));

	private static Item register(String name, Item item) {
		return Registry.register(Registries.ITEM, GreysideMod.id(name), item);
	}

	/** Отдельная вкладка креатива со всеми предметами мода. */
	public static final ItemGroup GREYSIDE_GROUP = Registry.register(Registries.ITEM_GROUP, GreysideMod.id("main"),
			FabricItemGroup.builder()
					.icon(() -> new ItemStack(VOID_SHARD))
					.displayName(Text.translatable("itemGroup.greyside.main"))
					.entries((context, entries) -> {
						entries.add(ModBlocks.DAWN_ALTAR);
						entries.add(ModBlocks.ANCHOR);
						entries.add(ModBlocks.RIFT);
						entries.add(RIFT_HOE);
						entries.add(GREY_COMPASS);
						entries.add(GREY_BLADE);
						entries.add(MASK_SILENCE);
						entries.add(MASK_WATCHER);
						entries.add(MASK_VOID);
						entries.add(MASK_ION);
						entries.add(ION_CHISEL);
						entries.add(ModBlocks.ION_HEAD);
						entries.add(GREY_DUST);
						entries.add(VOID_SHARD);
					})
					.build());

	public static void init() {
		ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> e.add(RIFT_HOE));
		ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> e.add(GREY_COMPASS));
		GreyCompassItem.initTicker();
		ItemGroupEvents.modifyEntriesEvent(ItemGroups.FUNCTIONAL).register(e -> {
			e.add(ModBlocks.DAWN_ALTAR);
			e.add(ModBlocks.ANCHOR);
		});
		ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(e -> {
			e.add(GREY_BLADE);
			e.add(MASK_SILENCE);
			e.add(MASK_WATCHER);
			e.add(MASK_VOID);
			e.add(MASK_ION);
			e.add(ION_CHISEL);
		});
		ItemGroupEvents.modifyEntriesEvent(ItemGroups.INGREDIENTS).register(e -> {
			e.add(GREY_DUST);
			e.add(VOID_SHARD);
		});
	}

	private ModItems() {}
}

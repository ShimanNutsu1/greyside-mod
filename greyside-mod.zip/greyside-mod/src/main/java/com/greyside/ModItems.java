package com.greyside;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SwordItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public final class ModItems {
	public static final Item RIFT_HOE = register("rift_hoe", new RiftHoeItem(new FabricItemSettings().maxCount(1)));
	public static final Item GREY_DUST = register("grey_dust", new Item(new FabricItemSettings()));
	public static final Item VOID_SHARD = register("void_shard", new Item(new FabricItemSettings()));
	public static final Item GREY_BLADE = register("grey_blade",
			new SwordItem(GreyToolMaterial.INSTANCE, 3, -2.4f, new FabricItemSettings()));

	public static final Item MASK_SILENCE = register("mask_silence", new MaskItem(MaskItem.Kind.SILENCE, new FabricItemSettings()));
	public static final Item MASK_WATCHER = register("mask_watcher", new MaskItem(MaskItem.Kind.WATCHER, new FabricItemSettings()));
	public static final Item MASK_VOID = register("mask_void", new MaskItem(MaskItem.Kind.VOID, new FabricItemSettings()));

	public static final Item GREY_COMPASS = register("grey_compass", new GreyCompassItem(new FabricItemSettings().maxCount(1)));

	private static Item register(String name, Item item) {
		return Registry.register(Registries.ITEM, GreysideMod.id(name), item);
	}

	public static void init() {
		ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> e.add(RIFT_HOE));
		ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> e.add(GREY_COMPASS));
		GreyCompassItem.initTicker();
		ItemGroupEvents.modifyEntriesEvent(ItemGroups.FUNCTIONAL).register(e -> {
			e.add(ModBlocks.DAWN_ALTAR);
			e.add(ModBlocks.ANCHOR);
		});
		ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(e -> {
			e.add(GREY_BLADE);
			e.add(MASK_SILENCE);
			e.add(MASK_WATCHER);
			e.add(MASK_VOID);
		});
		ItemGroupEvents.modifyEntriesEvent(ItemGroups.INGREDIENTS).register(e -> {
			e.add(GREY_DUST);
			e.add(VOID_SHARD);
		});
	}

	private ModItems() {}
}

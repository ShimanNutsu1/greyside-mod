package com.greyside;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.Difficulty;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class GreyEvents {
	/** Сколько тиков подряд нужно пробыть в Изнанке, чтобы за тобой пришёл Безликий (5 минут). */
	private static final int FACELESS_START = 6000;

	private static int lastLevel = -1;
	/** Непрерывное время каждого игрока в Изнанке (сбрасывается при выходе). */
	private static final Map<UUID, Integer> VISIT = new HashMap<>();
	/** Когда игроку в последний раз показывали «Лицо в окне» (в тиках сервера). */
	private static final Map<UUID, Integer> PEEK_LAST = new HashMap<>();

	public static void init() {
		ServerLifecycleEvents.SERVER_STARTED.register(server -> lastLevel = -1);
		ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
			VISIT.clear();
			PEEK_LAST.clear();
		});
		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) ->
				GreyNetworking.send(handler.player, GreyState.get(server).level()));
		ServerTickEvents.END_SERVER_TICK.register(GreyEvents::onTick);
	}

	public static void resetVisit(UUID id) {
		VISIT.put(id, FACELESS_START);
	}

	private static void onTick(MinecraftServer server) {
		GreyState state = GreyState.get(server);
		int level = state.level();

		for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
			if (p.getWorld().getRegistryKey() == ModDimensions.GREYSIDE) {
				// Маска Наблюдателя: цена за широкий конус, Серость копится вдвое быстрее
				int inc = MaskItem.wearing(p, MaskItem.Kind.WATCHER) ? 2 : 1;
				state.add(inc);
				int before = VISIT.getOrDefault(p.getUuid(), 0);
				int after = before + inc;
				VISIT.put(p.getUuid(), after);
				tickFaceless(p, before, after, level);
			} else {
				VISIT.remove(p.getUuid());
			}
		}

		// смена уровня: уведомляем клиентов
		level = state.level();
		if (level != lastLevel) {
			boolean increased = lastLevel != -1 && level > lastLevel;
			lastLevel = level;
			for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
				GreyNetworking.send(p, level);
				if (increased) p.sendMessage(Text.translatable("message.greyside.level." + level), true);
			}
		}

		if (server.getTicks() % 100 != 0) return;

		for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
			if (p.isSpectator() || p.isDead()) continue;
			ServerWorld w = p.getServerWorld();
			Random r = w.random;

			if (w.getRegistryKey() == ModDimensions.GREYSIDE) {
				spawnAmbient(p, level, true);
			} else if (w.getRegistryKey() == World.OVERWORLD) {
				if (level >= 1 && r.nextInt(5) == 0) {
					// шёпот раздаётся рядом, но не точно из головы игрока
					BlockPos near = p.getBlockPos().add(r.nextInt(13) - 6, 0, r.nextInt(13) - 6);
					w.playSound(null, near, ModSounds.WHISPER, SoundCategory.AMBIENT,
							0.7f, 0.85f + r.nextFloat() * 0.3f);
				}
				if (level >= 3 && r.nextInt(3) == 0) {
					spawnAmbient(p, level, false);
				}
				if (level >= 5) {
					p.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 160, 0, false, false, false));
				}
				if (level >= 4 && r.nextInt(level >= 5 ? 14 : 28) == 0) {
					spawnPeeker(p, level, false);
				}
			}
		}
	}

	// ---------- Безликий ----------

	private static void tickFaceless(ServerPlayerEntity p, int before, int after, int level) {
		ServerWorld w = p.getServerWorld();
		// шаг счётчика может быть 2 (маска), поэтому пороги проверяем «перешагнул», а не «равно»
		int warnAt = FACELESS_START - 600;
		if (before < warnAt && after >= warnAt) {
			p.sendMessage(Text.translatable("message.greyside.too_long"), true);
			w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_WARDEN_NEARBY_CLOSER, SoundCategory.AMBIENT, 1.0f, 0.6f);
		}
		int interval = Math.max(1800, 4800 - level * 600);
		if (after >= FACELESS_START) {
			int prevN = before >= FACELESS_START ? (before - FACELESS_START) / interval : -1;
			int nowN = (after - FACELESS_START) / interval;
			if (nowN > prevN) spawnFaceless(p);
		}
	}

	private static void spawnFaceless(ServerPlayerEntity p) {
		ServerWorld w = p.getServerWorld();
		if (w.getDifficulty() == Difficulty.PEACEFUL) return;
		// Безликий из логова не в счёт: у них свой дом, они не бродят
		if (!w.getEntitiesByType(ModEntities.FACELESS, p.getBoundingBox().expand(80), f -> !f.isLair()).isEmpty()) return;

		Random r = w.random;
		for (int i = 0; i < 12; i++) {
			double ang = r.nextDouble() * Math.PI * 2;
			double dist = 24 + r.nextDouble() * 8;
			int x = (int) (p.getX() + Math.cos(ang) * dist);
			int z = (int) (p.getZ() + Math.sin(ang) * dist);
			if (!w.isChunkLoaded(new BlockPos(x, 0, z))) continue;
			BlockPos ground = GreyMobs.findGround(w, x, z, p.getBlockY());
			if (ground == null) continue;
			GreyMobs.spawnAt(ModEntities.FACELESS, w, ground);
			return;
		}
	}

	// ---------- Лицо в окне ----------

	/**
	 * Ставит неподвижного Безликого снаружи, на линии взгляда игрока, не в его поле зрения.
	 * Уровень 4: только если игрок под крышей (фигура встаёт снаружи, видна через окно или проём).
	 * Уровень 5: и на открытом месте, дальше. Не чаще раза в 3 минуты (на 5 уровне в 2). force=true для команды.
	 */
	static boolean spawnPeeker(ServerPlayerEntity p, int level, boolean force) {
		ServerWorld w = p.getServerWorld();
		if (w.getDifficulty() == Difficulty.PEACEFUL) return false;
		if (!w.getEntitiesByType(ModEntities.PEEKER, p.getBoundingBox().expand(64), e -> true).isEmpty()) return false;

		int now = p.getServer().getTicks();
		Integer last = PEEK_LAST.get(p.getUuid());
		if (!force && last != null && now - last < (level >= 5 ? 2400 : 3600)) return false;

		boolean indoors = !w.isSkyVisible(p.getBlockPos().up());
		if (!indoors && level < 5 && !force) return false;

		Random r = w.random;
		Vec3d look = p.getRotationVec(1.0f).normalize();
		for (int i = 0; i < 20; i++) {
			double ang = r.nextDouble() * Math.PI * 2;
			double dist = indoors ? 5 + r.nextDouble() * 8 : 14 + r.nextDouble() * 8;
			int x = (int) (p.getX() + Math.cos(ang) * dist);
			int z = (int) (p.getZ() + Math.sin(ang) * dist);
			if (!w.isChunkLoaded(new BlockPos(x, 0, z))) continue;
			BlockPos g = GreyMobs.findGround(w, x, z, p.getBlockY());
			if (g == null || Math.abs(g.getY() - p.getBlockY()) > 3) continue;
			if (indoors && !w.isSkyVisible(g.up())) continue; // фигура должна стоять снаружи

			Vec3d head = new Vec3d(g.getX() + 0.5, g.getY() + 1.5, g.getZ() + 0.5);
			if (!GreyMobs.lineClear(w, p.getEyePos(), head)) continue; // видна через стекло/проём
			Vec3d to = head.subtract(p.getEyePos()).normalize();
			if (look.dotProduct(to) > 0.5) continue; // не прямо в глаза: пусть заметит сам

			GreyMobs.spawnAt(ModEntities.PEEKER, w, g);
			PEEK_LAST.put(p.getUuid(), now);
			return true;
		}
		return false;
	}

	/** Для команды /greyside faceless. */
	static void spawnFacelessNear(ServerPlayerEntity p) {
		spawnFaceless(p);
	}

	// ---------- обычные мобы ----------

	private static void spawnAmbient(ServerPlayerEntity p, int level, boolean inGreyside) {
		ServerWorld w = p.getServerWorld();
		if (w.getDifficulty() == Difficulty.PEACEFUL) return;
		int roll = w.random.nextInt(100);

		EntityType<? extends MobEntity> type;
		int cap;
		if (inGreyside) {
			if (roll < 45)      { type = ModEntities.SHADOW;         cap = 6 + level; }
			else if (roll < 65) { type = ModEntities.SHADE_ARCHER;   cap = 3; }
			else if (roll < 75) { type = ModEntities.GREY_PHANTOM;   cap = 2; }
			else if (roll < 91) { type = ModEntities.LISTENER;       cap = 2; }
			else                { type = ModEntities.SILHOUETTE;     cap = 1; }
		} else {
			if (roll < 70)                   { type = ModEntities.SHADOW;     cap = level - 1; }
			else if (roll < 80 && level >= 3) { type = ModEntities.LISTENER;   cap = 1; }
			else if (roll < 90 && level >= 4) { type = ModEntities.SILHOUETTE; cap = 1; }
			else if (level >= 5)             { type = ModEntities.GREY_PHANTOM; cap = 1; }
			else return;
		}
		trySpawn(p, w, type, cap);
	}

	private static <T extends MobEntity> void trySpawn(ServerPlayerEntity p, ServerWorld w, EntityType<T> type, int cap) {
		if (GreyMobs.countNear(w, type, p.getBoundingBox().expand(48)) >= cap) return;

		Random r = w.random;
		if (type == ModEntities.GREY_PHANTOM) {
			// фантомы появляются в воздухе над игроком, только если над ним открытое небо
			if (!w.isSkyVisible(p.getBlockPos())) return;
			BlockPos pos = p.getBlockPos().add(r.nextInt(25) - 12, 12 + r.nextInt(5), r.nextInt(25) - 12);
			if (w.getBlockState(pos).isAir()) GreyMobs.spawnAt(type, w, pos);
			return;
		}

		double ang = r.nextDouble() * Math.PI * 2;
		double dist = 18 + r.nextDouble() * 14;
		int x = (int) (p.getX() + Math.cos(ang) * dist);
		int z = (int) (p.getZ() + Math.sin(ang) * dist);
		if (!w.isChunkLoaded(new BlockPos(x, 0, z))) return;
		BlockPos ground = GreyMobs.findGround(w, x, z, p.getBlockY());
		if (ground != null) GreyMobs.spawnAt(type, w, ground);
	}

	private GreyEvents() {}
}

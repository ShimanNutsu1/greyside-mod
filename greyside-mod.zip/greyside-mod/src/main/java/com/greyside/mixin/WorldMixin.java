package com.greyside.mixin;

import com.greyside.HomeMirror;
import net.minecraft.block.BlockState;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Сообщает тёмному зеркалу дома о каждом изменении блока в обычном мире. */
@Mixin(World.class)
public abstract class WorldMixin {
	@Inject(method = "setBlockState(Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/BlockState;II)Z", at = @At("RETURN"))
	private void greyside$mirrorHome(BlockPos pos, BlockState state, int flags, int maxDepth, CallbackInfoReturnable<Boolean> cir) {
		if (cir.getReturnValue() && (Object) this instanceof ServerWorld sw) {
			HomeMirror.onBlockChanged(sw, pos, state);
		}
	}
}

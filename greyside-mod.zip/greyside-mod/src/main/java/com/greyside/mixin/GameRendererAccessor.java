package com.greyside.mixin;

import net.minecraft.client.gl.PostEffectProcessor;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(GameRenderer.class)
public interface GameRendererAccessor {
	@Invoker("loadPostProcessor")
	void greyside$loadPostProcessor(Identifier id);

	/** Текущий пост-шейдер (null, если выключен). Ванильная смена вида по F5 сама его выключает. */
	@Accessor("postProcessor")
	PostEffectProcessor greyside$getPostProcessor();
}

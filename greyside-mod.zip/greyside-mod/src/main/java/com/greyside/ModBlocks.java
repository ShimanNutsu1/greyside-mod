package com.greyside;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.block.Block;
import net.minecraft.item.BlockItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.BlockSoundGroup;

public final class ModBlocks {
	public static final Block RIFT = Registry.register(Registries.BLOCK, GreysideMod.id("rift"),
			new RiftBlock(FabricBlockSettings.create()
					.noCollision()
					.nonOpaque()
					.strength(-1.0f, 3600000.0f)
					.luminance(state -> 6)
					.dropsNothing()));

	public static final Block DAWN_ALTAR = Registry.register(Registries.BLOCK, GreysideMod.id("dawn_altar"),
			new DawnAltarBlock(FabricBlockSettings.create()
					.strength(3.0f, 1200.0f)
					.luminance(state -> 7)
					.sounds(BlockSoundGroup.STONE)));

	public static final Block ANCHOR = Registry.register(Registries.BLOCK, GreysideMod.id("anchor"),
			new AnchorBlock(FabricBlockSettings.create()
					.strength(5.0f, 1200.0f)
					.requiresTool()
					.luminance(state -> 5)
					.sounds(BlockSoundGroup.STONE)));

	public static void init() {
		Registry.register(Registries.ITEM, GreysideMod.id("rift"), new BlockItem(RIFT, new FabricItemSettings()));
		Registry.register(Registries.ITEM, GreysideMod.id("dawn_altar"), new BlockItem(DAWN_ALTAR, new FabricItemSettings()));
		Registry.register(Registries.ITEM, GreysideMod.id("anchor"), new BlockItem(ANCHOR, new FabricItemSettings()));
	}

	private ModBlocks() {}
}

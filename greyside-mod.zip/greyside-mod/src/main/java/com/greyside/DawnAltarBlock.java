package com.greyside;

import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityTicker;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * Алтарь Рассвета: ритуал очищения.
 * ПКМ: отдаёшь серую пыль и осколок пустоты, 90 секунд отбиваешься от волн теней у алтаря.
 * Выстоял: Серость падает на 1 уровень. Алтарь разрушен: Серость растёт.
 */
public class DawnAltarBlock extends BlockWithEntity {
	public static final int DUST_COST = 8;
	public static final int SHARD_COST = 1;

	public DawnAltarBlock(Settings settings) {
		super(settings);
	}

	@Override
	public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
		return new DawnAltarBlockEntity(pos, state);
	}

	@Override
	public BlockRenderType getRenderType(BlockState state) {
		return BlockRenderType.MODEL;
	}

	@Override
	public <T extends BlockEntity> BlockEntityTicker<T> getTicker(World world, BlockState state, BlockEntityType<T> type) {
		return world.isClient ? null : checkType(type, ModBlockEntities.DAWN_ALTAR, DawnAltarBlockEntity::tick);
	}

	@Override
	public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
		if (world.isClient) return ActionResult.SUCCESS;
		if (!(world.getBlockEntity(pos) instanceof DawnAltarBlockEntity altar)) return ActionResult.PASS;

		if (altar.isActive()) {
			player.sendMessage(Text.translatable("message.greyside.ritual_running"), true);
			return ActionResult.SUCCESS;
		}
		if (world.getRegistryKey() != World.OVERWORLD) {
			player.sendMessage(Text.translatable("message.greyside.ritual_overworld"), true);
			return ActionResult.SUCCESS;
		}
		GreyState grey = GreyState.get(world.getServer());
		if (grey.level() <= 0) {
			player.sendMessage(Text.translatable("message.greyside.ritual_clean"), true);
			return ActionResult.SUCCESS;
		}
		if (!world.isSkyVisible(pos.up())) {
			player.sendMessage(Text.translatable("message.greyside.ritual_sky"), true);
			return ActionResult.SUCCESS;
		}
		if (!player.isCreative()) {
			PlayerInventory inv = player.getInventory();
			if (inv.count(ModItems.GREY_DUST) < DUST_COST || inv.count(ModItems.VOID_SHARD) < SHARD_COST) {
				player.sendMessage(Text.translatable("message.greyside.ritual_need", DUST_COST, SHARD_COST), true);
				return ActionResult.SUCCESS;
			}
			take(inv, ModItems.GREY_DUST, DUST_COST);
			take(inv, ModItems.VOID_SHARD, SHARD_COST);
		}
		altar.start();
		player.sendMessage(Text.translatable("message.greyside.ritual_started", DawnAltarBlockEntity.DURATION / 20), true);
		return ActionResult.SUCCESS;
	}

	private static void take(PlayerInventory inv, Item item, int amount) {
		for (int i = 0; i < inv.size() && amount > 0; i++) {
			ItemStack s = inv.getStack(i);
			if (s.isOf(item)) {
				int d = Math.min(amount, s.getCount());
				s.decrement(d);
				amount -= d;
			}
		}
	}
}

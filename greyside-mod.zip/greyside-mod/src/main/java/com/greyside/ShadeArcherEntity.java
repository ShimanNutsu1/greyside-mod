package com.greyside;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.SkeletonEntity;
import net.minecraft.world.World;

/**
 * Тень-стрелок: чёрный скелет с луком. Огнеупорный (из-за этого не горит на солнце).
 * Наследуется от {@link SkeletonEntity}, а не от AbstractSkeletonEntity: в 1.20.1 у абстрактного
 * класса есть package-private метод getStepSound(), который нельзя переопределить из другого пакета.
 * Звуки скелета берутся из родителя.
 */
public class ShadeArcherEntity extends SkeletonEntity {
	public ShadeArcherEntity(EntityType<? extends ShadeArcherEntity> type, World world) {
		super(type, world);
	}
}

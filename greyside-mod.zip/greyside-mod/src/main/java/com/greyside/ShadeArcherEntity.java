package com.greyside;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.SkeletonEntity;
import net.minecraft.world.World;

/**
 * Тень-стрелок: чёрный скелет с луком. Огнеупорный (из-за этого не горит на солнце).
 * Наследуется от SkeletonEntity, потому что у AbstractSkeletonEntity звук шагов доступен только внутри пакета Minecraft.
 */
public class ShadeArcherEntity extends SkeletonEntity {
	public ShadeArcherEntity(EntityType<? extends ShadeArcherEntity> type, World world) {
		super(type, world);
	}
}

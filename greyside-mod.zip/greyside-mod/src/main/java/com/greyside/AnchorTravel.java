package com.greyside;

import net.minecraft.block.Blocks;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.entity.player.ItemCooldownManager;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

/** Логика перехода через Якорь: цена, кулдаун, поиск или создание парного Якоря. */
public final class AnchorTravel {
	public static final int SHARD_COST = 1;
	/** Запасной вариант оплаты, если осколков нет. */
	public static final int DUST_COST = 8;
	/** Кулдаун в тиках (10 секунд). */
	public static final int COOLDOWN = 200;

	private AnchorTravel() {}

	public static void activate(ServerWorld src, BlockPos pos, ServerPlayerEntity player) {
		RegistryKey<World> srcKey = src.getRegistryKey();
		RegistryKey<World> destKey;
		if (srcKey == World.OVERWORLD) destKey = ModDimensions.GREYSIDE;
		else if (srcKey == ModDimensions.GREYSIDE) destKey = World.OVERWORLD;
		else {
			deny(src, pos, player, "message.greyside.anchor_wrong_world");
			return;
		}
		if (!(src.getBlockEntity(pos) instanceof AnchorBlockEntity be)) return;
		ServerWorld dest = src.getServer().getWorld(destKey);
		if (dest == null) return;

		// общий кулдаун через менеджер предметов (ключ — осколок пустоты)
		ItemCooldownManager cooldown = player.getItemCooldownManager();
		if (cooldown.isCoolingDown(ModItems.VOID_SHARD)) {
			deny(src, pos, player, "message.greyside.anchor_cooldown");
			return;
		}

		PlayerInventory inv = player.getInventory();
		boolean useShard = false;
		if (!player.isCreative()) {
			if (inv.count(ModItems.VOID_SHARD) >= SHARD_COST) {
				useShard = true;
			} else if (inv.count(ModItems.GREY_DUST) < DUST_COST) {
				player.sendMessage(Text.translatable("message.greyside.anchor_need", SHARD_COST, DUST_COST), true);
				src.playSound(null, pos, ModSounds.ANCHOR_DENY, SoundCategory.BLOCKS, 1.0f, 1.0f);
				return;
			}
		}

		BlockPos arrival = resolveDestination(src, pos, be, dest);

		if (!player.isCreative()) {
			if (useShard) take(inv, ModItems.VOID_SHARD, SHARD_COST);
			else take(inv, ModItems.GREY_DUST, DUST_COST);
		}
		cooldown.set(ModItems.VOID_SHARD, COOLDOWN);

		src.playSound(null, pos, ModSounds.ANCHOR_ACTIVATE, SoundCategory.BLOCKS, 1.0f, 1.0f);
		src.spawnParticles(ParticleTypes.PORTAL, player.getX(), player.getY() + 1.0, player.getZ(), 40, 0.4, 0.8, 0.4, 0.3);

		player.teleport(dest, arrival.getX() + 0.5, arrival.getY() + 1.0, arrival.getZ() + 0.5,
				player.getYaw(), player.getPitch());
		player.resetPortalCooldown();

		dest.playSound(null, arrival, ModSounds.ANCHOR_ACTIVATE, SoundCategory.BLOCKS, 1.0f, 0.85f);
		dest.spawnParticles(ParticleTypes.PORTAL, arrival.getX() + 0.5, arrival.getY() + 1.5, arrival.getZ() + 0.5, 40, 0.4, 0.8, 0.4, 0.3);
	}

	private static void deny(ServerWorld w, BlockPos pos, ServerPlayerEntity p, String key) {
		p.sendMessage(Text.translatable(key), true);
		w.playSound(null, pos, ModSounds.ANCHOR_DENY, SoundCategory.BLOCKS, 1.0f, 1.0f);
	}

	/** Возвращает позицию парного Якоря в dest. Если его нет (или его сломали), создаёт новый. */
	private static BlockPos resolveDestination(ServerWorld src, BlockPos pos, AnchorBlockEntity be, ServerWorld dest) {
		BlockPos link = be.getLinkPos();
		if (link != null && be.getLinkWorld() == dest.getRegistryKey()) {
			dest.getChunk(link); // подгружаем чанк
			if (dest.getBlockState(link).isOf(ModBlocks.ANCHOR)) {
				if (dest.getBlockEntity(link) instanceof AnchorBlockEntity other) {
					other.setLink(src.getRegistryKey(), pos);
				}
				return link;
			}
		}

		BlockPos spot = findAnchorSpot(dest, pos);
		dest.setBlockState(spot, ModBlocks.ANCHOR.getDefaultState());
		if (dest.getBlockEntity(spot) instanceof AnchorBlockEntity other) {
			other.setLink(src.getRegistryKey(), pos);
		}
		be.setLink(dest.getRegistryKey(), spot);
		return spot;
	}

	/** Клетка для нового Якоря: те же координаты, если там свободно, иначе на поверхности. */
	private static BlockPos findAnchorSpot(ServerWorld dest, BlockPos from) {
		dest.getChunk(from);
		int minY = dest.getBottomY() + 2;
		int maxY = dest.getTopY() - 4;
		if (from.getY() >= minY && from.getY() <= maxY && fits(dest, from)) return from;

		int top = dest.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, from.getX(), from.getZ());
		BlockPos spot = new BlockPos(from.getX(), Math.max(minY, Math.min(top, maxY)), from.getZ());
		BlockPos floor = spot.down();
		if (!dest.getBlockState(floor).isSolidBlock(dest, floor)) {
			dest.setBlockState(floor, Blocks.STONE.getDefaultState()); // вода/воздух под ногами: ставим опору
		}
		for (int i = 1; i <= 2; i++) {
			BlockPos up = spot.up(i);
			if (!dest.getBlockState(up).isAir()) dest.setBlockState(up, Blocks.AIR.getDefaultState());
		}
		return spot;
	}

	private static boolean fits(ServerWorld w, BlockPos p) {
		return w.getBlockState(p).isAir()
				&& w.getBlockState(p.up()).isAir()
				&& w.getBlockState(p.up(2)).isAir()
				&& w.getBlockState(p.down()).isSolidBlock(w, p.down());
	}

	private static void take(PlayerInventory inv, Item item, int amount) {
		for (int i = 0; i < inv.size() && amount > 0; i++) {
			ItemStack s = inv.getStack(i);
			if (s.isOf(item)) {
				int d = Math.min(amount, s.getCount());
				s.decrement(d);
				amount -= d;
			}
		}
	}
}

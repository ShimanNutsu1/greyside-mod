package com.greyside;

import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;

public enum IonToolMaterial implements ToolMaterial {
	INSTANCE;

	@Override public int getDurability() { return 1800; }
	@Override public float getMiningSpeedMultiplier() { return 8.0f; }
	@Override public float getAttackDamage() { return 5.0f; }
	@Override public int getMiningLevel() { return 4; }
	@Override public int getEnchantability() { return 20; }
	@Override public Ingredient getRepairIngredient() { return Ingredient.ofItems(ModItems.VOID_SHARD); }
}

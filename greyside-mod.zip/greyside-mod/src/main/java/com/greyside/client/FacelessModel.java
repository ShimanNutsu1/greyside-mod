package com.greyside.client;

import com.greyside.GreysideMod;
import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;

/**
 * Модель Безликого: вытянутая фигура около 2.9 блока. Узкий торс, длинная шея, голова без черт,
 * руки до колен. Поле {@link #twitch} (0..1) задаёт рендерер: чем сильнее, тем рваннее суставы.
 * Дёрганье покадровое (раз в 2 тика, как покадровая анимация), поэтому выглядит неправильно, а не плавно.
 *
 * Координаты в пикселях (16 px = блок), ноги стоят на y = 24. Текстура 64x64.
 */
public class FacelessModel<T extends LivingEntity> extends EntityModel<T> {
	public static final EntityModelLayer LAYER = new EntityModelLayer(GreysideMod.id("faceless"), "main");

	/** 0 = спокоен, 1 = бьётся в судорогах. Выставляется рендерером перед отрисовкой. */
	public float twitch = 0.0f;

	private final ModelPart root;
	private final ModelPart head;
	private final ModelPart neck;
	private final ModelPart torso;
	private final ModelPart armL;
	private final ModelPart armR;
	private final ModelPart legL;
	private final ModelPart legR;

	public FacelessModel(ModelPart root) {
		this.root = root;
		this.head = root.getChild("head");
		this.neck = root.getChild("neck");
		this.torso = root.getChild("torso");
		this.armL = root.getChild("arm_l");
		this.armR = root.getChild("arm_r");
		this.legL = root.getChild("leg_l");
		this.legR = root.getChild("leg_r");
	}

	public static TexturedModelData getTexturedModelData() {
		ModelData data = new ModelData();
		ModelPartData r = data.getRoot();
		Dilation none = Dilation.NONE;

		// высота: ноги 18 + торс 16 + шея 4 + голова 8 = 46 px = 2.875 блока
		r.addChild("leg_l", ModelPartBuilder.create().uv(0, 40).cuboid(-1.0f, 0.0f, -1.0f, 2.0f, 18.0f, 2.0f, none),
				ModelTransform.pivot(1.8f, 6.0f, 0.0f));
		r.addChild("leg_r", ModelPartBuilder.create().uv(8, 40).cuboid(-1.0f, 0.0f, -1.0f, 2.0f, 18.0f, 2.0f, none),
				ModelTransform.pivot(-1.8f, 6.0f, 0.0f));
		r.addChild("torso", ModelPartBuilder.create().uv(0, 16).cuboid(-3.0f, 0.0f, -1.5f, 6.0f, 16.0f, 3.0f, none),
				ModelTransform.pivot(0.0f, -10.0f, 0.0f));
		r.addChild("neck", ModelPartBuilder.create().uv(20, 0).cuboid(-1.0f, 0.0f, -1.0f, 2.0f, 4.0f, 2.0f, none),
				ModelTransform.pivot(0.0f, -14.0f, 0.0f));
		r.addChild("head", ModelPartBuilder.create().uv(0, 0).cuboid(-2.5f, -8.0f, -2.5f, 5.0f, 8.0f, 5.0f, none),
				ModelTransform.pivot(0.0f, -14.0f, 0.0f));
		// руки: 24 px, висят ниже бёдер
		r.addChild("arm_l", ModelPartBuilder.create().uv(20, 16).cuboid(-1.0f, 0.0f, -1.0f, 2.0f, 24.0f, 2.0f, none),
				ModelTransform.pivot(4.5f, -9.0f, 0.0f));
		r.addChild("arm_r", ModelPartBuilder.create().uv(28, 16).cuboid(-1.0f, 0.0f, -1.0f, 2.0f, 24.0f, 2.0f, none),
				ModelTransform.pivot(-4.5f, -9.0f, 0.0f));
		return TexturedModelData.of(data, 64, 64);
	}

	/** Детерминированный шум -1..1 от (шаг, номер сустава). */
	private static float jitter(int step, int part) {
		float h = (float) Math.sin(step * 12.9898f + part * 78.233f) * 43758.5453f;
		return (h - MathHelper.floor(h)) * 2.0f - 1.0f;
	}

	@Override
	public void setAngles(T entity, float limbAngle, float limbDistance, float animationProgress,
						  float headYaw, float headPitch) {
		float t = MathHelper.clamp(twitch, 0.0f, 1.0f);
		int step = (int) (animationProgress * 0.5f); // кадр сменяется раз в 2 тика

		// спокойная поза: голова чуть набок, руки качаются как от сквозняка
		float sway = MathHelper.sin(animationProgress * 0.04f) * 0.04f;
		float swing = MathHelper.sin(limbAngle * 0.6662f) * 0.9f * limbDistance;

		head.yaw = headYaw * 0.0174533f * 0.5f + jitter(step, 0) * 0.55f * t;
		head.pitch = headPitch * 0.0174533f * 0.5f + jitter(step, 1) * 0.35f * t;
		head.roll = 0.18f + jitter(step, 2) * 0.45f * t;
		neck.pitch = jitter(step, 3) * 0.25f * t;
		neck.roll = head.roll * 0.4f;

		torso.yaw = jitter(step, 4) * 0.20f * t;
		torso.roll = jitter(step, 5) * 0.08f * t;

		// на бегу руки отведены вперёд, как у бегущего вслепую
		float reach = MathHelper.clamp(limbDistance * 1.2f, 0.0f, 0.7f);
		armL.pitch = -reach - swing * 0.5f + jitter(step, 6) * 0.8f * t;
		armR.pitch = -reach + swing * 0.5f + jitter(step, 7) * 0.8f * t;
		armL.roll = 0.06f + sway + jitter(step, 8) * 0.45f * t;
		armR.roll = -0.06f - sway + jitter(step, 9) * 0.45f * t;

		legL.pitch = swing + jitter(step, 10) * 0.30f * t;
		legR.pitch = -swing + jitter(step, 11) * 0.30f * t;
	}

	@Override
	public void render(MatrixStack matrices, VertexConsumer vertices, int light, int overlay,
					   float red, float green, float blue, float alpha) {
		root.render(matrices, vertices, light, overlay, red, green, blue, alpha);
	}
}

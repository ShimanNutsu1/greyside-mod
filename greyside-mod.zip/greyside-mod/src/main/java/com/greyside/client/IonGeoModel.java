package com.greyside.client;

import com.greyside.GreysideMod;
import com.greyside.IonEntity;
import net.minecraft.util.Identifier;
import software.bernie.geckolib.model.GeoModel;

/** Модель, анимации и текстуры Иона (файлы генерирует tools/gen_ion_geo.py). Во второй фазе текстура с красными трещинами. */
public class IonGeoModel extends GeoModel<IonEntity> {
	private static final Identifier MODEL = GreysideMod.id("geo/ion.geo.json");
	private static final Identifier ANIMATION = GreysideMod.id("animations/ion.animation.json");
	private static final Identifier TEXTURE = GreysideMod.id("textures/entity/ion.png");
	private static final Identifier TEXTURE_ENRAGED = GreysideMod.id("textures/entity/ion_enraged.png");

	@Override
	public Identifier getModelResource(IonEntity animatable) {
		return MODEL;
	}

	@Override
	public Identifier getTextureResource(IonEntity animatable) {
		return animatable.isPhaseTwo() ? TEXTURE_ENRAGED : TEXTURE;
	}

	@Override
	public Identifier getAnimationResource(IonEntity animatable) {
		return ANIMATION;
	}
}

package com.greyside.client;

import com.greyside.IonEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import software.bernie.geckolib.renderer.layer.AutoGlowingGeoLayer;

/**
 * Ион на GeckoLib. Светящийся слой берётся из файлов *_glowmask.png рядом с текстурой:
 * глаза всех масок, а во второй фазе ещё и красные трещины. Светятся и в полной темноте.
 */
public class IonGeoRenderer extends GeoEntityRenderer<IonEntity> {
	public IonGeoRenderer(EntityRendererFactory.Context ctx) {
		super(ctx, new IonGeoModel());
		this.shadowRadius = 1.4f;
		addRenderLayer(new AutoGlowingGeoLayer<>(this));
	}
}

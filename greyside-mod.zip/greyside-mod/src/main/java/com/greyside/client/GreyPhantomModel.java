package com.greyside.client;

import com.greyside.GreysideMod;
import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.mob.PhantomEntity;
import net.minecraft.util.math.MathHelper;

/**
 * Модель Серого фантома: узкое вытянутое тело, безликая голова с гребнем, длинный хвост из двух
 * звеньев и рваные крылья из трёх лоскутов разной длины. Крылья машут, лоскуты запаздывают
 * и колышутся как ткань. Текстура 64x64 (tools/gen_grey_phantom.py).
 */
public class GreyPhantomModel<T extends PhantomEntity> extends EntityModel<T> {
	public static final EntityModelLayer LAYER = new EntityModelLayer(GreysideMod.id("grey_phantom"), "main");

	private final ModelPart root;
	private final ModelPart body;
	private final ModelPart head;
	private final ModelPart wingBaseL, wingBaseR;
	private final ModelPart[] stripsL = new ModelPart[3];
	private final ModelPart[] stripsR = new ModelPart[3];
	private final ModelPart tailBase, tailTip;

	public GreyPhantomModel(ModelPart root) {
		this.root = root;
		this.body = root.getChild("body");
		this.head = body.getChild("head");
		this.tailBase = body.getChild("tail_base");
		this.tailTip = tailBase.getChild("tail_tip");
		this.wingBaseL = body.getChild("wing_l");
		this.wingBaseR = body.getChild("wing_r");
		for (int i = 0; i < 3; i++) {
			stripsL[i] = wingBaseL.getChild("strip" + i);
			stripsR[i] = wingBaseR.getChild("strip" + i);
		}
	}

	public static TexturedModelData getTexturedModelData() {
		ModelData data = new ModelData();
		ModelPartData r = data.getRoot();
		Dilation none = Dilation.NONE;

		ModelPartData body = r.addChild("body",
				ModelPartBuilder.create().uv(0, 0).cuboid(-2.5f, -2.0f, -8.0f, 5.0f, 4.0f, 12.0f, none),
				ModelTransform.rotation(-0.05f, 0.0f, 0.0f));

		// голова гладкая, без глаз; сверху тонкий гребень
		ModelPartData head = body.addChild("head",
				ModelPartBuilder.create().uv(0, 16).cuboid(-3.0f, -3.0f, -5.0f, 6.0f, 6.0f, 5.0f, none),
				ModelTransform.of(0.0f, 0.0f, -8.0f, 0.2f, 0.0f, 0.0f));
		head.addChild("crest",
				ModelPartBuilder.create().uv(22, 16).cuboid(-0.5f, -5.0f, -4.0f, 1.0f, 2.0f, 5.0f, none),
				ModelTransform.NONE);

		// хвост из двух звеньев
		ModelPartData tail = body.addChild("tail_base",
				ModelPartBuilder.create().uv(34, 0).cuboid(-1.5f, -1.5f, 0.0f, 3.0f, 3.0f, 9.0f, none),
				ModelTransform.pivot(0.0f, 0.0f, 4.0f));
		tail.addChild("tail_tip",
				ModelPartBuilder.create().uv(34, 12).cuboid(-1.0f, -1.0f, 0.0f, 2.0f, 2.0f, 10.0f, none),
				ModelTransform.pivot(0.0f, 0.0f, 9.0f));

		// левое крыло: основа + три рваных лоскута
		ModelPartData wl = body.addChild("wing_l",
				ModelPartBuilder.create().uv(0, 28).cuboid(0.0f, -0.5f, 0.0f, 9.0f, 1.0f, 10.0f, none),
				ModelTransform.pivot(2.5f, -1.0f, -6.0f));
		wl.addChild("strip0", ModelPartBuilder.create().uv(0, 40).cuboid(0.0f, -0.5f, 0.0f, 12.0f, 1.0f, 3.0f, none),
				ModelTransform.of(9.0f, 0.0f, 0.5f, 0.0f, -0.12f, 0.0f));
		wl.addChild("strip1", ModelPartBuilder.create().uv(0, 44).cuboid(0.0f, -0.5f, 0.0f, 9.0f, 1.0f, 3.0f, none),
				ModelTransform.of(9.0f, 0.0f, 3.8f, 0.0f, 0.04f, 0.0f));
		wl.addChild("strip2", ModelPartBuilder.create().uv(0, 48).cuboid(0.0f, -0.5f, 0.0f, 6.0f, 1.0f, 3.0f, none),
				ModelTransform.of(9.0f, 0.0f, 7.0f, 0.0f, 0.22f, 0.0f));

		// правое крыло: зеркально
		ModelPartData wr = body.addChild("wing_r",
				ModelPartBuilder.create().uv(0, 28).mirrored(true).cuboid(-9.0f, -0.5f, 0.0f, 9.0f, 1.0f, 10.0f, none),
				ModelTransform.pivot(-2.5f, -1.0f, -6.0f));
		wr.addChild("strip0", ModelPartBuilder.create().uv(0, 40).mirrored(true).cuboid(-12.0f, -0.5f, 0.0f, 12.0f, 1.0f, 3.0f, none),
				ModelTransform.of(-9.0f, 0.0f, 0.5f, 0.0f, 0.12f, 0.0f));
		wr.addChild("strip1", ModelPartBuilder.create().uv(0, 44).mirrored(true).cuboid(-9.0f, -0.5f, 0.0f, 9.0f, 1.0f, 3.0f, none),
				ModelTransform.of(-9.0f, 0.0f, 3.8f, 0.0f, -0.04f, 0.0f));
		wr.addChild("strip2", ModelPartBuilder.create().uv(0, 48).mirrored(true).cuboid(-6.0f, -0.5f, 0.0f, 6.0f, 1.0f, 3.0f, none),
				ModelTransform.of(-9.0f, 0.0f, 7.0f, 0.0f, -0.22f, 0.0f));

		return TexturedModelData.of(data, 64, 64);
	}

	@Override
	public void setAngles(T entity, float limbAngle, float limbDistance, float animationProgress,
						  float headYaw, float headPitch) {
		float f = ((float) entity.getWingFlapTickOffset() + animationProgress) * 7.448451f * 0.017453292f;

		float flap = MathHelper.cos(f) * 16.0f * 0.017453292f;
		wingBaseL.roll = 0.1f + flap;
		wingBaseR.roll = -wingBaseL.roll;

		// лоскуты запаздывают по фазе, поэтому крыло колышется как рваная ткань
		for (int i = 0; i < 3; i++) {
			float lag = MathHelper.cos(f - 0.7f * (i + 1)) * (0.28f + 0.08f * i);
			stripsL[i].roll = lag;
			stripsR[i].roll = -lag;
		}

		tailBase.pitch = -(5.0f + MathHelper.cos(f * 2.0f) * 5.0f) * 0.017453292f;
		tailTip.pitch = -(5.0f + MathHelper.cos(f * 2.0f + 0.6f) * 8.0f) * 0.017453292f;
		tailBase.yaw = MathHelper.sin(f) * 0.08f;
		tailTip.yaw = MathHelper.sin(f - 0.8f) * 0.16f;
	}

	@Override
	public void render(MatrixStack matrices, VertexConsumer vertices, int light, int overlay,
					   float red, float green, float blue, float alpha) {
		root.render(matrices, vertices, light, overlay, red, green, blue, alpha);
	}
}

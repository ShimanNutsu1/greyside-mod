package com.greyside.client;

import com.greyside.GreysideMod;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.ZombieEntityRenderer;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.util.Identifier;

public class ShadowRenderer extends ZombieEntityRenderer {
	private static final Identifier TEXTURE = GreysideMod.id("textures/entity/shadow.png");

	public ShadowRenderer(EntityRendererFactory.Context ctx) {
		super(ctx);
	}

	@Override
	public Identifier getTexture(ZombieEntity entity) {
		return TEXTURE;
	}
}

package com.greyside.client;

import com.greyside.FacelessEntity;
import com.greyside.GreysideMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.EndermanEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

/** Высокая чёрная фигура. Прямо в центре взгляда не рисуется вообще: видно только краем экрана. */
public class FacelessRenderer extends MobEntityRenderer<FacelessEntity, EndermanEntityModel<FacelessEntity>> {
	private static final Identifier TEXTURE = GreysideMod.id("textures/entity/black.png");

	public FacelessRenderer(EntityRendererFactory.Context ctx) {
		super(ctx, new EndermanEntityModel<>(ctx.getPart(EntityModelLayers.ENDERMAN)), 0.0f);
	}

	@Override
	public Identifier getTexture(FacelessEntity entity) {
		return TEXTURE;
	}

	@Override
	public void render(FacelessEntity entity, float yaw, float tickDelta, MatrixStack matrices,
					   VertexConsumerProvider vertexConsumers, int light) {
		Entity cam = MinecraftClient.getInstance().getCameraEntity();
		if (cam != null) {
			Vec3d look = cam.getRotationVec(tickDelta).normalize();
			Vec3d to = entity.getBoundingBox().getCenter().subtract(cam.getCameraPosVec(tickDelta)).normalize();
			if (look.dotProduct(to) > FacelessEntity.WATCH_DOT) return; // смотришь прямо на него: его нет
		}
		super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
	}
}

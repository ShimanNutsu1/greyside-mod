package com.greyside.client;

import com.greyside.FacelessEntity;
import com.greyside.GreysideMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Высокая чёрная фигура. Прямо в центре взгляда не рисуется вообще: видно только краем экрана.
 * Чем ближе он к центру взгляда, тем сильнее дёргаются его суставы (на самом краю почти спокоен,
 * у порога исчезновения бьётся в судорогах).
 */
public class FacelessRenderer extends MobEntityRenderer<FacelessEntity, FacelessModel<FacelessEntity>> {
	private static final Identifier TEXTURE = GreysideMod.id("textures/entity/faceless.png");
	/** С какого угла к центру начинает дёргаться (скалярное произведение). */
	private static final double TWITCH_FROM = 0.35;

	public FacelessRenderer(EntityRendererFactory.Context ctx) {
		super(ctx, new FacelessModel<>(ctx.getPart(FacelessModel.LAYER)), 0.0f);
	}

	@Override
	public Identifier getTexture(FacelessEntity entity) {
		return TEXTURE;
	}

	@Override
	public void render(FacelessEntity entity, float yaw, float tickDelta, MatrixStack matrices,
					   VertexConsumerProvider vertexConsumers, int light) {
		Entity cam = MinecraftClient.getInstance().getCameraEntity();
		float twitch = 0.0f;
		if (cam != null) {
			Vec3d look = cam.getRotationVec(tickDelta).normalize();
			Vec3d to = entity.getBoundingBox().getCenter().subtract(cam.getCameraPosVec(tickDelta)).normalize();
			double dot = look.dotProduct(to);
			double limit = FacelessEntity.watchDotFor(cam);
			if (dot > limit) return; // смотришь прямо на него: его нет
			twitch = (float) MathHelper.clamp((dot - TWITCH_FROM) / (limit - TWITCH_FROM), 0.0, 1.0);
		}
		this.model.twitch = twitch;
		super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
	}
}

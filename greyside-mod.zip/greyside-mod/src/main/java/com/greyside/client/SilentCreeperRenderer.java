package com.greyside.client;

import com.greyside.GreysideMod;
import net.minecraft.client.render.entity.CreeperEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.util.Identifier;

public class SilentCreeperRenderer extends CreeperEntityRenderer {
	private static final Identifier TEXTURE = GreysideMod.id("textures/entity/black.png");

	public SilentCreeperRenderer(EntityRendererFactory.Context ctx) {
		super(ctx);
	}

	@Override
	public Identifier getTexture(CreeperEntity entity) {
		return TEXTURE;
	}
}

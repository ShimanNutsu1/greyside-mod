package com.greyside.client;

import com.greyside.FacelessEntity;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.random.Random;

/**
 * Шум по краям экрана, когда рядом Безликий. Дальше 28 блоков ничего нет, ближе нарастает:
 * сначала затемнение углов, потом зернистая «рябь» у краёв. Мягко включается и выключается (по 10% за кадр).
 */
public final class FearOverlay {
	private static final double RANGE = 28.0;
	private static final Random RNG = Random.create();
	private static float level = 0.0f;

	public static void init() {
		HudRenderCallback.EVENT.register(FearOverlay::render);
	}

	private static float target(MinecraftClient mc) {
		if (mc.world == null || mc.player == null) return 0.0f;
		double best = RANGE;
		for (FacelessEntity f : mc.world.getEntitiesByClass(FacelessEntity.class,
				new Box(mc.player.getBlockPos()).expand(RANGE), e -> true)) {
			best = Math.min(best, f.distanceTo(mc.player));
		}
		if (best >= RANGE) return 0.0f;
		float k = (float) (1.0 - best / RANGE);
		return k * k; // у самого лица почти 1, вдали едва заметно
	}

	private static void render(DrawContext ctx, float tickDelta) {
		MinecraftClient mc = MinecraftClient.getInstance();
		level += (target(mc) - level) * 0.1f;
		if (level < 0.02f) return;

		int w = ctx.getScaledWindowWidth();
		int h = ctx.getScaledWindowHeight();

		// затемнение краёв: полосы убывающей прозрачности
		int band = (int) (Math.min(w, h) * (0.10f + 0.20f * level));
		int steps = 10;
		for (int i = 0; i < steps; i++) {
			float f = 1.0f - i / (float) steps;
			int a = (int) (170 * level * f * f);
			if (a <= 0) continue;
			int col = a << 24;
			int d0 = band * i / steps;
			int d1 = band * (i + 1) / steps;
			ctx.fill(0, d0, w, d1, col);              // верх
			ctx.fill(0, h - d1, w, h - d0, col);      // низ
			ctx.fill(d0, d1, d1, h - d1, col);        // лево
			ctx.fill(w - d1, d1, w - d0, h - d1, col); // право
		}

		// зерно: случайные точки и короткие чёрточки у краёв
		int grains = (int) (260 * level);
		for (int i = 0; i < grains; i++) {
			int side = RNG.nextInt(4);
			int depth = (int) (band * RNG.nextFloat() * RNG.nextFloat() * 1.4f);
			int x, y;
			if (side < 2) {
				x = RNG.nextInt(w);
				y = side == 0 ? depth : h - 1 - depth;
			} else {
				y = RNG.nextInt(h);
				x = side == 2 ? depth : w - 1 - depth;
			}
			boolean light = RNG.nextInt(5) == 0;
			int a = MathHelper.clamp((int) (60 + 150 * level * RNG.nextFloat()), 0, 220);
			int col = (a << 24) | (light ? 0xB4B4B4 : 0x000000);
			int len = 1 + RNG.nextInt(3);
			ctx.fill(x, y, x + (side < 2 ? len : 1), y + (side < 2 ? 1 : len), col);
		}
	}

	private FearOverlay() {}
}

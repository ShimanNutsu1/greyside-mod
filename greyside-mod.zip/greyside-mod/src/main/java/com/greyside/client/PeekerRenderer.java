package com.greyside.client;

import com.greyside.GreysideMod;
import com.greyside.PeekerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

/** «Лицо в окне»: та же фигура, но видна всегда (даже прямо перед глазами) и чуть подёргивается. */
public class PeekerRenderer extends MobEntityRenderer<PeekerEntity, FacelessModel<PeekerEntity>> {
	private static final Identifier TEXTURE = GreysideMod.id("textures/entity/faceless.png");

	public PeekerRenderer(EntityRendererFactory.Context ctx) {
		super(ctx, new FacelessModel<>(ctx.getPart(FacelessModel.LAYER)), 0.0f);
	}

	@Override
	public Identifier getTexture(PeekerEntity entity) {
		return TEXTURE;
	}

	@Override
	public void render(PeekerEntity entity, float yaw, float tickDelta, MatrixStack matrices,
					   VertexConsumerProvider vertexConsumers, int light) {
		this.model.twitch = 0.22f;
		super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
	}
}

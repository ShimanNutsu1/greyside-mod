package com.greyside.client;

import com.greyside.IonEntity;
import com.greyside.ModEntities;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Тряска камеры, пока смотришь на Иона. Чем точнее взгляд на него и чем он ближе, тем сильнее дрожит прицел.
 * Работает только на клиенте и только в конусе взгляда (скалярное произведение больше 0.75), на 48 блоков.
 */
public final class IonShake {
	private static final double RANGE = 48.0;
	private static final double MIN_DOT = 0.75;

	public static void init() {
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			ClientPlayerEntity p = client.player;
			ClientWorld w = client.world;
			if (p == null || w == null || client.isPaused()) return;

			double strongest = 0.0;
			Vec3d look = p.getRotationVec(1.0f).normalize();
			for (IonEntity ion : w.getEntitiesByType(ModEntities.ION, p.getBoundingBox().expand(RANGE), e -> true)) {
				double dist = p.distanceTo(ion);
				if (dist > RANGE) continue;
				Vec3d to = ion.getBoundingBox().getCenter().subtract(p.getEyePos()).normalize();
				double dot = look.dotProduct(to);
				if (dot < MIN_DOT) continue;
				double s = (dot - MIN_DOT) / (1.0 - MIN_DOT) * (1.0 - dist / RANGE);
				strongest = Math.max(strongest, s);
			}
			if (strongest <= 0.0) return;

			float amp = (float) (0.4 + strongest * 3.2);
			p.setYaw(p.getYaw() + (p.getRandom().nextFloat() - 0.5f) * amp);
			p.setPitch(MathHelper.clamp(p.getPitch() + (p.getRandom().nextFloat() - 0.5f) * amp, -90.0f, 90.0f));
		});
	}

	private IonShake() {}
}

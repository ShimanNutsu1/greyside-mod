package com.greyside.client;

import com.greyside.GreysideMod;
import com.greyside.SilhouetteEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.util.Identifier;

/** Силуэт: модель игрока с полностью чёрной текстурой. */
public class SilhouetteRenderer extends LivingEntityRenderer<SilhouetteEntity, PlayerEntityModel<SilhouetteEntity>> {
	private static final Identifier TEXTURE = GreysideMod.id("textures/entity/black.png");

	public SilhouetteRenderer(EntityRendererFactory.Context ctx) {
		super(ctx, new PlayerEntityModel<>(ctx.getPart(EntityModelLayers.PLAYER), false), 0.5f);
	}

	@Override
	public Identifier getTexture(SilhouetteEntity entity) {
		return TEXTURE;
	}
}

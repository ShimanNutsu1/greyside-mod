package com.greyside.client;

import com.greyside.GreyPhantomEntity;
import com.greyside.GreysideMod;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;

/** Серый фантом: собственная модель (см. {@link GreyPhantomModel}), поведение и полёт остаются фантомьими. */
public class GreyPhantomRenderer extends MobEntityRenderer<GreyPhantomEntity, GreyPhantomModel<GreyPhantomEntity>> {
	private static final Identifier TEXTURE = GreysideMod.id("textures/entity/grey_phantom.png");

	public GreyPhantomRenderer(EntityRendererFactory.Context ctx) {
		super(ctx, new GreyPhantomModel<>(ctx.getPart(GreyPhantomModel.LAYER)), 0.75f);
	}

	@Override
	public Identifier getTexture(GreyPhantomEntity entity) {
		return TEXTURE;
	}

	@Override
	protected void scale(GreyPhantomEntity entity, MatrixStack matrices, float amount) {
		float s = 1.0f + 0.15f * entity.getPhantomSize();
		matrices.scale(s, s, s);
		matrices.translate(0.0f, 1.3125f, 0.1875f);
	}

	@Override
	protected void setupTransforms(GreyPhantomEntity entity, MatrixStack matrices, float animationProgress,
								   float bodyYaw, float tickDelta) {
		super.setupTransforms(entity, matrices, animationProgress, bodyYaw, tickDelta);
		matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(entity.getPitch()));
	}
}

package com.greyside.client;

import com.greyside.GreysideMod;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.PhantomEntityRenderer;
import net.minecraft.entity.mob.PhantomEntity;
import net.minecraft.util.Identifier;

public class GreyPhantomRenderer extends PhantomEntityRenderer {
	private static final Identifier TEXTURE = GreysideMod.id("textures/entity/black.png");

	public GreyPhantomRenderer(EntityRendererFactory.Context ctx) {
		super(ctx);
	}

	@Override
	public Identifier getTexture(PhantomEntity entity) {
		return TEXTURE;
	}
}

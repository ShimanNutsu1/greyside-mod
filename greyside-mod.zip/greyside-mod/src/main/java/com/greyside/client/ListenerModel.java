package com.greyside.client;

import com.greyside.GreysideMod;
import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;

/**
 * Модель Слушателя: сутулая худая фигура, длинные руки, гладкая голова без глаз и рта
 * и огромные воронкообразные уши, развёрнутые вперёд. Уши подрагивают, ловя звук.
 *
 * Координаты в пикселях (16 px = блок), ноги стоят на y = 24. Текстура 64x64
 * (рисуется скриптом tools/gen_listener.py).
 */
public class ListenerModel<T extends LivingEntity> extends EntityModel<T> {
	public static final EntityModelLayer LAYER = new EntityModelLayer(GreysideMod.id("listener"), "main");

	private final ModelPart root;
	private final ModelPart head;
	private final ModelPart earL;
	private final ModelPart earR;
	private final ModelPart torso;
	private final ModelPart armL;
	private final ModelPart armR;
	private final ModelPart legL;
	private final ModelPart legR;

	public ListenerModel(ModelPart root) {
		this.root = root;
		this.head = root.getChild("head");
		this.earL = this.head.getChild("ear_l");
		this.earR = this.head.getChild("ear_r");
		this.torso = root.getChild("torso");
		this.armL = root.getChild("arm_l");
		this.armR = root.getChild("arm_r");
		this.legL = root.getChild("leg_l");
		this.legR = root.getChild("leg_r");
	}

	public static TexturedModelData getTexturedModelData() {
		ModelData data = new ModelData();
		ModelPartData r = data.getRoot();
		Dilation none = Dilation.NONE;

		r.addChild("leg_l", ModelPartBuilder.create().uv(0, 32).cuboid(-1.5f, 0.0f, -1.5f, 3.0f, 13.0f, 3.0f, none),
				ModelTransform.pivot(2.2f, 11.0f, 0.0f));
		r.addChild("leg_r", ModelPartBuilder.create().uv(12, 32).cuboid(-1.5f, 0.0f, -1.5f, 3.0f, 13.0f, 3.0f, none),
				ModelTransform.pivot(-2.2f, 11.0f, 0.0f));

		ModelPartData torso = r.addChild("torso", ModelPartBuilder.create().uv(0, 16).cuboid(-4.0f, 0.0f, -2.0f, 8.0f, 11.0f, 4.0f, none),
				ModelTransform.of(0.0f, 1.0f, 0.0f, 0.35f, 0.0f, 0.0f));
		// хребет: выступает со спины
		torso.addChild("spine", ModelPartBuilder.create().uv(48, 16).cuboid(-1.0f, 0.0f, 2.0f, 2.0f, 9.0f, 1.0f, none),
				ModelTransform.NONE);

		ModelPartData head = r.addChild("head", ModelPartBuilder.create().uv(0, 0).cuboid(-3.5f, -8.0f, -3.5f, 7.0f, 8.0f, 7.0f, none),
				ModelTransform.pivot(0.0f, 1.0f, -2.5f));
		// уши: большие плоские «воронки», тянутся в стороны и немного вперёд
		head.addChild("ear_l", ModelPartBuilder.create().uv(28, 0).cuboid(0.0f, -6.0f, -0.5f, 9.0f, 12.0f, 1.0f, none),
				ModelTransform.of(3.5f, -4.0f, 0.0f, 0.0f, 0.45f, -0.2f));
		head.addChild("ear_r", ModelPartBuilder.create().uv(28, 41).cuboid(-9.0f, -6.0f, -0.5f, 9.0f, 12.0f, 1.0f, none),
				ModelTransform.of(-3.5f, -4.0f, 0.0f, 0.0f, -0.45f, 0.2f));

		// руки очень длинные, почти до земли
		r.addChild("arm_l", ModelPartBuilder.create().uv(24, 16).cuboid(-1.5f, -1.0f, -1.5f, 3.0f, 20.0f, 3.0f, none),
				ModelTransform.pivot(5.5f, 2.5f, -1.5f));
		r.addChild("arm_r", ModelPartBuilder.create().uv(36, 16).cuboid(-1.5f, -1.0f, -1.5f, 3.0f, 20.0f, 3.0f, none),
				ModelTransform.pivot(-5.5f, 2.5f, -1.5f));

		return TexturedModelData.of(data, 64, 64);
	}

	@Override
	public void setAngles(T entity, float limbAngle, float limbDistance, float animationProgress,
						  float headYaw, float headPitch) {
		float walk = limbAngle * 0.6662f;
		float breath = MathHelper.sin(animationProgress * 0.09f);

		// голова склонена набок, как будто прислушивается
		head.yaw = headYaw * 0.0174533f;
		head.pitch = headPitch * 0.0174533f * 0.5f + 0.2f;
		head.roll = 0.12f + MathHelper.sin(animationProgress * 0.03f) * 0.08f;

		// уши ловят звук: лёгкая дрожь, редкие резкие подёргивания, на бегу прижаты вперёд
		float flick = MathHelper.sin(animationProgress * 0.05f) > 0.9f
				? MathHelper.sin(animationProgress * 1.1f) * 0.14f : 0.0f;
		float forward = MathHelper.clamp(limbDistance, 0.0f, 1.0f) * 0.3f;
		earL.yaw = 0.45f + forward + MathHelper.sin(animationProgress * 0.17f) * 0.04f + flick;
		earR.yaw = -0.45f - forward - MathHelper.sin(animationProgress * 0.17f + 1.3f) * 0.04f - flick;

		// дыхание и сутулость
		torso.pitch = 0.35f + breath * 0.025f;

		legL.pitch = MathHelper.cos(walk) * 1.3f * limbDistance;
		legR.pitch = MathHelper.cos(walk + (float) Math.PI) * 1.3f * limbDistance;

		// руки болтаются, на бегу тянутся вперёд
		float reach = MathHelper.clamp(limbDistance * 1.2f, 0.0f, 0.8f);
		armL.pitch = -0.15f - reach + MathHelper.cos(walk + (float) Math.PI) * 0.7f * limbDistance;
		armR.pitch = -0.15f - reach + MathHelper.cos(walk) * 0.7f * limbDistance;
		armL.roll = 0.06f + breath * 0.02f;
		armR.roll = -0.06f - breath * 0.02f;
	}

	@Override
	public void render(MatrixStack matrices, VertexConsumer vertices, int light, int overlay,
					   float red, float green, float blue, float alpha) {
		root.render(matrices, vertices, light, overlay, red, green, blue, alpha);
	}
}

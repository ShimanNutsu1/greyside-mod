package com.greyside.client;

import com.greyside.GreysideMod;
import com.greyside.ListenerEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.PiglinEntityModel;
import net.minecraft.util.Identifier;

/** Слушатель: модель пиглина (большие уши, гладкое лицо без глаз) с тёмной текстурой. */
public class ListenerRenderer extends MobEntityRenderer<ListenerEntity, PiglinEntityModel<ListenerEntity>> {
	private static final Identifier TEXTURE = GreysideMod.id("textures/entity/listener.png");

	public ListenerRenderer(EntityRendererFactory.Context ctx) {
		super(ctx, new PiglinEntityModel<>(ctx.getPart(EntityModelLayers.PIGLIN)), 0.5f);
	}

	@Override
	public Identifier getTexture(ListenerEntity entity) {
		return TEXTURE;
	}
}

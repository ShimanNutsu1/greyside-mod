package com.greyside.client;

import com.greyside.GreysideMod;
import com.greyside.ListenerEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.util.Identifier;

/** Слушатель: собственная модель (см. {@link ListenerModel}), без глаз, с огромными ушами. */
public class ListenerRenderer extends MobEntityRenderer<ListenerEntity, ListenerModel<ListenerEntity>> {
	private static final Identifier TEXTURE = GreysideMod.id("textures/entity/listener.png");

	public ListenerRenderer(EntityRendererFactory.Context ctx) {
		super(ctx, new ListenerModel<>(ctx.getPart(ListenerModel.LAYER)), 0.5f);
	}

	@Override
	public Identifier getTexture(ListenerEntity entity) {
		return TEXTURE;
	}
}

package com.greyside.client;

import com.greyside.FacelessEntity;
import com.greyside.GreyPhantomEntity;
import com.greyside.GreyNetworking;
import com.greyside.ListenerEntity;
import com.greyside.SilhouetteEntity;
import com.greyside.GreysideMod;
import com.greyside.ModBlocks;
import com.greyside.ModDimensions;
import com.greyside.ModEntities;
import com.greyside.PeekerEntity;
import com.greyside.mixin.GameRendererAccessor;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.entity.mob.AbstractSkeletonEntity;
import net.minecraft.entity.mob.ZombieEntity;

import java.util.Objects;

public class GreysideClient implements ClientModInitializer {
	private static int level = 0;
	private static String currentShader = null;

	@Override
	public void onInitializeClient() {
		EntityRendererRegistry.register(ModEntities.SHADOW, (EntityRendererFactory<ZombieEntity>) ShadowRenderer::new);
		EntityModelLayerRegistry.registerModelLayer(FacelessModel.LAYER, FacelessModel::getTexturedModelData);
		EntityRendererRegistry.register(ModEntities.PEEKER, (EntityRendererFactory<PeekerEntity>) PeekerRenderer::new);
		FearOverlay.init();
		EntityRendererRegistry.register(ModEntities.FACELESS, (EntityRendererFactory<FacelessEntity>) FacelessRenderer::new);
		EntityRendererRegistry.register(ModEntities.SILHOUETTE, (EntityRendererFactory<SilhouetteEntity>) SilhouetteRenderer::new);
		EntityModelLayerRegistry.registerModelLayer(GreyPhantomModel.LAYER, GreyPhantomModel::getTexturedModelData);
		EntityRendererRegistry.register(ModEntities.GREY_PHANTOM, (EntityRendererFactory<GreyPhantomEntity>) GreyPhantomRenderer::new);
		EntityRendererRegistry.register(ModEntities.SHADE_ARCHER, (EntityRendererFactory<AbstractSkeletonEntity>) ShadeArcherRenderer::new);
		EntityModelLayerRegistry.registerModelLayer(ListenerModel.LAYER, ListenerModel::getTexturedModelData);
		EntityRendererRegistry.register(ModEntities.LISTENER, (EntityRendererFactory<ListenerEntity>) ListenerRenderer::new);
		BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.RIFT, RenderLayer.getTranslucent());

		ClientPlayNetworking.registerGlobalReceiver(GreyNetworking.LEVEL_PACKET, (client, handler, buf, sender) -> {
			int l = buf.readInt();
			client.execute(() -> level = l);
		});

		ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
			level = 0;
			currentShader = null;
			client.gameRenderer.disablePostProcessor();
		});

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			if (client.world == null || client.player == null) return;

			String want;
			if (client.world.getRegistryKey() == ModDimensions.GREYSIDE) want = "grey_full";
			else if (level >= 1) want = "grey_" + Math.min(level, 5);
			else want = null;

			if (!Objects.equals(want, currentShader)) {
				if (want == null) {
					client.gameRenderer.disablePostProcessor();
				} else {
					((GameRendererAccessor) client.gameRenderer)
							.greyside$loadPostProcessor(GreysideMod.id("shaders/post/" + want + ".json"));
				}
				currentShader = want;
			}
		});
	}
}

package com.greyside.client;

import com.greyside.GreysideMod;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.SkeletonEntityRenderer;
import net.minecraft.entity.mob.AbstractSkeletonEntity;
import net.minecraft.util.Identifier;

public class ShadeArcherRenderer extends SkeletonEntityRenderer {
	private static final Identifier TEXTURE = GreysideMod.id("textures/entity/black.png");

	public ShadeArcherRenderer(EntityRendererFactory.Context ctx) {
		super(ctx);
	}

	@Override
	public Identifier getTexture(AbstractSkeletonEntity entity) {
		return TEXTURE;
	}
}

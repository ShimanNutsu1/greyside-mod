package com.greyside;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;

/**
 * Безликий. Нельзя убить. Замирает, пока на него смотрят, и на клиенте вообще не рисуется
 * в центре экрана (виден только краем). Стоит отвернуться, и он бросается к тебе.
 * Касание: урон, слепота, он забирает кусочек мира (+Серость) и исчезает.
 */
public class FacelessEntity extends HostileEntity {
	/** Конус «прямо на него»; должен совпадать с порогом скрытия в FacelessRenderer. */
	public static final double WATCH_DOT = 0.90;
	private static final int MAX_LIFE = 2400; // 2 минуты

	private int life = MAX_LIFE;

	public FacelessEntity(EntityType<? extends FacelessEntity> type, World world) {
		super(type, world);
		this.setPersistent();
	}

	public static DefaultAttributeContainer.Builder createAttributes() {
		return HostileEntity.createHostileAttributes()
				.add(EntityAttributes.GENERIC_MAX_HEALTH, 40.0)
				.add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.36)
				.add(EntityAttributes.GENERIC_FOLLOW_RANGE, 64.0)
				.add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 10.0);
	}

	@Override
	public boolean damage(DamageSource source, float amount) {
		// убегать, а не драться: неуязвим (кроме /kill и пустоты)
		if (source.isIn(DamageTypeTags.BYPASSES_INVULNERABILITY)) return super.damage(source, amount);
		return false;
	}

	@Override
	public boolean canImmediatelyDespawn(double distanceSquared) {
		return false;
	}

	@Override
	public void tick() {
		super.tick();
		if (getWorld().isClient) return;

		if (--life <= 0) {
			vanish();
			return;
		}

		PlayerEntity target = getWorld().getClosestPlayer(getX(), getY(), getZ(), 64.0, true);
		if (target == null) {
			vanish();
			return;
		}

		boolean watched = GreyMobs.isLookedAt(target, this, WATCH_DOT);
		if (watched) {
			getNavigation().stop();
			setVelocity(0, getVelocity().y, 0);
		} else {
			getNavigation().startMovingTo(target, 1.2);
		}

		// сердцебиение: чем ближе, тем чаще
		float dist = distanceTo(target);
		int interval = MathHelper.clamp((int) (dist * 2), 14, 60);
		if (age % interval == 0) {
			getWorld().playSound(null, target.getBlockPos(), SoundEvents.ENTITY_WARDEN_HEARTBEAT,
					SoundCategory.HOSTILE, 1.0f, 0.8f);
		}

		if (!watched && squaredDistanceTo(target) < 2.5) {
			strike(target);
		}
	}

	private void strike(PlayerEntity target) {
		target.damage(getDamageSources().mobAttack(this), 10.0f);
		target.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 100, 0));
		target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 100, 1));
		target.sendMessage(Text.translatable("message.greyside.faceless_hit"), true);
		getWorld().playSound(null, target.getBlockPos(), SoundEvents.ENTITY_ENDERMAN_SCREAM,
				SoundCategory.HOSTILE, 1.0f, 0.4f);
		if (getWorld() instanceof ServerWorld sw) {
			GreyState.get(sw.getServer()).add(1200); // забрал кусочек мира: +1 минута Серости
		}
		if (target instanceof net.minecraft.server.network.ServerPlayerEntity sp) {
			GreyEvents.resetVisit(sp.getUuid());
		}
		vanish();
	}

	private void vanish() {
		if (getWorld() instanceof ServerWorld sw) {
			sw.spawnParticles(ParticleTypes.LARGE_SMOKE, getX(), getY() + 1.5, getZ(), 25, 0.3, 0.8, 0.3, 0.01);
		}
		discard();
	}
}

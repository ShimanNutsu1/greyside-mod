package com.greyside;

import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Безликий. Нельзя убить. Замирает, пока на него смотрят, и на клиенте вообще не рисуется
 * в центре экрана (виден только краем). Стоит отвернуться, и он бросается к тебе.
 *
 * <h3>Способности (0.5)</h3>
 * <ul>
 *   <li><b>Нарастающий бег.</b> Чем дольше на него не смотрят, тем он быстрее (до +40%). Взгляд сбрасывает разгон.</li>
 *   <li><b>Шаг в тень.</b> Исчезает и появляется за спиной (5-7 блоков). За секунду до этого щёлкающий звук
 *       и дым в точке появления. Если успеть повернуться к этой точке, шаг срывается. Не чаще раза в 10 с, 3 раза за визит.</li>
 *   <li><b>Гашение света.</b> Рядом с ним (до 8 блоков) гаснут факелы и фонари, по 2 за 3 секунды.</li>
 *   <li><b>Страх.</b> Вблизи (до 14 блоков), пока на него не смотрят, накатывает Тьма. Маска Пустоты защищает.</li>
 *   <li><b>Шёпот за спиной.</b> Редкий звук позади игрока.</li>
 *   <li><b>Касание.</b> 10-14 урона (растёт с Серостью), слепота, замедление, срывает 60 прочности с маски.</li>
 * </ul>
 *
 * <h3>Логово</h3>
 * Безликий из логова (см. {@link com.greyside.worldgen.GreyPiece}) привязан к своему дому: не исчезает по таймеру,
 * не выходит дальше {@link #LAIR_RADIUS} блоков, после касания не пропадает, а возвращается домой и 10 секунд
 * не может бить. Открытие его сундука приводит его в ярость на 30 секунд.
 */
public class FacelessEntity extends HostileEntity {
	/** Конус «прямо на него»; должен совпадать с порогом скрытия в FacelessRenderer. */
	public static final double WATCH_DOT = 0.90;
	/** Конус с Маской Наблюдателя: он замирает, даже когда виден лишь краем глаза. */
	public static final double WATCH_DOT_MASK = 0.72;

	private static final int MAX_LIFE = 2400; // 2 минуты
	private static final int LAIR_RADIUS = 14;
	private static final int LAIR_STRIKE_COOLDOWN = 200;
	private static final int RAGE_TICKS = 600;
	private static final int BLINK_WARN = 25;
	private static final int MAX_BLINKS = 3;

	private int life = MAX_LIFE;
	private BlockPos home;
	private BlockPos chest;

	private int unwatched = 0;
	private int strikeCd = 0;
	private int rage = 0;
	private int blinkCd = 200;
	private int blinkWarn = 0;
	private int blinks = 0;
	private Vec3d blinkTo;
	private int snuffCd = 0;
	private int dreadCd = 0;
	private int whisperCd = 160;

	public FacelessEntity(EntityType<? extends FacelessEntity> type, World world) {
		super(type, world);
		this.setPersistent();
	}

	public static DefaultAttributeContainer.Builder createAttributes() {
		return HostileEntity.createHostileAttributes()
				.add(EntityAttributes.GENERIC_MAX_HEALTH, 40.0)
				.add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.34)
				.add(EntityAttributes.GENERIC_FOLLOW_RANGE, 64.0)
				.add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 10.0);
	}

	/** Конус «смотрит прямо на него» для конкретного игрока (сервер и клиент считают одинаково). */
	public static double watchDotFor(net.minecraft.entity.Entity viewer) {
		return viewer instanceof PlayerEntity p && MaskItem.wearing(p, MaskItem.Kind.WATCHER) ? WATCH_DOT_MASK : WATCH_DOT;
	}

	// ---------- логово ----------

	public boolean isLair() {
		return home != null;
	}

	public void setLair(BlockPos home, BlockPos chest) {
		this.home = home;
		this.chest = chest;
	}

	/** Игрок открыл сундук логова. */
	public void enrage() {
		rage = RAGE_TICKS;
		blinkCd = Math.min(blinkCd, 40);
	}

	/** Слушаем открытие сундука: тот, кто живёт в логове, это чувствует. */
	public static void initEvents() {
		UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
			if (!(world instanceof ServerWorld sw) || player.isSpectator()) return ActionResult.PASS;
			BlockPos p = hit.getBlockPos();
			if (!sw.getBlockState(p).isOf(Blocks.CHEST)) return ActionResult.PASS;
			for (FacelessEntity f : sw.getEntitiesByType(ModEntities.FACELESS, new Box(p).expand(32), e -> e.isLair() && p.equals(e.chest))) {
				if (f.rage <= 0) {
					player.sendMessage(Text.translatable("message.greyside.lair_stir"), true);
					sw.playSound(null, p, SoundEvents.ENTITY_WARDEN_ROAR, SoundCategory.HOSTILE, 0.6f, 0.5f);
				}
				f.enrage();
			}
			return ActionResult.PASS;
		});
	}

	// ---------- общее ----------

	@Override
	public boolean damage(DamageSource source, float amount) {
		// убегать, а не драться: неуязвим (кроме /kill и пустоты)
		if (source.isIn(DamageTypeTags.BYPASSES_INVULNERABILITY)) return super.damage(source, amount);
		return false;
	}

	@Override
	public boolean canImmediatelyDespawn(double distanceSquared) {
		return false;
	}

	@Override
	public void writeCustomDataToNbt(NbtCompound nbt) {
		super.writeCustomDataToNbt(nbt);
		nbt.putInt("Life", life);
		if (home != null) {
			nbt.putIntArray("LairHome", new int[]{home.getX(), home.getY(), home.getZ()});
			if (chest != null) nbt.putIntArray("LairChest", new int[]{chest.getX(), chest.getY(), chest.getZ()});
		}
	}

	@Override
	public void readCustomDataFromNbt(NbtCompound nbt) {
		super.readCustomDataFromNbt(nbt);
		if (nbt.contains("Life")) life = nbt.getInt("Life");
		int[] h = nbt.getIntArray("LairHome");
		if (h.length == 3) home = new BlockPos(h[0], h[1], h[2]);
		int[] c = nbt.getIntArray("LairChest");
		if (c.length == 3) chest = new BlockPos(c[0], c[1], c[2]);
	}

	// ---------- логика ----------

	@Override
	public void tick() {
		super.tick();
		if (getWorld().isClient || !(getWorld() instanceof ServerWorld sw)) return;

		if (strikeCd > 0) strikeCd--;
		if (rage > 0) rage--;
		if (blinkCd > 0) blinkCd--;
		if (snuffCd > 0) snuffCd--;
		if (dreadCd > 0) dreadCd--;
		if (whisperCd > 0) whisperCd--;

		if (!isLair() && --life <= 0) {
			vanish();
			return;
		}

		PlayerEntity target = findTarget(sw);
		if (target == null) {
			if (isLair()) {
				idleAtHome();
			} else {
				vanish();
			}
			return;
		}

		boolean watched = GreyMobs.isLookedAt(target, this, watchDotFor(target));
		double dist = distanceTo(target);

		// нарастающий бег: отвернулся надолго, и он уже не человеческий шаг
		if (watched) {
			unwatched = unwatched / 2;
			getNavigation().stop();
			setVelocity(0, getVelocity().y, 0);
			getLookControl().lookAt(target, 60f, 60f);
		} else {
			unwatched++;
			double ramp = 1.0 + Math.min(0.4, (unwatched / 40) * 0.07) + (rage > 0 ? 0.2 : 0.0);
			if (blinkWarn == 0) getNavigation().startMovingTo(target, 1.2 * ramp);
		}

		heartbeat(sw, target, dist);
		if (!watched) {
			blink(sw, target, dist);
			dread(target, dist);
		}
		if (blinkWarn > 0) tickBlinkWarning(sw, target);
		snuff(sw, dist);
		whisper(sw, target);

		if (!watched && strikeCd == 0 && squaredDistanceTo(target) < 2.5) {
			strike(sw, target);
		}
	}

	/** Роуминг: ближайший игрок на 64. Логово: ближайший игрок рядом с домом. */
	private PlayerEntity findTarget(ServerWorld sw) {
		if (!isLair()) return sw.getClosestPlayer(getX(), getY(), getZ(), 64.0, true);
		PlayerEntity p = sw.getClosestPlayer(home.getX() + 0.5, home.getY(), home.getZ() + 0.5, LAIR_RADIUS, true);
		return p;
	}

	private void idleAtHome() {
		if (home.getSquaredDistance(getX(), getY(), getZ()) > 9) {
			getNavigation().startMovingTo(home.getX() + 0.5, home.getY(), home.getZ() + 0.5, 0.9);
		} else {
			getNavigation().stop();
		}
		unwatched = 0;
		blinkWarn = 0;
		blinkTo = null;
	}

	/** Сердцебиение: чем ближе, тем чаще. */
	private void heartbeat(ServerWorld sw, PlayerEntity target, double dist) {
		int interval = MathHelper.clamp((int) (dist * 2), 14, 60);
		if (age % interval == 0) {
			sw.playSound(null, target.getBlockPos(), SoundEvents.ENTITY_WARDEN_HEARTBEAT,
					SoundCategory.HOSTILE, 1.0f, 0.8f);
		}
	}

	// ---------- Шаг в тень ----------

	private void blink(ServerWorld sw, PlayerEntity target, double dist) {
		if (blinkWarn > 0 || blinkCd > 0 || dist < 9 || dist > 30) return;
		if (!isLair() && blinks >= MAX_BLINKS) return;
		if (random.nextInt(rage > 0 ? 20 : 60) != 0) return;

		Vec3d look = target.getRotationVec(1.0f);
		Vec3d back = new Vec3d(-look.x, 0, -look.z);
		if (back.lengthSquared() < 1.0E-4) return;
		back = back.normalize();
		double d = 5.0 + random.nextDouble() * 2.0;
		int x = MathHelper.floor(target.getX() + back.x * d);
		int z = MathHelper.floor(target.getZ() + back.z * d);
		if (!sw.isChunkLoaded(new BlockPos(x, 0, z))) return;
		BlockPos g = GreyMobs.findGround(sw, x, z, target.getBlockY());
		if (g == null) return;
		if (isLair() && g.getSquaredDistance(home) > LAIR_RADIUS * LAIR_RADIUS) return;

		blinkTo = new Vec3d(g.getX() + 0.5, g.getY(), g.getZ() + 0.5);
		blinkWarn = BLINK_WARN;
		getNavigation().stop();
		// предупреждение: щелчки у самого уха
		sw.playSound(null, target.getBlockPos(), SoundEvents.ENTITY_WARDEN_TENDRIL_CLICKS,
				SoundCategory.HOSTILE, 1.0f, 0.7f);
	}

	private void tickBlinkWarning(ServerWorld sw, PlayerEntity target) {
		if (blinkTo == null) {
			blinkWarn = 0;
			return;
		}
		sw.spawnParticles(ParticleTypes.SMOKE, blinkTo.x, blinkTo.y + 1.0, blinkTo.z, 4, 0.25, 0.8, 0.25, 0.01);
		if (--blinkWarn > 0) return;

		// успел повернуться к точке: шаг срывается
		Vec3d look = target.getRotationVec(1.0f).normalize();
		Vec3d to = blinkTo.add(0, 1.0, 0).subtract(target.getEyePos()).normalize();
		if (look.dotProduct(to) > 0.5) {
			blinkCd = 100;
			blinkTo = null;
			return;
		}
		sw.spawnParticles(ParticleTypes.LARGE_SMOKE, getX(), getY() + 1.5, getZ(), 15, 0.3, 0.8, 0.3, 0.01);
		refreshPositionAndAngles(blinkTo.x, blinkTo.y, blinkTo.z, getYaw(), 0f);
		getNavigation().stop();
		sw.playSound(null, target.getBlockPos(), SoundEvents.ENTITY_ENDERMAN_TELEPORT,
				SoundCategory.HOSTILE, 0.8f, 0.4f);
		blinks++;
		blinkCd = 200;
		blinkTo = null;
	}

	// ---------- Гашение света ----------

	private void snuff(ServerWorld sw, double dist) {
		if (snuffCd > 0 || dist > 14) return;
		snuffCd = 60;
		int broken = 0;
		BlockPos c = getBlockPos();
		for (BlockPos p : BlockPos.iterateOutwards(c, 8, 4, 8)) {
			if (broken >= 2) break;
			BlockState s = sw.getBlockState(p);
			if (s.isOf(Blocks.TORCH) || s.isOf(Blocks.WALL_TORCH) || s.isOf(Blocks.SOUL_TORCH)
					|| s.isOf(Blocks.SOUL_WALL_TORCH) || s.isOf(Blocks.LANTERN) || s.isOf(Blocks.SOUL_LANTERN)) {
				sw.breakBlock(p, false, this);
				broken++;
			}
		}
	}

	// ---------- Страх ----------

	private void dread(PlayerEntity target, double dist) {
		if (dreadCd > 0 || dist > 14 || MaskItem.wearing(target, MaskItem.Kind.VOID)
				|| MaskItem.wearing(target, MaskItem.Kind.ION)) return;
		dreadCd = 40;
		target.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 60, 0, true, false, false));
	}

	// ---------- Шёпот за спиной ----------

	private void whisper(ServerWorld sw, PlayerEntity target) {
		if (whisperCd > 0) return;
		whisperCd = 160 + random.nextInt(200);
		Vec3d look = target.getRotationVec(1.0f);
		Vec3d p = target.getPos().add(-look.x * 3, 0, -look.z * 3);
		sw.playSound(null, BlockPos.ofFloored(p), ModSounds.WHISPER, SoundCategory.HOSTILE, 1.0f, 0.7f);
	}

	// ---------- Касание ----------

	private void strike(ServerWorld sw, PlayerEntity target) {
		int level = GreyState.get(sw.getServer()).level();
		float dmg = isLair() ? 14.0f : MathHelper.clamp(10.0f + Math.max(0, level - 1), 10.0f, 14.0f);

		target.damage(getDamageSources().mobAttack(this), dmg);
		target.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 100, 0));
		target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 100, 1));
		target.sendMessage(Text.translatable("message.greyside.faceless_hit"), true);
		sw.playSound(null, target.getBlockPos(), SoundEvents.ENTITY_ENDERMAN_SCREAM,
				SoundCategory.HOSTILE, 1.0f, 0.4f);

		// срывает маску: часть прочности
		ItemStack head = target.getEquippedStack(EquipmentSlot.HEAD);
		if (head.getItem() instanceof MaskItem) {
			head.damage(MaskItem.FACELESS_DAMAGE, target, p -> p.sendEquipmentBreakStatus(EquipmentSlot.HEAD));
			target.sendMessage(Text.translatable("message.greyside.mask_torn"), true);
		}

		// Серость: забрал кусочек мира, +1 минута
		GreyState.get(sw.getServer()).add(1200);
		if (target instanceof ServerPlayerEntity sp) {
			GreyEvents.resetVisit(sp.getUuid());
		}

		if (isLair()) {
			// не исчезает: уходит домой и копит силы
			sw.spawnParticles(ParticleTypes.LARGE_SMOKE, getX(), getY() + 1.5, getZ(), 25, 0.3, 0.8, 0.3, 0.01);
			refreshPositionAndAngles(home.getX() + 0.5, home.getY(), home.getZ() + 0.5, getYaw(), 0f);
			getNavigation().stop();
			strikeCd = LAIR_STRIKE_COOLDOWN;
			unwatched = 0;
			rage = 0;
			blinkCd = 200;
		} else {
			vanish();
		}
	}

	private void vanish() {
		if (getWorld() instanceof ServerWorld sw) {
			sw.spawnParticles(ParticleTypes.LARGE_SMOKE, getX(), getY() + 1.5, getZ(), 25, 0.3, 0.8, 0.3, 0.01);
		}
		discard();
	}
}

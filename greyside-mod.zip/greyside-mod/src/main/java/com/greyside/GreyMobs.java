package com.greyside;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PhantomEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/** Общие хелперы: спавн мобов Изнанки и проверка «смотрит ли игрок на существо». */
public final class GreyMobs {
	private GreyMobs() {}

	/** Ищет клетку с воздухом в 2 блока высотой и твёрдым полом рядом с высотой aroundY. */
	public static BlockPos findGround(ServerWorld w, int x, int z, int aroundY) {
		for (int dy = 8; dy >= -8; dy--) {
			BlockPos pos = new BlockPos(x, aroundY + dy, z);
			if (w.getBlockState(pos).isAir() && w.getBlockState(pos.up()).isAir()
					&& w.getBlockState(pos.down()).isSolidBlock(w, pos.down())) {
				return pos;
			}
		}
		return null;
	}

	public static <T extends MobEntity> T spawnAt(EntityType<T> type, ServerWorld w, BlockPos pos) {
		T mob = type.create(w);
		if (mob == null) return null;
		mob.refreshPositionAndAngles(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, w.random.nextFloat() * 360f, 0f);
		if (mob instanceof ShadeArcherEntity archer) {
			archer.equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.BOW));
		}
		if (mob instanceof PhantomEntity phantom) {
			phantom.setPhantomSize(1);
		}
		w.spawnEntity(mob);
		return mob;
	}

	public static <T extends Entity> int countNear(ServerWorld w, EntityType<T> type, Box box) {
		return w.getEntitiesByType(type, box, e -> true).size();
	}

	/** true, если существо находится в конусе взгляда игрока и в прямой видимости. */
	public static boolean isLookedAt(PlayerEntity player, Entity target, double minDot) {
		Vec3d look = player.getRotationVec(1.0f).normalize();
		Vec3d to = target.getBoundingBox().getCenter().subtract(player.getEyePos()).normalize();
		return look.dotProduct(to) > minDot && player.canSee(target);
	}
}

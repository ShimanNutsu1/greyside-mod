package com.greyside;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.world.World;

/** Тень: чёрный зомби, который не горит на солнце и видит игрока издалека. */
public class ShadowEntity extends ZombieEntity {
	public ShadowEntity(EntityType<? extends ShadowEntity> type, World world) {
		super(type, world);
	}

	public static DefaultAttributeContainer.Builder createShadowAttributes() {
		return ZombieEntity.createZombieAttributes()
				.add(EntityAttributes.GENERIC_MAX_HEALTH, 26.0)
				.add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.26)
				.add(EntityAttributes.GENERIC_FOLLOW_RANGE, 48.0);
	}

	@Override
	protected boolean burnsInDaylight() {
		return false;
	}
}

package com.greyside;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.PersistentState;

/** Общая на сервер шкала Серости. Копится, пока кто-то находится в Изнанке. */
public class GreyState extends PersistentState {
	/** Тики пребывания в Изнанке (суммарно по всем игрокам), нужные для уровней 1..5. */
	public static final long[] THRESHOLDS = {6000L, 18000L, 36000L, 72000L, 144000L};

	private long greyTicks = 0;

	public static int levelFor(long ticks) {
		int level = 0;
		for (long t : THRESHOLDS) if (ticks >= t) level++;
		return level;
	}

	public int level() { return levelFor(greyTicks); }
	public long ticks() { return greyTicks; }
	public void add(long t) { greyTicks += t; markDirty(); }
	public void set(long t) { greyTicks = Math.max(0, t); markDirty(); }

	/** Снижает Серость ровно на один уровень (до порога предыдущего). */
	public void reduceLevel() {
		int l = level();
		if (l <= 0) return;
		set(l == 1 ? 0 : THRESHOLDS[l - 2]);
	}

	@Override
	public NbtCompound writeNbt(NbtCompound nbt) {
		nbt.putLong("greyTicks", greyTicks);
		return nbt;
	}

	public static GreyState fromNbt(NbtCompound nbt) {
		GreyState s = new GreyState();
		s.greyTicks = nbt.getLong("greyTicks");
		return s;
	}

	public static GreyState get(MinecraftServer server) {
		return server.getOverworld().getPersistentStateManager()
				.getOrCreate(GreyState::fromNbt, GreyState::new, GreysideMod.MOD_ID);
	}
}

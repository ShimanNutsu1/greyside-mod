package com.greyside;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.PersistentState;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Дом каждого игрока: точка в обычном мире, чью тёмную копию строит Изнанка. */
public class HomeState extends PersistentState {
	public static final class Home {
		public final BlockPos pos;
		/** Первичное копирование области уже завершено. */
		public boolean scanned;
		/** Дом задан командой, кровать его не меняет. */
		public final boolean manual;

		public Home(BlockPos pos, boolean scanned, boolean manual) {
			this.pos = pos.toImmutable();
			this.scanned = scanned;
			this.manual = manual;
		}
	}

	private final Map<UUID, Home> homes = new HashMap<>();

	public Map<UUID, Home> all() { return homes; }
	public Home get(UUID id) { return homes.get(id); }

	public void put(UUID id, Home home) {
		homes.put(id, home);
		markDirty();
	}

	public void markScanned(UUID id, BlockPos pos) {
		Home h = homes.get(id);
		if (h != null && h.pos.equals(pos) && !h.scanned) {
			h.scanned = true;
			markDirty();
		}
	}

	@Override
	public NbtCompound writeNbt(NbtCompound nbt) {
		NbtList list = new NbtList();
		for (Map.Entry<UUID, Home> e : homes.entrySet()) {
			NbtCompound c = new NbtCompound();
			c.putString("owner", e.getKey().toString());
			c.putLong("pos", e.getValue().pos.asLong());
			c.putBoolean("scanned", e.getValue().scanned);
			c.putBoolean("manual", e.getValue().manual);
			list.add(c);
		}
		nbt.put("homes", list);
		return nbt;
	}

	public static HomeState fromNbt(NbtCompound nbt) {
		HomeState s = new HomeState();
		NbtList list = nbt.getList("homes", NbtElement.COMPOUND_TYPE);
		for (int i = 0; i < list.size(); i++) {
			NbtCompound c = list.getCompound(i);
			try {
				UUID id = UUID.fromString(c.getString("owner"));
				s.homes.put(id, new Home(BlockPos.fromLong(c.getLong("pos")), c.getBoolean("scanned"), c.getBoolean("manual")));
			} catch (IllegalArgumentException ignored) {
				// битая запись: пропускаем
			}
		}
		return s;
	}

	public static HomeState get(MinecraftServer server) {
		return server.getOverworld().getPersistentStateManager()
				.getOrCreate(HomeState::fromNbt, HomeState::new, GreysideMod.MOD_ID + "_homes");
	}
}

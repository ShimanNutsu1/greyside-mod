package com.greyside;

import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;

public enum GreyToolMaterial implements ToolMaterial {
	INSTANCE;

	@Override public int getDurability() { return 900; }
	@Override public float getMiningSpeedMultiplier() { return 7.0f; }
	@Override public float getAttackDamage() { return 3.5f; }
	@Override public int getMiningLevel() { return 3; }
	@Override public int getEnchantability() { return 18; }
	@Override public Ingredient getRepairIngredient() { return Ingredient.ofItems(ModItems.GREY_DUST); }
}

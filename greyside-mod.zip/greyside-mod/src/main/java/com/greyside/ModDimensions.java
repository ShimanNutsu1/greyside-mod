package com.greyside;

import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.world.World;

public final class ModDimensions {
	/** Серая Изнанка: измерение с тем же сидом и генерацией, что и обычный мир. */
	public static final RegistryKey<World> GREYSIDE = RegistryKey.of(RegistryKeys.WORLD, GreysideMod.id("grey"));

	private ModDimensions() {}
}

package com.greyside;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.EvokerFangsEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.entity.Entity;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.Animation;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

import net.minecraft.entity.projectile.ShulkerBulletEntity;
import net.minecraft.util.math.Direction;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Ион, Безликий: финальный босс. Обычная жёсткая схватка, его можно убить мечом.
 * <ul>
 *   <li><b>Фаза 1</b>: удар резцом, рывок к игроку, удар в землю (за секунду предупреждение, нужно прыгнуть).</li>
 *   <li><b>Фаза 2</b> (меньше 50% здоровья): быстрее, шипы-«лица» вокруг игрока, вспышка тьмы и шаг
 *       за спину, приспешники из Теней и Силуэтов (не больше 6 одновременно).</li>
 * </ul>
 * Пока босс жив, у него есть полоска здоровья. Победа снимает всю Серость и возвращает маски на постаменты.
 * Если рядом нет ни одного живого игрока 3 секунды (все погибли или ушли), бой сбрасывается, маски тоже возвращаются.
 */
public class IonEntity extends HostileEntity implements GeoEntity {
	public static final String MINION_TAG = "greyside_ion_minion";

	private static final RawAnimation IDLE = RawAnimation.begin().thenLoop("animation.ion.idle");
	private static final RawAnimation WALK = RawAnimation.begin().thenLoop("animation.ion.walk");
	private static final RawAnimation AMBIENT = RawAnimation.begin().thenLoop("animation.ion.ambient");
	private static final RawAnimation ATTACK = RawAnimation.begin().then("animation.ion.attack", Animation.LoopType.PLAY_ONCE);
	private static final RawAnimation SLAM = RawAnimation.begin().then("animation.ion.slam", Animation.LoopType.PLAY_ONCE);

	private final AnimatableInstanceCache geoCache = GeckoLibUtil.createInstanceCache(this);

	private final ServerBossBar bossBar = new ServerBossBar(Text.translatable("entity.greyside.ion"),
			BossBar.Color.WHITE, BossBar.Style.PROGRESS);
	private final List<BlockPos> pedestals = new ArrayList<>();
	private boolean phase2 = false;
	private int slamCd = 300;
	private int slamWind = 0;
	private int dashCd = 160;
	private int facesCd = 240;
	private int darkCd = 400;
	private int minionCd = 300;
	private int lonely = 0;
	private int pullCd = 700;
	private int pullWind = 0;
	private int barrageCd = 420;
	private int ringStep = 0;
	private int ringTimer = 0;
	private boolean berserk = false;
	/** Сколько тиков каждый игрок смотрит прямо на него. */
	private final Map<UUID, Integer> gaze = new HashMap<>();

	public IonEntity(EntityType<? extends IonEntity> type, World world) {
		super(type, world);
		this.setPersistent();
		this.experiencePoints = 200;
	}

	public static DefaultAttributeContainer.Builder createAttributes() {
		return HostileEntity.createHostileAttributes()
				.add(EntityAttributes.GENERIC_MAX_HEALTH, 450.0)
				.add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.29)
				.add(EntityAttributes.GENERIC_FOLLOW_RANGE, 64.0)
				.add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 20.0)
				.add(EntityAttributes.GENERIC_ARMOR, 8.0)
				.add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 1.0);
	}

	@Override
	protected void initGoals() {
		this.goalSelector.add(1, new SwimGoal(this));
		this.goalSelector.add(2, new MeleeAttackGoal(this, 1.0, false));
		this.goalSelector.add(8, new LookAtEntityGoal(this, PlayerEntity.class, 32.0f));
		this.targetSelector.add(1, new RevengeGoal(this));
		this.targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
	}

	/** Запоминает постаменты, с которых сняты маски (чтобы вернуть их после боя). */
	public void setPedestals(List<BlockPos> list) {
		pedestals.clear();
		pedestals.addAll(list);
	}

	/** Нужно и клиенту (смена текстуры): здоровье синхронизируется само, поле phase2 есть только на сервере. */
	public boolean isPhaseTwo() {
		return phase2 || getHealth() <= getMaxHealth() * 0.5f;
	}

	// ---------- анимации (GeckoLib) ----------

	@Override
	public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
		controllers.add(new AnimationController<>(this, "move", 6, this::moveState));
		controllers.add(new AnimationController<>(this, "ambient", 0, state -> state.setAndContinue(AMBIENT)));
		controllers.add(new AnimationController<>(this, "attack", 0, state -> PlayState.STOP)
				.triggerableAnim("attack", ATTACK)
				.triggerableAnim("slam", SLAM));
	}

	private PlayState moveState(AnimationState<IonEntity> state) {
		return state.setAndContinue(state.isMoving() ? WALK : IDLE);
	}

	@Override
	public AnimatableInstanceCache getAnimatableInstanceCache() {
		return geoCache;
	}

	@Override
	public boolean tryAttack(Entity target) {
		if (!getWorld().isClient) triggerAnim("attack", "attack");
		boolean hit = super.tryAttack(target);
		if (hit && target instanceof LivingEntity le) {
			// каждый удар отравляет иссушением
			le.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 100, phase2 ? 1 : 0), this);
		}
		return hit;
	}

	@Override
	public boolean canImmediatelyDespawn(double distanceSquared) {
		return false;
	}

	// ---------- полоска здоровья ----------

	@Override
	public void onStartedTrackingBy(ServerPlayerEntity player) {
		super.onStartedTrackingBy(player);
		bossBar.addPlayer(player);
	}

	@Override
	public void onStoppedTrackingBy(ServerPlayerEntity player) {
		super.onStoppedTrackingBy(player);
		bossBar.removePlayer(player);
	}

	@Override
	public void remove(RemovalReason reason) {
		bossBar.clearPlayers();
		super.remove(reason);
	}

	// ---------- сохранение ----------

	@Override
	public void writeCustomDataToNbt(NbtCompound nbt) {
		super.writeCustomDataToNbt(nbt);
		nbt.putBoolean("Phase2", phase2);
		nbt.putBoolean("Berserk", berserk);
		long[] arr = new long[pedestals.size()];
		for (int i = 0; i < arr.length; i++) arr[i] = pedestals.get(i).asLong();
		nbt.putLongArray("Pedestals", arr);
	}

	@Override
	public void readCustomDataFromNbt(NbtCompound nbt) {
		super.readCustomDataFromNbt(nbt);
		pedestals.clear();
		for (long l : nbt.getLongArray("Pedestals")) pedestals.add(BlockPos.fromLong(l));
		if (nbt.getBoolean("Berserk")) {
			berserk = true;
			EntityAttributeInstance fast = getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
			if (fast != null) fast.setBaseValue(0.40);
		}
		if (nbt.getBoolean("Phase2")) {
			phase2 = true;
			bossBar.setColor(BossBar.Color.RED);
			EntityAttributeInstance speed = getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
			if (speed != null) speed.setBaseValue(0.35);
		}
	}

	// ---------- урон ----------

	@Override
	public boolean damage(DamageSource source, float amount) {
		if (source.getAttacker() instanceof LivingEntity a) {
			ItemStack held = a.getMainHandStack();
			if (held.isOf(ModItems.GREY_BLADE)) amount *= 1.3f;
		}
		return super.damage(source, amount);
	}

	// ---------- логика боя ----------

	@Override
	protected void mobTick() {
		super.mobTick();
		if (!(getWorld() instanceof ServerWorld sw)) return;

		bossBar.setPercent(Math.max(0.0f, getHealth() / getMaxHealth()));
		if (!phase2 && getHealth() <= getMaxHealth() * 0.5f) enterPhase2(sw);
		if (!berserk && getHealth() <= getMaxHealth() * 0.25f) enterBerserk(sw);

		List<ServerPlayerEntity> players = sw.getPlayers(p -> p.isAlive() && !p.isSpectator() && p.squaredDistanceTo(this) < 4900);
		if (players.isEmpty()) {
			if (++lonely > 60) {
				restoreMasks(sw);
				clearMinions(sw);
				discard();
			}
			return;
		}
		lonely = 0;

		LivingEntity t = getTarget();
		if (t == null || !t.isAlive()) {
			setTarget(players.get(0));
			t = getTarget();
		}
		if (t == null) return;

		// в берсерке все перезарядки идут вдвое быстрее
		int step = berserk ? 2 : 1;
		if (slamCd > 0) slamCd -= step;
		if (dashCd > 0) dashCd -= step;
		if (facesCd > 0) facesCd -= step;
		if (darkCd > 0) darkCd -= step;
		if (minionCd > 0) minionCd -= step;
		if (pullCd > 0) pullCd -= step;
		if (barrageCd > 0) barrageCd -= step;

		// проклятие взгляда: нельзя смотреть на него долго, но и отвернуться опасно
		if (age % 4 == 0) tickGaze(sw, players);

		// расходящиеся кольца после удара в землю (фаза 2)
		if (ringStep > 0 && --ringTimer <= 0) {
			ring(sw, ringStep);
			ringStep = ringStep < 3 ? ringStep + 1 : 0;
			ringTimer = 10;
		}

		// притяжение: полсекунды видно и слышно, потом всех втягивает к нему
		if (pullWind > 0) {
			pullWind--;
			sw.spawnParticles(ParticleTypes.PORTAL, getX(), getY() + 2.5, getZ(), 40, 5.0, 3.0, 5.0, 0.4);
			if (pullWind == 0) doPull(sw, players);
		} else if (phase2 && pullCd <= 0) {
			pullWind = 30;
			pullCd = 700;
			sw.playSound(null, getBlockPos(), SoundEvents.ENTITY_WARDEN_SONIC_CHARGE, SoundCategory.HOSTILE, 3.0f, 0.7f);
		}

		// удар в землю: за секунду видно дым, нужно прыгнуть
		if (slamWind > 0) {
			getNavigation().stop();
			slamWind--;
			sw.spawnParticles(ParticleTypes.SMOKE, getX(), getY() + 0.1, getZ(), 14, 3.0, 0.05, 3.0, 0.01);
			if (slamWind == 0) doSlam(sw);
		} else if (slamCd <= 0 && distanceTo(t) < 9.0f) {
			slamWind = 20;
			triggerAnim("attack", "slam");
			slamCd = phase2 ? 300 : 400;
			sw.playSound(null, getBlockPos(), SoundEvents.BLOCK_ANVIL_LAND, SoundCategory.HOSTILE, 1.5f, 0.5f);
		}

		// рывок
		if (slamWind == 0 && dashCd <= 0) {
			float d = distanceTo(t);
			if (d > 8.0f && d < 26.0f) {
				Vec3d dir = t.getPos().subtract(getPos());
				dir = new Vec3d(dir.x, 0.0, dir.z).normalize();
				setVelocity(dir.x * 1.5, 0.4, dir.z * 1.5);
				velocityModified = true;
				dashCd = 200;
				playSound(SoundEvents.ENTITY_RAVAGER_ROAR, 1.5f, 0.7f);
			}
		}

		if (phase2) {
			if (facesCd <= 0) {
				facesAttack(sw, t);
				facesCd = 360;
			}
			if (darkCd <= 0) {
				darkStep(sw, t, players);
				darkCd = 500;
			}
			if (minionCd <= 0) {
				spawnMinions(sw);
				minionCd = 400;
			}
			if (barrageCd <= 0) {
				barrage(sw, t);
				barrageCd = 450;
			}
		}
	}

	private void enterPhase2(ServerWorld sw) {
		phase2 = true;
		bossBar.setColor(BossBar.Color.RED);
		EntityAttributeInstance speed = getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
		if (speed != null) speed.setBaseValue(0.35);
		slamCd = Math.min(slamCd, 200);
		facesCd = 100;
		minionCd = 100;
		darkCd = 300;
		sw.playSound(null, getBlockPos(), SoundEvents.ENTITY_WARDEN_ROAR, SoundCategory.HOSTILE, 3.0f, 0.6f);
		sw.spawnParticles(ParticleTypes.END_ROD, getX(), getY() + 3.0, getZ(), 60, 0.8, 1.5, 0.8, 0.08);
		for (ServerPlayerEntity p : sw.getPlayers(pl -> pl.squaredDistanceTo(this) < 6400)) {
			p.sendMessage(Text.translatable("message.greyside.ion_phase2"), true);
		}
		shout(sw);
	}

	/** Крик: отбрасывает всех рядом и бьёт по ушам. */
	private void shout(ServerWorld sw) {
		for (ServerPlayerEntity p : sw.getPlayers(pl -> pl.isAlive() && !pl.isSpectator() && pl.squaredDistanceTo(this) < 196.0)) {
			Vec3d away = p.getPos().subtract(getPos());
			away = new Vec3d(away.x, 0.0, away.z);
			away = away.lengthSquared() < 1.0e-4 ? new Vec3d(1.0, 0.0, 0.0) : away.normalize();
			p.damage(getDamageSources().mobAttack(this), 4.0f);
			p.addVelocity(away.x * 1.6, 0.5, away.z * 1.6);
			p.velocityModified = true;
		}
	}

	private void enterBerserk(ServerWorld sw) {
		berserk = true;
		bossBar.setColor(BossBar.Color.PURPLE);
		EntityAttributeInstance speed = getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
		if (speed != null) speed.setBaseValue(0.40);
		slamCd = 0;
		pullCd = Math.min(pullCd, 100);
		barrageCd = Math.min(barrageCd, 60);
		sw.playSound(null, getBlockPos(), SoundEvents.ENTITY_WARDEN_ROAR, SoundCategory.HOSTILE, 3.0f, 0.4f);
		sw.spawnParticles(ParticleTypes.SOUL_FIRE_FLAME, getX(), getY() + 2.5, getZ(), 80, 1.2, 2.0, 1.2, 0.08);
		for (ServerPlayerEntity p : sw.getPlayers(pl -> pl.squaredDistanceTo(this) < 6400)) {
			p.sendMessage(Text.translatable("message.greyside.ion_berserk"), true);
		}
		shout(sw);
	}

	/** Смотришь прямо на него дольше 2 секунд: тошнота и урон каждую секунду, после 5 секунд ещё и замедление. */
	private void tickGaze(ServerWorld sw, List<ServerPlayerEntity> players) {
		for (ServerPlayerEntity p : players) {
			UUID id = p.getUuid();
			if (p.squaredDistanceTo(this) < 2304.0 && GreyMobs.isLookedAt(p, this, 0.9)) {
				int g = gaze.merge(id, 4, Integer::sum);
				if (g >= 40) {
					p.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 140, 0, false, false, false));
					if (g % 20 == 0) {
						if (g == 40) p.sendMessage(Text.translatable("message.greyside.ion_gaze"), true);
						p.damage(getDamageSources().magic(), 2.0f);
						sw.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_WARDEN_HEARTBEAT, SoundCategory.HOSTILE, 2.0f, 0.8f);
						if (g >= 100) {
							p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 40, 1, false, false, false));
						}
					}
				}
			} else {
				Integer v = gaze.get(id);
				if (v != null) {
					if (v <= 8) gaze.remove(id);
					else gaze.put(id, v - 8);
				}
			}
		}
	}

	/** Втягивает всех в радиусе 30 блоков к Иону. */
	private void doPull(ServerWorld sw, List<ServerPlayerEntity> players) {
		for (ServerPlayerEntity p : players) {
			if (p.squaredDistanceTo(this) > 900.0) continue;
			Vec3d to = getPos().subtract(p.getPos());
			to = new Vec3d(to.x, 0.0, to.z);
			if (to.lengthSquared() < 1.0e-4) continue;
			to = to.normalize();
			p.addVelocity(to.x * 1.3, 0.35, to.z * 1.3);
			p.velocityModified = true;
		}
		slamCd = Math.min(slamCd, 30);
		sw.playSound(null, getBlockPos(), SoundEvents.ENTITY_WARDEN_SONIC_BOOM, SoundCategory.HOSTILE, 3.0f, 0.6f);
	}

	/** Кольцо удара расходится от Иона: нужно перепрыгнуть каждое. */
	private void ring(ServerWorld sw, int stepNo) {
		double r = 6.0 + stepNo * 5.0;
		for (int i = 0; i < 48; i++) {
			double a = i * Math.PI * 2 / 48;
			sw.spawnParticles(ParticleTypes.SMOKE, getX() + Math.cos(a) * r, getY() + 0.2, getZ() + Math.sin(a) * r, 2, 0.1, 0.1, 0.1, 0.01);
		}
		sw.playSound(null, getBlockPos(), SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.HOSTILE, 1.0f, 0.5f + 0.15f * stepNo);
		for (ServerPlayerEntity p : sw.getPlayers(pl -> pl.isAlive() && !pl.isSpectator() && pl.isOnGround())) {
			double dx = p.getX() - getX();
			double dz = p.getZ() - getZ();
			double d = Math.sqrt(dx * dx + dz * dz);
			if (Math.abs(d - r) > 1.6) continue;
			p.damage(getDamageSources().mobAttack(this), 8.0f);
			p.addVelocity(0.0, 0.5, 0.0);
			p.velocityModified = true;
		}
	}

	/** Маски-преследователи: четыре (в берсерке шесть) самонаводящихся снаряда. Попадание: урон и левитация. */
	private void barrage(ServerWorld sw, LivingEntity t) {
		int n = berserk ? 6 : 4;
		for (int i = 0; i < n; i++) {
			double a = i * Math.PI * 2 / n;
			ShulkerBulletEntity b = new ShulkerBulletEntity(sw, this, t, Direction.Axis.Y);
			b.refreshPositionAndAngles(getX() + Math.cos(a) * 2.5, getY() + 4.0, getZ() + Math.sin(a) * 2.5, 0.0f, 0.0f);
			sw.spawnEntity(b);
		}
		sw.playSound(null, getBlockPos(), SoundEvents.ENTITY_SHULKER_SHOOT, SoundCategory.HOSTILE, 2.5f, 0.5f);
	}

	private void doSlam(ServerWorld sw) {
		for (ServerPlayerEntity p : sw.getPlayers(pl -> pl.isAlive() && !pl.isSpectator()
				&& pl.squaredDistanceTo(this) < 64.0 && pl.isOnGround())) {
			p.damage(getDamageSources().mobAttack(this), 14.0f);
			p.addVelocity(0.0, 0.6, 0.0);
			p.velocityModified = true;
		}
		sw.spawnParticles(ParticleTypes.EXPLOSION, getX(), getY() + 0.2, getZ(), 6, 2.5, 0.1, 2.5, 0.0);
		sw.playSound(null, getBlockPos(), SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.HOSTILE, 1.5f, 0.6f);
		if (phase2) {
			ringStep = 1;
			ringTimer = 10;
		}
	}

	/** Шипы под игроком и вокруг него: через секунду вырываются из земли. */
	private void facesAttack(ServerWorld sw, LivingEntity t) {
		double[][] offs = {{0, 0}, {2.5, 0}, {-2.5, 0}, {0, 2.5}, {0, -2.5}};
		for (int i = 0; i < offs.length; i++) {
			EvokerFangsEntity f = new EvokerFangsEntity(sw, t.getX() + offs[i][0], t.getY(), t.getZ() + offs[i][1],
					0.0f, i == 0 ? 30 : 20, this);
			sw.spawnEntity(f);
		}
		sw.playSound(null, getBlockPos(), SoundEvents.ENTITY_EVOKER_PREPARE_ATTACK, SoundCategory.HOSTILE, 2.0f, 0.5f);
	}

	/** Тьма на 2.5 секунды и шаг за спину цели. */
	private void darkStep(ServerWorld sw, LivingEntity t, List<ServerPlayerEntity> players) {
		for (ServerPlayerEntity p : players) {
			p.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 50, 0, false, false, false));
		}
		Vec3d look = t.getRotationVec(1.0f);
		Vec3d flat = new Vec3d(look.x, 0.0, look.z);
		if (flat.lengthSquared() < 1.0e-4) flat = new Vec3d(0.0, 0.0, 1.0);
		flat = flat.normalize();
		Vec3d to = t.getPos().subtract(flat.multiply(3.5));
		requestTeleport(to.x, to.y, to.z);
		sw.playSound(null, to.x, to.y, to.z, SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.HOSTILE, 1.5f, 0.5f);
	}

	private void spawnMinions(ServerWorld sw) {
		List<MobEntity> existing = sw.getEntitiesByClass(MobEntity.class, getBoundingBox().expand(40.0),
				e -> e.getCommandTags().contains(MINION_TAG));
		if (existing.size() >= 8) return;
		for (int i = 0; i < (berserk ? 3 : 2); i++) {
			double ang = sw.random.nextDouble() * Math.PI * 2;
			double dist = 10 + sw.random.nextInt(8);
			int x = (int) Math.round(getX() + Math.cos(ang) * dist);
			int z = (int) Math.round(getZ() + Math.sin(ang) * dist);
			BlockPos g = GreyMobs.findGround(sw, x, z, getBlockY());
			if (g == null) continue;
			MobEntity m;
			if (sw.random.nextBoolean()) m = GreyMobs.spawnAt(ModEntities.SHADOW, sw, g);
			else m = GreyMobs.spawnAt(ModEntities.SILHOUETTE, sw, g);
			if (m != null) {
				m.addCommandTag(MINION_TAG);
				m.setPersistent();
			}
		}
	}

	private void clearMinions(ServerWorld sw) {
		for (MobEntity m : sw.getEntitiesByClass(MobEntity.class, getBoundingBox().expand(70.0),
				e -> e.getCommandTags().contains(MINION_TAG))) {
			sw.spawnParticles(ParticleTypes.SMOKE, m.getX(), m.getY() + 1, m.getZ(), 8, 0.3, 0.5, 0.3, 0.02);
			m.discard();
		}
	}

	/** Освобождает постаменты и выкладывает маски на землю рядом с ними. */
	private void restoreMasks(ServerWorld sw) {
		for (BlockPos p : pedestals) {
			BlockState s = sw.getBlockState(p);
			if (!s.isOf(ModBlocks.MASK_PEDESTAL) || !s.get(MaskPedestalBlock.FILLED)) continue;
			sw.setBlockState(p, s.with(MaskPedestalBlock.FILLED, false), Block.NOTIFY_ALL);
			Block.dropStack(sw, p.up(), new ItemStack(MaskPedestalBlock.maskFor(s.get(MaskPedestalBlock.KIND))));
		}
		pedestals.clear();
	}

	@Override
	public void onDeath(DamageSource source) {
		super.onDeath(source);
		if (!(getWorld() instanceof ServerWorld sw)) return;
		GreyState.get(sw.getServer()).set(0);
		restoreMasks(sw);
		clearMinions(sw);
		for (ServerPlayerEntity p : sw.getPlayers(pl -> pl.squaredDistanceTo(this) < 6400)) {
			p.sendMessage(Text.translatable("message.greyside.ion_defeated"), true);
		}
		sw.spawnParticles(ParticleTypes.END_ROD, getX(), getY() + 2.0, getZ(), 120, 1.5, 2.0, 1.5, 0.12);
		sw.playSound(null, getBlockPos(), SoundEvents.BLOCK_BEACON_ACTIVATE, SoundCategory.HOSTILE, 2.0f, 0.8f);
	}
}

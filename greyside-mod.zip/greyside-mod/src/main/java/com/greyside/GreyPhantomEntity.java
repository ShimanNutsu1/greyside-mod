package com.greyside;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.PhantomEntity;
import net.minecraft.world.World;

/** Серый фантом: чёрный фантом, который атакует с неба днём и ночью (огнеупорный, не горит на солнце). */
public class GreyPhantomEntity extends PhantomEntity {
	public GreyPhantomEntity(EntityType<? extends GreyPhantomEntity> type, World world) {
		super(type, world);
	}
}

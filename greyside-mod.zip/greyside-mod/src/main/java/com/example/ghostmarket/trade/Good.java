package com.example.ghostmarket.trade;

import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;

/**
 * Товар. Сюда в будущих этапах добавятся реальные способности: достаточно реализовать интерфейс
 * и зарегистрировать в GoodRegistry.register(...). Окно, ротация и покупка менять не нужно.
 */
public interface Good {
    ResourceLocation id();

    /** Можно ли выдать товар прямо сейчас (например, хватит ли места в инвентаре). Ничего не меняет. */
    boolean canGive(ServerPlayer player);

    /** Выдаёт товар. false: выдать не удалось, и покупка откатывается с возвратом валюты. */
    boolean give(ServerPlayer player);

    /** Описание для подсказки в окне. Вызывается и на клиенте. */
    Component describe();
}

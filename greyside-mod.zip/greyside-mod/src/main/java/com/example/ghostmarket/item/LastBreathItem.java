package com.example.ghostmarket.item;

import com.example.ghostmarket.config.GhostMarketConfig;
import com.example.ghostmarket.currency.CurrencyRules;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class LastBreathItem extends Item {

    public LastBreathItem(Properties properties) {
        super(properties);
    }

    /**
     * Вызывается каждый тик для выброшенного предмета, и на клиенте, и на сервере.
     * Частицы рисуем только на клиенте.
     */
    @Override
    public boolean onEntityItemUpdate(ItemStack stack, ItemEntity entity) {
        Level level = entity.level();
        if (level.isClientSide() && GhostMarketConfig.SPEC.isLoaded()) {
            int interval = GhostMarketConfig.DROPPED_PARTICLE_INTERVAL_TICKS.get();
            if (interval > 0 && entity.tickCount % interval == 0) {
                double x = entity.getX() + (level.random.nextDouble() - 0.5D) * 0.3D;
                double y = entity.getY() + 0.15D;
                double z = entity.getZ() + (level.random.nextDouble() - 0.5D) * 0.3D;
                level.addParticle(CurrencyRules.BLACK_SMOKE, x, y, z, 0.0D, 0.03D, 0.0D);
            }
        }
        return false;
    }
}

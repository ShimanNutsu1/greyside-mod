package com.example.ghostmarket.currency;

import com.example.ghostmarket.registry.ModItems;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

/** Валюта как предметы «Последний вздох» в инвентаре игрока (основные слоты, броня, вторая рука). */
public class InventoryCurrencyAccess implements CurrencyAccess {

    @Override
    public long getBalance(ServerPlayer player) {
        Inventory inventory = player.getInventory();
        long total = 0L;
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack stack = inventory.getItem(i);
            if (stack.is(ModItems.LAST_BREATH.get())) {
                total += stack.getCount();
            }
        }
        return total;
    }

    @Override
    public long withdraw(ServerPlayer player, long amount) {
        if (amount <= 0L) {
            return 0L;
        }
        Inventory inventory = player.getInventory();
        long remaining = amount;
        for (int i = 0; i < inventory.getContainerSize() && remaining > 0L; i++) {
            ItemStack stack = inventory.getItem(i);
            if (!stack.is(ModItems.LAST_BREATH.get())) {
                continue;
            }
            int take = (int) Math.min(remaining, stack.getCount());
            stack.shrink(take);
            remaining -= take;
            if (stack.isEmpty()) {
                inventory.setItem(i, ItemStack.EMPTY);
            }
        }
        inventory.setChanged();
        return amount - remaining;
    }

    @Override
    public long deposit(ServerPlayer player, long amount) {
        long remaining = Math.max(0L, amount);
        int maxStack = ModItems.LAST_BREATH.get().getMaxStackSize();
        while (remaining > 0L) {
            int count = (int) Math.min(remaining, maxStack);
            remaining -= count;
            ItemStack stack = new ItemStack(ModItems.LAST_BREATH.get(), count);
            if (!player.getInventory().add(stack) && !stack.isEmpty()) {
                player.drop(stack, false);
            }
        }
        player.getInventory().setChanged();
        return Math.max(0L, amount);
    }
}

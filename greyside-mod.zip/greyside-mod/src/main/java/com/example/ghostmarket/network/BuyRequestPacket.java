package com.example.ghostmarket.network;

import com.example.ghostmarket.trade.MerchantMenu;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Клиент -> сервер: «хочу купить позицию №index». Больше клиент ничего не диктует. */
public record BuyRequestPacket(int containerId, int index) {

    public static void encode(BuyRequestPacket packet, FriendlyByteBuf buf) {
        buf.writeVarInt(packet.containerId);
        buf.writeVarInt(packet.index);
    }

    public static BuyRequestPacket decode(FriendlyByteBuf buf) {
        return new BuyRequestPacket(buf.readVarInt(), buf.readVarInt());
    }

    public static void handle(BuyRequestPacket packet, Supplier<NetworkEvent.Context> context) {
        ServerPlayer sender = context.get().getSender();
        if (sender != null && sender.containerMenu instanceof MerchantMenu menu
                && menu.containerId == packet.containerId) {
            menu.tryBuy(sender, packet.index);
        }
        context.get().setPacketHandled(true);
    }
}

package com.example.ghostmarket.trade;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;

/** Заглушка: шлёт сообщение в чат (текст good.<ns>.<path>.message). */
public class MessageGood implements Good {
    private final ResourceLocation id;

    public MessageGood(ResourceLocation id) {
        this.id = id;
    }

    @Override
    public ResourceLocation id() {
        return id;
    }

    @Override
    public boolean canGive(ServerPlayer player) {
        return true;
    }

    @Override
    public boolean give(ServerPlayer player) {
        player.displayClientMessage(Component.translatable("good." + id.getNamespace() + "." + id.getPath() + ".message")
                .withStyle(ChatFormatting.DARK_PURPLE, ChatFormatting.ITALIC), false);
        return true;
    }

    @Override
    public Component describe() {
        return Component.translatable("good.ghostmarket.message.desc");
    }
}

package com.example.ghostmarket.item;

import com.example.ghostmarket.config.GhostMarketConfig;
import com.example.ghostmarket.key.KeyRules;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class StrangeKeyItem extends Item {

    public StrangeKeyItem(Properties properties) {
        super(properties);
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    /**
     * После использования в NBT ключа меняется запись о последней ночи.
     * Без этого переопределения предмет в руке «подпрыгивал» бы, как при смене предмета.
     */
    @Override
    public boolean shouldCauseReequipAnimation(ItemStack oldStack, ItemStack newStack, boolean slotChanged) {
        return slotChanged || oldStack.getItem() != newStack.getItem();
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        if (level == null || !GhostMarketConfig.SPEC.isLoaded()) {
            return;
        }

        KeyRules.State state = KeyRules.evaluate(level.getDayTime(), KeyRules.getLastUsedNight(stack));

        if (state.status() == KeyRules.Status.WHISPERING) {
            tooltip.add(Component.translatable("tooltip.ghostmarket.strange_key.whispering")
                    .withStyle(ChatFormatting.DARK_PURPLE));
            return;
        }

        tooltip.add(Component.translatable("tooltip.ghostmarket.strange_key.sleeping")
                .withStyle(ChatFormatting.DARK_GRAY));

        if (state.nightsLeft() > 0) {
            tooltip.add(Component.translatable("tooltip.ghostmarket.strange_key.nights_left", state.nightsLeft())
                    .withStyle(ChatFormatting.GRAY));
        }

        if (state.waitTicks() < KeyRules.TICKS_PER_MINUTE) {
            tooltip.add(Component.translatable("tooltip.ghostmarket.strange_key.wait_soon")
                    .withStyle(ChatFormatting.GRAY));
        } else {
            long minutes = (state.waitTicks() + KeyRules.TICKS_PER_MINUTE - 1) / KeyRules.TICKS_PER_MINUTE;
            tooltip.add(Component.translatable("tooltip.ghostmarket.strange_key.wait_minutes", minutes)
                    .withStyle(ChatFormatting.GRAY));
        }
    }
}

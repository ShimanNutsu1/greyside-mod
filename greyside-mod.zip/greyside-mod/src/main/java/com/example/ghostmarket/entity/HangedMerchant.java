package com.example.ghostmarket.entity;

import com.example.ghostmarket.trade.MerchantType;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

public class HangedMerchant extends MerchantEntity {
    public HangedMerchant(EntityType<HangedMerchant> type, Level level) {
        super(type, level, MerchantType.HANGED);
    }
}

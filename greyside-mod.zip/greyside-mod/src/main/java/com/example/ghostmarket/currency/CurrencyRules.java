package com.example.ghostmarket.currency;

import com.example.ghostmarket.GhostMarket;
import com.example.ghostmarket.config.GhostMarketConfig;
import com.example.ghostmarket.key.KeyRules;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.OwnableEntity;
import net.minecraft.world.entity.animal.Parrot;
import net.minecraft.world.entity.animal.horse.AbstractHorse;
import net.minecraft.world.entity.player.Player;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

import java.util.UUID;

public final class CurrencyRules {
    public static final TagKey<EntityType<?>> PETS = tag("currency_pets");
    public static final TagKey<EntityType<?>> BABIES = tag("currency_babies");
    public static final TagKey<EntityType<?>> HARMLESS = tag("currency_harmless");

    /** Чёрный дымок: тёмная пыль без цветового оттенка. */
    public static final DustParticleOptions BLACK_SMOKE =
            new DustParticleOptions(new Vector3f(0.03F, 0.03F, 0.05F), 1.2F);

    public enum Category {
        PET,
        BABY,
        HARMLESS
    }

    private static TagKey<EntityType<?>> tag(String name) {
        return TagKey.create(Registries.ENTITY_TYPE, new ResourceLocation(GhostMarket.MODID, name));
    }

    /**
     * Определяет категорию убитого моба для данного игрока. null: валюты за это убийство нет.
     * <p>
     * Любое животное с хозяином рассматривается только как питомец: если оно не подходит
     * (чужой питомец, не приручён этим игроком, тип выключен), награды нет вообще.
     */
    @Nullable
    public static Category classify(LivingEntity victim, Player killer) {
        if (victim instanceof OwnableEntity ownable && ownable.getOwnerUUID() != null) {
            if (!isPetType(victim)) {
                return null;
            }
            if (!killer.getUUID().equals(ownable.getOwnerUUID())) {
                return null;
            }
            return isTamedByPlayer(victim, killer) ? Category.PET : null;
        }

        EntityType<?> type = victim.getType();
        if (victim.isBaby() && type.is(BABIES)) {
            return Category.BABY;
        }
        if (type.is(HARMLESS)) {
            return Category.HARMLESS;
        }
        return null;
    }

    private static boolean isPetType(LivingEntity victim) {
        if (victim.getType().is(PETS)) {
            return true;
        }
        if (GhostMarketConfig.INCLUDE_PARROTS.get() && victim instanceof Parrot) {
            return true;
        }
        return GhostMarketConfig.INCLUDE_HORSES.get() && victim instanceof AbstractHorse;
    }

    private static boolean isTamedByPlayer(LivingEntity victim, Player killer) {
        UUID tamer = PetMarks.getTamer(victim);
        if (tamer != null) {
            return tamer.equals(killer.getUUID());
        }
        return GhostMarketConfig.COUNT_UNMARKED_PETS.get();
    }

    /** Базовое количество до бонусов и множителей. */
    public static int rollBase(Category category, RandomSource random) {
        return switch (category) {
            case PET -> rollBetween(GhostMarketConfig.PET_MIN_AMOUNT.get(),
                    GhostMarketConfig.PET_MAX_AMOUNT.get(), random);
            case BABY -> rollBetween(GhostMarketConfig.BABY_MIN_AMOUNT.get(),
                    GhostMarketConfig.BABY_MAX_AMOUNT.get(), random);
            case HARMLESS -> rollBetween(GhostMarketConfig.HARMLESS_MIN_AMOUNT.get(),
                    GhostMarketConfig.HARMLESS_MAX_AMOUNT.get(), random);
        };
    }

    private static int rollBetween(int min, int max, RandomSource random) {
        int high = Math.max(min, max);
        return min + random.nextInt(high - min + 1);
    }

    /** +1 за каждые N игровых дней с момента приручения, не больше bondMaxBonus. */
    public static int bondBonus(LivingEntity pet, long gameTime) {
        long tameTime = PetMarks.getTameTime(pet);
        if (tameTime == PetMarks.NO_TIME) {
            return 0;
        }
        long days = Math.max(0L, gameTime - tameTime) / KeyRules.TICKS_PER_DAY;
        long bonus = days / GhostMarketConfig.BOND_DAYS_PER_BONUS.get();
        return (int) Math.min(bonus, GhostMarketConfig.BOND_MAX_BONUS.get());
    }

    public static boolean isBredReduced(LivingEntity victim, Category category) {
        if (!GhostMarketConfig.REDUCE_BRED_MOBS.get() || !PetMarks.isBred(victim)) {
            return false;
        }
        return category != Category.PET || GhostMarketConfig.BRED_AFFECTS_PETS.get();
    }

    /** Дробное значение округляется вероятностно: 0.5 даёт 1 с шансом 50%, иначе 0. */
    public static int probabilisticRound(double value, RandomSource random) {
        int whole = (int) Math.floor(value);
        double fraction = value - whole;
        return whole + (random.nextDouble() < fraction ? 1 : 0);
    }

    private CurrencyRules() {
    }
}

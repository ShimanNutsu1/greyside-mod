package com.example.ghostmarket.client;

import com.example.ghostmarket.config.GhostMarketClientConfig;
import com.example.ghostmarket.dimension.ModDimensions;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

/** Таймер до закрытия рынка. Бледно-фиолетовый, к концу краснеет и пульсирует. */
public final class MarketHudOverlay {
    private static final int COLOR_CALM = 0xB9A8D6;
    private static final int COLOR_DANGER = 0xE02828;

    public static final IGuiOverlay OVERLAY = (gui, graphics, partialTick, width, height) -> {
        if (!GhostMarketClientConfig.SPEC.isLoaded() || !GhostMarketClientConfig.HUD_ENABLED.get()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui || mc.level == null || !ModDimensions.isMarket(mc.level) || !ClientMarketTimer.isActive()) {
            return;
        }

        int totalSeconds = (ClientMarketTimer.getRemainingTicks() + 19) / 20;
        String time = String.format("%02d:%02d", totalSeconds / 60, totalSeconds % 60);
        Component text = Component.translatable("hud.ghostmarket.market_timer", time);

        float danger = ClientMarketTimer.warningProgress();
        float brightness = 1.0F;
        if (danger > 0.0F) {
            float phase = (mc.level.getGameTime() + partialTick) * 0.25F;
            brightness = 0.75F + 0.25F * (0.5F + 0.5F * Mth.sin(phase));
        }
        int color = 0xFF000000 | lerpColor(COLOR_CALM, COLOR_DANGER, danger, brightness);

        float scale = GhostMarketClientConfig.HUD_SCALE.get().floatValue();
        graphics.pose().pushPose();
        graphics.pose().translate(width / 2.0F, GhostMarketClientConfig.HUD_OFFSET_Y.get(), 0.0F);
        graphics.pose().scale(scale, scale, 1.0F);
        graphics.drawCenteredString(mc.font, text, 0, 0, color);
        graphics.pose().popPose();
    };

    private static int lerpColor(int from, int to, float t, float brightness) {
        int r = channel((from >> 16) & 0xFF, (to >> 16) & 0xFF, t, brightness);
        int g = channel((from >> 8) & 0xFF, (to >> 8) & 0xFF, t, brightness);
        int b = channel(from & 0xFF, to & 0xFF, t, brightness);
        return (r << 16) | (g << 8) | b;
    }

    private static int channel(int a, int b, float t, float brightness) {
        return Mth.clamp((int) (Mth.lerp(t, a, b) * brightness), 0, 255);
    }

    private MarketHudOverlay() {
    }
}

package com.example.ghostmarket.dimension;

import com.example.ghostmarket.config.GhostMarketConfig;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Геометрия площади рынка, посчитанная из конфига.
 * Это единая точка правды для платформы (Этап 2А) и для телепортации и портал-арки (Этап 2Б).
 *
 * @param center   центр площади, верхний слой пола
 * @param half     половина стороны площади (стена стоит на расстоянии half от центра)
 * @param arch     центр помоста под портал-арку, на уровне пола
 * @param spawn    блок пола под точкой появления игрока
 * @param spawnYaw куда смотрит игрок при появлении
 */
public record MarketLayout(BlockPos center, int half, int wallHeight, BlockPos arch, BlockPos spawn, float spawnYaw) {

    /** Увеличивай при любом изменении внешнего вида платформы, чтобы старые миры перестроились. */
    public static final int BUILD_VERSION = 2;

    /** Помост под арку занимает по X от -3 до +3 и по Z от -2 до +2 вокруг центра арки. */
    public static final int ARCH_HALF_WIDTH = 3;
    public static final int ARCH_HALF_DEPTH = 2;
    /** Сколько блоков над полом зарезервировано под арку. */
    public static final int ARCH_HEIGHT = 6;

    /** Смещения центров лавок вдоль стены по Z от центра площади. Лавки стоят у обеих боковых стен. */
    public static final int[] STALL_Z = {-6, 0, 6};
    /** Расстояние от центра площади до линии продавца в лавке: half - STALL_SELLER_INSET. */
    public static final int STALL_SELLER_INSET = 2;

    public static MarketLayout fromConfig() {
        int cx = GhostMarketConfig.MARKET_CENTER_X.get();
        int fy = GhostMarketConfig.MARKET_FLOOR_Y.get();
        int cz = GhostMarketConfig.MARKET_CENTER_Z.get();
        int half = GhostMarketConfig.MARKET_HALF_SIZE.get();
        int wh = GhostMarketConfig.MARKET_WALL_HEIGHT.get();

        // Смещения зажимаются, чтобы арка и точка появления не оказались в стене.
        int adx = Mth.clamp(GhostMarketConfig.ARCH_OFFSET_X.get(), -(half - 4), half - 4);
        int adz = Mth.clamp(GhostMarketConfig.ARCH_OFFSET_Z.get(), -(half - 3), half - 3);
        int sdx = Mth.clamp(GhostMarketConfig.SPAWN_OFFSET_X.get(), -(half - 2), half - 2);
        int sdz = Mth.clamp(GhostMarketConfig.SPAWN_OFFSET_Z.get(), -(half - 2), half - 2);

        return new MarketLayout(
                new BlockPos(cx, fy, cz),
                half,
                wh,
                new BlockPos(cx + adx, fy, cz + adz),
                new BlockPos(cx + sdx, fy, cz + sdz),
                GhostMarketConfig.SPAWN_YAW.get().floatValue());
    }

    public int archDx() {
        return arch.getX() - center.getX();
    }

    public int archDz() {
        return arch.getZ() - center.getZ();
    }

    public int spawnDx() {
        return spawn.getX() - center.getX();
    }

    public int spawnDz() {
        return spawn.getZ() - center.getZ();
    }

    /** Точка появления игрока: центр блока над полом. Для телепортации в Этапе 2Б. */
    public Vec3 spawnPos() {
        return new Vec3(spawn.getX() + 0.5D, spawn.getY() + 1.0D, spawn.getZ() + 0.5D);
    }

    /** Объём, зарезервированный под портал-арку Этапа 2Б (включая помост). */
    public BoundingBox archReservedBox() {
        return new BoundingBox(
                arch.getX() - ARCH_HALF_WIDTH, arch.getY() + 1, arch.getZ() - ARCH_HALF_DEPTH,
                arch.getX() + ARCH_HALF_WIDTH, arch.getY() + ARCH_HEIGHT, arch.getZ() + ARCH_HALF_DEPTH);
    }

    /** Всё, что строится на площади: от слоя под полом до фонарей на угловых колоннах. */
    public BoundingBox buildBounds() {
        return new BoundingBox(
                center.getX() - half, center.getY() - 2, center.getZ() - half,
                center.getX() + half, center.getY() + wallHeight + 3, center.getZ() + half);
    }

    /**
     * Место продавца в лавке.
     *
     * @param side   -1 западная стена, +1 восточная
     * @param zOffset смещение центра лавки по Z от центра площади
     * @param pos    точка, где стоят ноги продавца (центр блока над полом)
     * @param yaw    куда смотрит продавец, пока рядом нет игроков (на площадь)
     */
    public record StallSpot(int side, int zOffset, Vec3 pos, float yaw) {
    }

    /**
     * Все шесть мест продавцов. Порядок: по очереди с западной и восточной стены, от северных лавок к южным.
     * Позиции считаются от центра и размера площади, поэтому следуют за конфигом.
     */
    public List<StallSpot> stallSpots() {
        List<StallSpot> spots = new ArrayList<>();
        for (int zc : STALL_Z) {
            for (int side = -1; side <= 1; side += 2) {
                Vec3 pos = new Vec3(
                        center.getX() + side * (half - STALL_SELLER_INSET) + 0.5D,
                        center.getY() + 1.0D,
                        center.getZ() + zc + 0.5D);
                // Западная лавка смотрит на восток (yaw 270), восточная на запад (yaw 90).
                spots.add(new StallSpot(side, zc, pos, side < 0 ? 270.0F : 90.0F));
            }
        }
        return spots;
    }

    /** Подпись раскладки: если она изменилась, платформа перестраивается. */
    public int signature() {
        return Objects.hash(BUILD_VERSION,
                center.getX(), center.getY(), center.getZ(),
                half, wallHeight,
                arch.getX(), arch.getZ(),
                spawn.getX(), spawn.getZ());
    }
}

package com.example.ghostmarket.config;

import net.minecraftforge.common.ForgeConfigSpec;

public final class GhostMarketConfig {
    public static final ForgeConfigSpec SPEC;

    // ===== Этап 1: Странный ключ =====
    public static final ForgeConfigSpec.IntValue WINDOW_START_TICK;
    public static final ForgeConfigSpec.IntValue WINDOW_END_TICK;
    public static final ForgeConfigSpec.IntValue COOLDOWN_NIGHTS;
    public static final ForgeConfigSpec.BooleanValue ALLOW_TRAPDOORS;
    public static final ForgeConfigSpec.BooleanValue ALLOW_FENCE_GATES;
    public static final ForgeConfigSpec.DoubleValue DOOR_SOUND_VOLUME;
    public static final ForgeConfigSpec.DoubleValue DOOR_SOUND_PITCH;
    public static final ForgeConfigSpec.DoubleValue KEY_LOOT_CHANCE;

    // ===== Этап 2: Валюта, питомцы =====
    public static final ForgeConfigSpec.IntValue PET_MIN_AMOUNT;
    public static final ForgeConfigSpec.IntValue PET_MAX_AMOUNT;
    public static final ForgeConfigSpec.BooleanValue INCLUDE_PARROTS;
    public static final ForgeConfigSpec.BooleanValue INCLUDE_HORSES;
    public static final ForgeConfigSpec.BooleanValue COUNT_UNMARKED_PETS;
    public static final ForgeConfigSpec.IntValue BOND_DAYS_PER_BONUS;
    public static final ForgeConfigSpec.IntValue BOND_MAX_BONUS;

    // ===== Этап 2: Валюта, детёныши и безобидные =====
    public static final ForgeConfigSpec.IntValue BABY_MIN_AMOUNT;
    public static final ForgeConfigSpec.IntValue BABY_MAX_AMOUNT;
    public static final ForgeConfigSpec.IntValue HARMLESS_MIN_AMOUNT;
    public static final ForgeConfigSpec.IntValue HARMLESS_MAX_AMOUNT;

    // ===== Этап 2: Защита от фарма =====
    public static final ForgeConfigSpec.IntValue FARM_WINDOW_MINUTES;
    public static final ForgeConfigSpec.IntValue FARM_FULL_REWARD_KILLS;
    public static final ForgeConfigSpec.IntValue FARM_STAGE_LENGTH_KILLS;
    public static final ForgeConfigSpec.DoubleValue FARM_STAGE1_MULTIPLIER;
    public static final ForgeConfigSpec.DoubleValue FARM_STAGE2_MULTIPLIER;
    public static final ForgeConfigSpec.IntValue FARM_LOCKOUT_MINUTES;
    public static final ForgeConfigSpec.DoubleValue FARM_ZONE_RADIUS;
    public static final ForgeConfigSpec.BooleanValue REDUCE_BRED_MOBS;
    public static final ForgeConfigSpec.DoubleValue BRED_MULTIPLIER;
    public static final ForgeConfigSpec.BooleanValue BRED_AFFECTS_PETS;

    // ===== Этап 2: Эффекты =====
    public static final ForgeConfigSpec.DoubleValue PET_DEATH_SOUND_VOLUME;
    public static final ForgeConfigSpec.DoubleValue PET_DEATH_SOUND_PITCH;
    public static final ForgeConfigSpec.IntValue PET_DEATH_PARTICLE_COUNT;
    public static final ForgeConfigSpec.IntValue DROPPED_PARTICLE_INTERVAL_TICKS;
    public static final ForgeConfigSpec.DoubleValue PICKUP_SOUND_VOLUME;
    public static final ForgeConfigSpec.DoubleValue PICKUP_SOUND_PITCH;

    // ===== Этап 2А: Рынок призраков, площадь =====
    public static final ForgeConfigSpec.IntValue MARKET_CENTER_X;
    public static final ForgeConfigSpec.IntValue MARKET_FLOOR_Y;
    public static final ForgeConfigSpec.IntValue MARKET_CENTER_Z;
    public static final ForgeConfigSpec.IntValue MARKET_HALF_SIZE;
    public static final ForgeConfigSpec.IntValue MARKET_WALL_HEIGHT;
    public static final ForgeConfigSpec.IntValue ARCH_OFFSET_X;
    public static final ForgeConfigSpec.IntValue ARCH_OFFSET_Z;
    public static final ForgeConfigSpec.IntValue SPAWN_OFFSET_X;
    public static final ForgeConfigSpec.IntValue SPAWN_OFFSET_Z;
    public static final ForgeConfigSpec.DoubleValue SPAWN_YAW;

    // ===== Этап 2А: Рынок призраков, правила =====
    public static final ForgeConfigSpec.BooleanValue BLOCK_HOSTILE_SPAWNS;
    public static final ForgeConfigSpec.BooleanValue BLOCK_BREAKING;
    public static final ForgeConfigSpec.BooleanValue BLOCK_PLACING;
    public static final ForgeConfigSpec.BooleanValue CREATIVE_BYPASS;
    public static final ForgeConfigSpec.BooleanValue OP_BYPASS;
    public static final ForgeConfigSpec.IntValue OP_BYPASS_LEVEL;

    // ===== Этап 2А: Рынок призраков, атмосфера =====
    public static final ForgeConfigSpec.DoubleValue FOG_NEAR;
    public static final ForgeConfigSpec.DoubleValue FOG_FAR;
    public static final ForgeConfigSpec.BooleanValue MUSIC_ENABLED;
    public static final ForgeConfigSpec.BooleanValue AMBIENT_SOUNDS_ENABLED;
    public static final ForgeConfigSpec.IntValue AMBIENT_SOUND_CHECK_INTERVAL_TICKS;
    public static final ForgeConfigSpec.DoubleValue AMBIENT_SOUND_CHANCE;
    public static final ForgeConfigSpec.DoubleValue AMBIENT_SOUND_MIN_DISTANCE;
    public static final ForgeConfigSpec.DoubleValue AMBIENT_SOUND_MAX_DISTANCE;
    public static final ForgeConfigSpec.DoubleValue AMBIENT_SOUND_VOLUME;
    public static final ForgeConfigSpec.DoubleValue AMBIENT_SOUND_MIN_PITCH;
    public static final ForgeConfigSpec.DoubleValue AMBIENT_SOUND_MAX_PITCH;

    // ===== Этап 2Б: Сеанс на рынке =====
    public static final ForgeConfigSpec.IntValue SESSION_DAWN_TICK;
    public static final ForgeConfigSpec.IntValue SESSION_MIN_TICKS;
    public static final ForgeConfigSpec.IntValue SESSION_MAX_TICKS;
    public static final ForgeConfigSpec.IntValue WARNING_TICKS;
    public static final ForgeConfigSpec.DoubleValue WARNING_SOUND_VOLUME;
    public static final ForgeConfigSpec.DoubleValue WARNING_SOUND_PITCH;
    public static final ForgeConfigSpec.DoubleValue FOG_WARNING_NEAR;
    public static final ForgeConfigSpec.DoubleValue FOG_WARNING_FAR;
    public static final ForgeConfigSpec.IntValue TIMER_SYNC_INTERVAL_TICKS;
    public static final ForgeConfigSpec.IntValue PENALTY_WEAKNESS_MINUTES;
    public static final ForgeConfigSpec.IntValue PENALTY_WEAKNESS_AMPLIFIER;
    public static final ForgeConfigSpec.IntValue PENALTY_CURRENCY_PERCENT;
    public static final ForgeConfigSpec.BooleanValue KEEP_KEY_ON_MARKET_DEATH;
    public static final ForgeConfigSpec.IntValue RETURN_SEARCH_HEIGHT;

    // ===== Этап 4Б: Торговля =====
    public static final ForgeConfigSpec.IntValue TRADE_SLOTS;
    public static final ForgeConfigSpec.DoubleValue TRADE_RANDOM_SHARE;
    public static final ForgeConfigSpec.DoubleValue TRADE_DISTANCE;
    public static final ForgeConfigSpec.IntValue TRADE_PURCHASE_COOLDOWN_TICKS;
    public static final ForgeConfigSpec.DoubleValue TRADE_SOUND_VOLUME;
    public static final ForgeConfigSpec.DoubleValue TRADE_SOUND_PITCH;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();

        // ---------- Странный ключ ----------
        builder.comment("Странный ключ").push("strange_key");

        WINDOW_START_TICK = builder
                .comment("Начало окна «полночи» в тиках времени суток (0-23999). 18000 = полночь.",
                        "Если начало больше конца, окно переходит через границу суток (например 23000 -> 1000).")
                .defineInRange("windowStartTick", 17500, 0, 23999);

        WINDOW_END_TICK = builder
                .comment("Конец окна «полночи» в тиках времени суток (0-23999), включительно.")
                .defineInRange("windowEndTick", 18500, 0, 23999);

        COOLDOWN_NIGHTS = builder
                .comment("Через сколько игровых ночей ключ можно использовать снова.",
                        "Использовал в ночь N, следующее использование возможно в ночь N + это значение.")
                .defineInRange("cooldownNights", 3, 1, 1000);

        ALLOW_TRAPDOORS = builder
                .comment("Разрешить использовать ключ на деревянных люках.")
                .define("allowTrapdoors", false);

        ALLOW_FENCE_GATES = builder
                .comment("Разрешить использовать ключ на деревянных калитках.")
                .define("allowFenceGates", false);

        DOOR_SOUND_VOLUME = builder
                .comment("Громкость звука при успешном использовании ключа.")
                .defineInRange("doorSoundVolume", 1.0D, 0.0D, 10.0D);

        DOOR_SOUND_PITCH = builder
                .comment("Высота звука при успешном использовании ключа (0.5-2.0).")
                .defineInRange("doorSoundPitch", 0.5D, 0.5D, 2.0D);

        builder.pop();

        // ---------- Лут ----------
        builder.comment("Лут").push("loot");

        KEY_LOOT_CHANCE = builder
                .comment("Шанс (0.0-1.0), что в сундуке из списка таблиц лута окажется ключ.",
                        "Список таблиц задаётся в data/ghostmarket/loot_modifiers/add_strange_key_to_dungeons.json.")
                .defineInRange("keyChance", 0.08D, 0.0D, 1.0D);

        builder.pop();

        // ---------- Валюта ----------
        builder.comment("Валюта «Последний вздох»",
                "Списки мобов по категориям лежат в тегах данных, а не здесь:",
                "data/ghostmarket/tags/entity_types/currency_pets.json, currency_babies.json, currency_harmless.json").push("currency");

        builder.comment("Питомцы: убиты своим хозяином, приручены им самим").push("pets");

        PET_MIN_AMOUNT = builder
                .comment("Минимум базовой награды за питомца (до бонуса привязанности).")
                .defineInRange("minAmount", 8, 0, 64);

        PET_MAX_AMOUNT = builder
                .comment("Максимум базовой награды за питомца (до бонуса привязанности).",
                        "Если меньше минимума, используется минимум.")
                .defineInRange("maxAmount", 12, 0, 64);

        INCLUDE_PARROTS = builder
                .comment("Считать прирученных попугаев питомцами.")
                .define("includeParrots", false);

        INCLUDE_HORSES = builder
                .comment("Считать прирученных лошадей, ослов, мулов и лам питомцами.")
                .define("includeHorses", false);

        COUNT_UNMARKED_PETS = builder
                .comment("Питомец без метки приручения (приручен до установки мода, или приручение",
                        "не вызвало событие AnimalTameEvent) засчитывается хозяину без бонуса привязанности.",
                        "false: такие питомцы не дают валюты вообще.")
                .define("countUnmarkedPets", true);

        BOND_DAYS_PER_BONUS = builder
                .comment("Привязанность: +1 к награде за каждые N игровых дней (24000 тиков) жизни у игрока.")
                .defineInRange("bondDaysPerBonus", 5, 1, 1000);

        BOND_MAX_BONUS = builder
                .comment("Привязанность: максимум добавки к награде (само число, не дни).")
                .defineInRange("bondMaxBonus", 10, 0, 1000);

        builder.pop();

        builder.comment("Детёныши мирных мобов").push("babies");

        BABY_MIN_AMOUNT = builder
                .comment("Минимум награды за детёныша.")
                .defineInRange("minAmount", 3, 0, 64);

        BABY_MAX_AMOUNT = builder
                .comment("Максимум награды за детёныша. Если меньше минимума, используется минимум.")
                .defineInRange("maxAmount", 4, 0, 64);

        builder.pop();

        builder.comment("Прочие безобидные существа").push("harmless");

        HARMLESS_MIN_AMOUNT = builder
                .comment("Минимум награды за безобидное существо.")
                .defineInRange("minAmount", 1, 0, 64);

        HARMLESS_MAX_AMOUNT = builder
                .comment("Максимум награды за безобидное существо. Если меньше минимума, используется минимум.")
                .defineInRange("maxAmount", 1, 0, 64);

        builder.pop();

        builder.comment("Защита от фарма (только детёныши и безобидные; питомцев не касается)").push("antiFarm");

        FARM_WINDOW_MINUTES = builder
                .comment("Окно учёта в минутах (1 минута = 1200 игровых тиков).",
                        "Считаются убийства одного типа моба в одной зоне за это время.")
                .defineInRange("windowMinutes", 10, 1, 1440);

        FARM_FULL_REWARD_KILLS = builder
                .comment("Сколько убийств в окне дают полную награду (Y).")
                .defineInRange("fullRewardKills", 3, 0, 1000);

        FARM_STAGE_LENGTH_KILLS = builder
                .comment("Длина каждой ступени урезания в убийствах.",
                        "После Y полных идёт ступень 1, потом ступень 2, потом ноль и блокировка.")
                .defineInRange("stageLengthKills", 3, 1, 1000);

        FARM_STAGE1_MULTIPLIER = builder
                .comment("Множитель награды на ступени 1 (0.5 = падение на 50%).")
                .defineInRange("stage1Multiplier", 0.5D, 0.0D, 1.0D);

        FARM_STAGE2_MULTIPLIER = builder
                .comment("Множитель награды на ступени 2 (0.25 = падение на 75%).")
                .defineInRange("stage2Multiplier", 0.25D, 0.0D, 1.0D);

        FARM_LOCKOUT_MINUTES = builder
                .comment("На сколько минут награда за этот тип моба в этой зоне обнуляется после ступени 2.",
                        "После блокировки счётчик для зоны сбрасывается.")
                .defineInRange("lockoutMinutes", 10, 1, 1440);

        FARM_ZONE_RADIUS = builder
                .comment("Радиус «одной зоны» в блоках (по горизонтали, в пределах одного измерения).")
                .defineInRange("zoneRadius", 24.0D, 1.0D, 256.0D);

        REDUCE_BRED_MOBS = builder
                .comment("Мобы, рождённые разведением, дают меньше валюты, чем найденные в мире.",
                        "Яйца кур и вылупление черепах отдельно не учитываются, их ловит защита от фарма.")
                .define("reduceBredMobs", true);

        BRED_MULTIPLIER = builder
                .comment("Множитель награды за рождённых разведением (0.5 = вдвое меньше).")
                .defineInRange("bredMultiplier", 0.5D, 0.0D, 1.0D);

        BRED_AFFECTS_PETS = builder
                .comment("Применять множитель разведения и к питомцам (щенки и котята от ваших питомцев).",
                        "false: питомцы, рождённые разведением, дают полную награду.")
                .define("bredAffectsPets", true);

        builder.pop();

        builder.comment("Звуки и частицы").push("effects");

        PET_DEATH_SOUND_VOLUME = builder
                .comment("Громкость звука при убийстве питомца.")
                .defineInRange("petDeathSoundVolume", 1.0D, 0.0D, 10.0D);

        PET_DEATH_SOUND_PITCH = builder
                .comment("Высота звука при убийстве питомца (0.5-2.0).")
                .defineInRange("petDeathSoundPitch", 0.8D, 0.5D, 2.0D);

        PET_DEATH_PARTICLE_COUNT = builder
                .comment("Сколько чёрных частиц появляется при убийстве питомца.")
                .defineInRange("petDeathParticleCount", 40, 0, 500);

        DROPPED_PARTICLE_INTERVAL_TICKS = builder
                .comment("Раз в сколько тиков лежащий на земле предмет «Последний вздох» пускает чёрный дымок.",
                        "0 отключает частицы.")
                .defineInRange("droppedParticleIntervalTicks", 6, 0, 200);

        PICKUP_SOUND_VOLUME = builder
                .comment("Громкость вздоха при подборе предмета.")
                .defineInRange("pickupSoundVolume", 0.4D, 0.0D, 10.0D);

        PICKUP_SOUND_PITCH = builder
                .comment("Высота вздоха при подборе (0.5-2.0).")
                .defineInRange("pickupSoundPitch", 0.7D, 0.5D, 2.0D);

        builder.pop();

        builder.pop(); // currency

        // ---------- Рынок призраков (измерение) ----------
        builder.comment("Измерение «Рынок призраков» (этап 2А).",
                "Параметры площади применяются при старте мира или сервера. Если они изменились,",
                "платформа сама перестраивается при следующем запуске (старая убирается).").push("market");

        builder.comment("Положение и размеры площади. Смещения арки и точки появления считаются от центра площади.").push("layout");

        MARKET_CENTER_X = builder
                .comment("X центра площади в измерении рынка.")
                .defineInRange("centerX", 0, -1000000, 1000000);

        MARKET_FLOOR_Y = builder
                .comment("Y верхнего слоя пола. Игрок стоит на Y+1.",
                        "Не опускай ниже 64: под линией горизонта (63) клиентский туман уходит в чёрный.")
                .defineInRange("floorY", 64, 64, 90);

        MARKET_CENTER_Z = builder
                .comment("Z центра площади в измерении рынка.")
                .defineInRange("centerZ", 0, -1000000, 1000000);

        MARKET_HALF_SIZE = builder
                .comment("Половина стороны квадратной площади в блоках. 12 даёт площадь 25x25 внутри стен.",
                        "Меньше 12 лавки перестают помещаться.")
                .defineInRange("halfSize", 12, 12, 24);

        MARKET_WALL_HEIGHT = builder
                .comment("Высота окружающей стены над полом. Цепи с фонарями натянуты на этой высоте.",
                        "Меньше 6 нельзя: лавки и фонари не поместятся.")
                .defineInRange("wallHeight", 6, 6, 16);

        ARCH_OFFSET_X = builder
                .comment("Смещение центра места под портал-арку по X от центра площади.",
                        "Зарезервировано под арку Этапа 2Б: помост 7x5 с заглушкой-аркой.")
                .defineInRange("archOffsetX", 0, -24, 24);

        ARCH_OFFSET_Z = builder
                .comment("Смещение центра места под портал-арку по Z от центра площади (минус = к северу).")
                .defineInRange("archOffsetZ", -9, -24, 24);

        SPAWN_OFFSET_X = builder
                .comment("Смещение точки появления игрока по X от центра площади.")
                .defineInRange("spawnOffsetX", 0, -24, 24);

        SPAWN_OFFSET_Z = builder
                .comment("Смещение точки появления игрока по Z от центра площади (плюс = к югу).")
                .defineInRange("spawnOffsetZ", 8, -24, 24);

        SPAWN_YAW = builder
                .comment("Куда смотрит игрок при появлении. 180 = на север (в сторону арки по умолчанию),",
                        "0 = на юг, 90 = на запад, 270 = на восток.")
                .defineInRange("spawnYaw", 180.0D, -360.0D, 360.0D);

        builder.pop();

        builder.comment("Правила измерения").push("rules");

        BLOCK_HOSTILE_SPAWNS = builder
                .comment("Запретить спавн враждебных существ (природный, из спавнеров, при генерации чанка).",
                        "Команды, яйца призыва и раздатчики работают как обычно.")
                .define("blockHostileSpawns", true);

        BLOCK_BREAKING = builder
                .comment("Запретить ломать блоки. Заодно блокирует разрушение взрывами и грифинг мобов.")
                .define("blockBreaking", true);

        BLOCK_PLACING = builder
                .comment("Запретить ставить блоки (в том числе вёдра, огниво, огненный шар) и менять их инструментами.")
                .define("blockPlacing", true);

        CREATIVE_BYPASS = builder
                .comment("Игроки в творческом режиме обходят запреты на ломание и строительство.")
                .define("creativeBypass", true);

        OP_BYPASS = builder
                .comment("Операторы обходят запреты на ломание и строительство (даже в режиме выживания).")
                .define("opBypass", false);

        OP_BYPASS_LEVEL = builder
                .comment("Минимальный уровень прав, который считается оператором для opBypass.")
                .defineInRange("opBypassLevel", 2, 1, 4);

        builder.pop();

        builder.comment("Атмосфера: туман, музыка, жуткие звуки").push("atmosphere");

        FOG_NEAR = builder
                .comment("Расстояние в блоках, с которого начинается туман.")
                .defineInRange("fogNear", 4.0D, 0.0D, 64.0D);

        FOG_FAR = builder
                .comment("Расстояние в блоках, на котором туман полностью скрывает местность.",
                        "Если меньше fogNear + 1, используется fogNear + 1.")
                .defineInRange("fogFar", 32.0D, 4.0D, 256.0D);

        MUSIC_ENABLED = builder
                .comment("Включить мрачную музыку биома рынка. Задержки между треками заданы в биоме",
                        "(data/ghostmarket/worldgen/biome/ghost_market.json, min_delay и max_delay).")
                .define("musicEnabled", true);

        AMBIENT_SOUNDS_ENABLED = builder
                .comment("Включить случайные жуткие звуки вокруг игрока на рынке.")
                .define("ambientSoundsEnabled", true);

        AMBIENT_SOUND_CHECK_INTERVAL_TICKS = builder
                .comment("Раз в сколько тиков для каждого игрока на рынке проверяется шанс жуткого звука.")
                .defineInRange("ambientSoundCheckIntervalTicks", 100, 20, 6000);

        AMBIENT_SOUND_CHANCE = builder
                .comment("Шанс (0.0-1.0), что при проверке прозвучит жуткий звук.")
                .defineInRange("ambientSoundChance", 0.35D, 0.0D, 1.0D);

        AMBIENT_SOUND_MIN_DISTANCE = builder
                .comment("Минимальное расстояние от игрока до источника жуткого звука, блоки.")
                .defineInRange("ambientSoundMinDistance", 6.0D, 0.0D, 64.0D);

        AMBIENT_SOUND_MAX_DISTANCE = builder
                .comment("Максимальное расстояние от игрока до источника жуткого звука, блоки.",
                        "Если меньше минимального, используется минимальное.")
                .defineInRange("ambientSoundMaxDistance", 18.0D, 0.0D, 64.0D);

        AMBIENT_SOUND_VOLUME = builder
                .comment("Громкость жутких звуков.")
                .defineInRange("ambientSoundVolume", 0.8D, 0.0D, 10.0D);

        AMBIENT_SOUND_MIN_PITCH = builder
                .comment("Минимальная высота жутких звуков (0.5-2.0).")
                .defineInRange("ambientSoundMinPitch", 0.6D, 0.5D, 2.0D);

        AMBIENT_SOUND_MAX_PITCH = builder
                .comment("Максимальная высота жутких звуков (0.5-2.0). Если меньше минимальной, используется минимальная.")
                .defineInRange("ambientSoundMaxPitch", 1.0D, 0.5D, 2.0D);

        builder.pop();

        builder.comment("Сеанс на рынке: длительность, предупреждение, штраф, смерть (этап 2Б).",
                "Время считается по главному миру (Overworld).").push("session");

        builder.comment("Длительность сеанса").push("duration");

        SESSION_DAWN_TICK = builder
                .comment("Время суток главного мира (0-23999), когда наступает «рассвет» и рынок закрывается.",
                        "23000 примерно соответствует первым лучам солнца.")
                .defineInRange("dawnTick", 23000, 0, 23999);

        SESSION_MIN_TICKS = builder
                .comment("Минимальная длительность сеанса в тиках (20 тиков = 1 секунда).",
                        "Если до рассвета осталось меньше, игрок всё равно получит столько.")
                .defineInRange("minDurationTicks", 4000, 100, 240000);

        SESSION_MAX_TICKS = builder
                .comment("Максимальная длительность сеанса в тиках. Если меньше минимальной, используется минимальная.",
                        "Также служит страховкой, если цикл дня и ночи выключен командой gamerule.")
                .defineInRange("maxDurationTicks", 6000, 100, 240000);

        TIMER_SYNC_INTERVAL_TICKS = builder
                .comment("Раз в сколько тиков сервер уточняет таймер на экране у клиента.",
                        "Между уточнениями клиент отсчитывает время сам.")
                .defineInRange("timerSyncIntervalTicks", 100, 20, 1200);

        builder.pop();

        builder.comment("Предупреждение перед закрытием").push("warning");

        WARNING_TICKS = builder
                .comment("За сколько тиков до конца сеанса приходит предупреждение и начинает сгущаться туман.",
                        "1200 тиков = 1 минута.")
                .defineInRange("warningTicks", 1200, 20, 24000);

        WARNING_SOUND_VOLUME = builder
                .comment("Громкость шёпота при предупреждении.")
                .defineInRange("warningSoundVolume", 1.0D, 0.0D, 10.0D);

        WARNING_SOUND_PITCH = builder
                .comment("Высота шёпота при предупреждении (0.5-2.0).")
                .defineInRange("warningSoundPitch", 0.7D, 0.5D, 2.0D);

        FOG_WARNING_NEAR = builder
                .comment("Где начинается туман в самый последний момент сеанса, блоки.",
                        "За время предупреждения туман плавно переходит от fogNear к этому значению.")
                .defineInRange("fogWarningNear", 1.0D, 0.0D, 64.0D);

        FOG_WARNING_FAR = builder
                .comment("Где туман полностью скрывает местность в самый последний момент сеанса, блоки.",
                        "Если меньше fogWarningNear + 1, используется fogWarningNear + 1.")
                .defineInRange("fogWarningFar", 12.0D, 4.0D, 256.0D);

        builder.pop();

        builder.comment("Штраф за опоздание (выброс по таймеру)").push("penalty");

        PENALTY_WEAKNESS_MINUTES = builder
                .comment("Сколько минут длится слабость после опоздания. 0 отключает эффект.")
                .defineInRange("weaknessMinutes", 5, 0, 120);

        PENALTY_WEAKNESS_AMPLIFIER = builder
                .comment("Уровень слабости: 0 = Слабость I, 1 = Слабость II и так далее.")
                .defineInRange("weaknessAmplifier", 0, 0, 4);

        PENALTY_CURRENCY_PERCENT = builder
                .comment("Какой процент валюты «Последний вздох» забирает рынок у опоздавшего (округляется вверх).",
                        "0 отключает потерю валюты.")
                .defineInRange("currencyLossPercent", 25, 0, 100);

        builder.pop();

        builder.comment("Смерть и возвращение").push("safety");

        KEEP_KEY_ON_MARKET_DEATH = builder
                .comment("Странный ключ не теряется, если игрок умер на рынке (независимо от gamerule keepInventory).",
                        "Ключ возвращается игроку при возрождении.")
                .define("keepKeyOnMarketDeath", true);

        RETURN_SEARCH_HEIGHT = builder
                .comment("Если точка возврата оказалась занята блоками, на сколько блоков вверх искать свободное место.",
                        "Если не нашлось, игрок возвращается на точку мирового спавна.")
                .defineInRange("returnSearchHeight", 8, 0, 64);

        builder.pop();

        builder.pop(); // session

        builder.comment("Торговля (этап 4Б). Сами позиции лежат в data/ghostmarket/merchant_stock/<вид>.json").push("trade");

        TRADE_SLOTS = builder
                .comment("Сколько позиций показывает каждый торговец за один визит (окно рассчитано максимум на 8).")
                .defineInRange("slots", 3, 1, 8);

        TRADE_RANDOM_SHARE = builder
                .comment("Доля случайных позиций (0.0-1.0). Остальные берутся из позиций с always = true.",
                        "Если таких позиций не хватает, недостающее добирается случайно.")
                .defineInRange("randomShare", 0.67D, 0.0D, 1.0D);

        TRADE_DISTANCE = builder
                .comment("Максимальное расстояние до торговца, на котором можно открыть окно и покупать, блоки.",
                        "Если игрок отошёл дальше, окно закрывается.")
                .defineInRange("maxDistance", 6.0D, 2.0D, 32.0D);

        TRADE_PURCHASE_COOLDOWN_TICKS = builder
                .comment("Минимальная пауза между покупками в одном окне, тиков (защита от двойных кликов).")
                .defineInRange("purchaseCooldownTicks", 10, 0, 200);

        TRADE_SOUND_VOLUME = builder
                .comment("Громкость звука покупки.")
                .defineInRange("buySoundVolume", 1.0D, 0.0D, 10.0D);

        TRADE_SOUND_PITCH = builder
                .comment("Высота звука покупки (0.5-2.0).")
                .defineInRange("buySoundPitch", 0.6D, 0.5D, 2.0D);

        builder.pop();

        builder.pop(); // market

        SPEC = builder.build();
    }

    private GhostMarketConfig() {
    }
}

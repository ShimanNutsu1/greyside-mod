package com.example.ghostmarket.network;

import com.example.ghostmarket.client.ClientTradeHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Сервер -> клиент: какие позиции окна уже проданы (битовая маска). */
public record OfferStatePacket(int containerId, int soldMask) {

    public static void encode(OfferStatePacket packet, FriendlyByteBuf buf) {
        buf.writeVarInt(packet.containerId);
        buf.writeInt(packet.soldMask);
    }

    public static OfferStatePacket decode(FriendlyByteBuf buf) {
        return new OfferStatePacket(buf.readVarInt(), buf.readInt());
    }

    public static void handle(OfferStatePacket packet, Supplier<NetworkEvent.Context> context) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientTradeHandler.onOfferState(packet.containerId, packet.soldMask));
        context.get().setPacketHandled(true);
    }
}

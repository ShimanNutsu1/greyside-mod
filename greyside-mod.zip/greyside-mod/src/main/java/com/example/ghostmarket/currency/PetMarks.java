package com.example.ghostmarket.currency;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.entity.Entity;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

/**
 * Метки мода на сущностях. Хранятся в persistent data (ForgeData) под ключом "ghostmarket",
 * сохраняются вместе с сущностью.
 */
public final class PetMarks {
    public static final long NO_TIME = -1L;

    private static final String ROOT = "ghostmarket";
    private static final String TAMER = "Tamer";
    private static final String TAME_TIME = "TameTime";
    private static final String BRED = "Bred";
    private static final String REWARDED = "Rewarded";

    @Nullable
    private static CompoundTag read(Entity entity) {
        CompoundTag data = entity.getPersistentData();
        return data.contains(ROOT, Tag.TAG_COMPOUND) ? data.getCompound(ROOT) : null;
    }

    private static CompoundTag write(Entity entity) {
        CompoundTag data = entity.getPersistentData();
        if (data.contains(ROOT, Tag.TAG_COMPOUND)) {
            return data.getCompound(ROOT);
        }
        CompoundTag created = new CompoundTag();
        data.put(ROOT, created);
        return created;
    }

    public static void markTamed(Entity entity, UUID tamer, long gameTime) {
        CompoundTag tag = write(entity);
        tag.putUUID(TAMER, tamer);
        tag.putLong(TAME_TIME, gameTime);
    }

    @Nullable
    public static UUID getTamer(Entity entity) {
        CompoundTag tag = read(entity);
        return (tag != null && tag.hasUUID(TAMER)) ? tag.getUUID(TAMER) : null;
    }

    /** Игровое время приручения в тиках или NO_TIME, если метки нет. */
    public static long getTameTime(Entity entity) {
        CompoundTag tag = read(entity);
        if (tag == null || !tag.contains(TAME_TIME, Tag.TAG_LONG)) {
            return NO_TIME;
        }
        return tag.getLong(TAME_TIME);
    }

    public static void markBred(Entity entity) {
        write(entity).putBoolean(BRED, true);
    }

    public static boolean isBred(Entity entity) {
        CompoundTag tag = read(entity);
        return tag != null && tag.getBoolean(BRED);
    }

    /** Защита от двойной выдачи, если die() вызвали дважды за один тик. */
    public static void markRewarded(Entity entity) {
        write(entity).putBoolean(REWARDED, true);
    }

    public static boolean isRewarded(Entity entity) {
        CompoundTag tag = read(entity);
        return tag != null && tag.getBoolean(REWARDED);
    }

    private PetMarks() {
    }
}

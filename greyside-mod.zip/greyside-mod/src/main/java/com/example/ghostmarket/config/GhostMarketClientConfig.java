package com.example.ghostmarket.config;

import net.minecraftforge.common.ForgeConfigSpec;

/** Клиентские настройки отображения (хранятся в ghostmarket-client.toml). */
public final class GhostMarketClientConfig {
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.BooleanValue HUD_ENABLED;
    public static final ForgeConfigSpec.IntValue HUD_OFFSET_Y;
    public static final ForgeConfigSpec.DoubleValue HUD_SCALE;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();

        builder.comment("Таймер сеанса на экране (этап 2Б)").push("hud");

        HUD_ENABLED = builder
                .comment("Показывать таймер до закрытия рынка.")
                .define("hudEnabled", true);

        HUD_OFFSET_Y = builder
                .comment("Отступ таймера от верхнего края экрана, пиксели.")
                .defineInRange("hudOffsetY", 30, 0, 2000);

        HUD_SCALE = builder
                .comment("Масштаб текста таймера.")
                .defineInRange("hudScale", 1.2D, 0.5D, 4.0D);

        builder.pop();

        SPEC = builder.build();
    }

    private GhostMarketClientConfig() {
    }
}

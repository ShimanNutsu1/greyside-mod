package com.example.ghostmarket.dimension;

import com.example.ghostmarket.GhostMarket;
import com.example.ghostmarket.config.GhostMarketConfig;
import com.example.ghostmarket.registry.ModSounds;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;


/**
 * Случайные жуткие звуки вокруг игрока на рынке. Слышит их только сам игрок,
 * поэтому несколько игроков не складываются в сплошной шум.
 */
@Mod.EventBusSubscriber(modid = GhostMarket.MODID)
public final class MarketAmbienceEvents {

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side != LogicalSide.SERVER) {
            return;
        }
        if (!(event.player instanceof ServerPlayer player)) {
            return;
        }
        if (!GhostMarketConfig.SPEC.isLoaded() || !GhostMarketConfig.AMBIENT_SOUNDS_ENABLED.get()) {
            return;
        }
        if (!ModDimensions.isMarket(player.level())) {
            return;
        }
        if (player.tickCount % GhostMarketConfig.AMBIENT_SOUND_CHECK_INTERVAL_TICKS.get() != 0) {
            return;
        }

        RandomSource random = player.getRandom();
        if (random.nextDouble() >= GhostMarketConfig.AMBIENT_SOUND_CHANCE.get()) {
            return;
        }

        var sounds = ModSounds.MARKET_ONE_SHOTS;
        SoundEvent sound = sounds.get(random.nextInt(sounds.size())).get();

        double minDistance = GhostMarketConfig.AMBIENT_SOUND_MIN_DISTANCE.get();
        double maxDistance = Math.max(minDistance, GhostMarketConfig.AMBIENT_SOUND_MAX_DISTANCE.get());
        double distance = minDistance + random.nextDouble() * (maxDistance - minDistance);
        double angle = random.nextDouble() * Math.PI * 2.0D;
        double x = player.getX() + Math.cos(angle) * distance;
        double y = player.getY() + random.nextDouble() * 2.0D;
        double z = player.getZ() + Math.sin(angle) * distance;

        double minPitch = GhostMarketConfig.AMBIENT_SOUND_MIN_PITCH.get();
        double maxPitch = Math.max(minPitch, GhostMarketConfig.AMBIENT_SOUND_MAX_PITCH.get());
        float pitch = (float) (minPitch + random.nextDouble() * (maxPitch - minPitch));
        float volume = GhostMarketConfig.AMBIENT_SOUND_VOLUME.get().floatValue();

        player.connection.send(new ClientboundSoundPacket(
                BuiltInRegistries.SOUND_EVENT.wrapAsHolder(sound),
                SoundSource.AMBIENT, x, y, z, volume, pitch, random.nextLong()));
    }

    private MarketAmbienceEvents() {
    }
}

package com.example.ghostmarket.client;

import com.example.ghostmarket.GhostMarket;
import com.example.ghostmarket.entity.MerchantEntity;
import com.example.ghostmarket.trade.MerchantType;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

import java.util.EnumMap;
import java.util.Map;

/**
 * Пути к ассетам торговца строятся из его id, код при подмене файлов менять не нужно:
 *   assets/ghostmarket/geo/entity/<id>.geo.json
 *   assets/ghostmarket/animations/entity/<id>.animation.json
 *   assets/ghostmarket/textures/entity/<id>.png
 */
public class MerchantModel extends GeoModel<MerchantEntity> {
    private final Map<MerchantType, ResourceLocation> models = new EnumMap<>(MerchantType.class);
    private final Map<MerchantType, ResourceLocation> textures = new EnumMap<>(MerchantType.class);
    private final Map<MerchantType, ResourceLocation> animations = new EnumMap<>(MerchantType.class);

    public MerchantModel() {
        for (MerchantType type : MerchantType.values()) {
            models.put(type, new ResourceLocation(GhostMarket.MODID, "geo/entity/" + type.id() + ".geo.json"));
            textures.put(type, new ResourceLocation(GhostMarket.MODID, "textures/entity/" + type.id() + ".png"));
            animations.put(type, new ResourceLocation(GhostMarket.MODID, "animations/entity/" + type.id() + ".animation.json"));
        }
    }

    @Override
    public ResourceLocation getModelResource(MerchantEntity entity) {
        return models.get(entity.getMerchantType());
    }

    @Override
    public ResourceLocation getTextureResource(MerchantEntity entity) {
        return textures.get(entity.getMerchantType());
    }

    @Override
    public ResourceLocation getAnimationResource(MerchantEntity entity) {
        return animations.get(entity.getMerchantType());
    }
}

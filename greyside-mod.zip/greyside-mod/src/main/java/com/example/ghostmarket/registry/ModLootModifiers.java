package com.example.ghostmarket.registry;

import com.example.ghostmarket.GhostMarket;
import com.example.ghostmarket.loot.AddStrangeKeyModifier;
import com.mojang.serialization.Codec;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModLootModifiers {
    public static final DeferredRegister<Codec<? extends IGlobalLootModifier>> LOOT_MODIFIERS =
            DeferredRegister.create(ForgeRegistries.Keys.GLOBAL_LOOT_MODIFIER_SERIALIZERS, GhostMarket.MODID);

    public static final RegistryObject<Codec<? extends IGlobalLootModifier>> ADD_STRANGE_KEY =
            LOOT_MODIFIERS.register("add_strange_key", AddStrangeKeyModifier.CODEC);

    public static void register(IEventBus modBus) {
        LOOT_MODIFIERS.register(modBus);
    }

    private ModLootModifiers() {
    }
}

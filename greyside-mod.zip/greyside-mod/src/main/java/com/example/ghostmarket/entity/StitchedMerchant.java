package com.example.ghostmarket.entity;

import com.example.ghostmarket.trade.MerchantType;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

public class StitchedMerchant extends MerchantEntity {
    public StitchedMerchant(EntityType<StitchedMerchant> type, Level level) {
        super(type, level, MerchantType.STITCHED);
    }
}

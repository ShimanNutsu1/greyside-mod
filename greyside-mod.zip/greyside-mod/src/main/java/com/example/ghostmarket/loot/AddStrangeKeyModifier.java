package com.example.ghostmarket.loot;

import com.example.ghostmarket.config.GhostMarketConfig;
import com.example.ghostmarket.registry.ModItems;
import com.google.common.base.Suppliers;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.common.loot.LootModifier;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.function.Supplier;

public class AddStrangeKeyModifier extends LootModifier {
    public static final Supplier<Codec<AddStrangeKeyModifier>> CODEC = Suppliers.memoize(() ->
            RecordCodecBuilder.create(inst -> codecStart(inst)
                    .and(ResourceLocation.CODEC.listOf().fieldOf("loot_tables").forGetter(m -> m.lootTables))
                    .apply(inst, AddStrangeKeyModifier::new)));

    private final List<ResourceLocation> lootTables;

    public AddStrangeKeyModifier(LootItemCondition[] conditions, List<ResourceLocation> lootTables) {
        super(conditions);
        this.lootTables = lootTables;
    }

    @Override
    protected @NotNull ObjectArrayList<ItemStack> doApply(ObjectArrayList<ItemStack> generatedLoot, LootContext context) {
        if (!lootTables.contains(context.getQueriedLootTableId())) {
            return generatedLoot;
        }
        if (context.getRandom().nextDouble() < GhostMarketConfig.KEY_LOOT_CHANCE.get()) {
            generatedLoot.add(new ItemStack(ModItems.STRANGE_KEY.get()));
        }
        return generatedLoot;
    }

    @Override
    public Codec<? extends IGlobalLootModifier> codec() {
        return CODEC.get();
    }
}

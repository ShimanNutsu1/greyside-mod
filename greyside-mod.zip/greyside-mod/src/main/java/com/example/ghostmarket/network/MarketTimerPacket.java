package com.example.ghostmarket.network;

import com.example.ghostmarket.client.ClientMarketTimer;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Сервер -> клиент: сколько тиков осталось до закрытия рынка. active = false выключает таймер.
 */
public record MarketTimerPacket(boolean active, int remainingTicks) {

    public static void encode(MarketTimerPacket packet, FriendlyByteBuf buf) {
        buf.writeBoolean(packet.active);
        buf.writeVarInt(packet.remainingTicks);
    }

    public static MarketTimerPacket decode(FriendlyByteBuf buf) {
        return new MarketTimerPacket(buf.readBoolean(), buf.readVarInt());
    }

    public static void handle(MarketTimerPacket packet, Supplier<NetworkEvent.Context> context) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientMarketTimer.sync(packet.active, packet.remainingTicks));
        context.get().setPacketHandled(true);
    }
}

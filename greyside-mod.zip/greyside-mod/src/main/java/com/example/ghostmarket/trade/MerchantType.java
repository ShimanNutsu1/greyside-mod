package com.example.ghostmarket.trade;

import org.jetbrains.annotations.Nullable;

/** Виды торговцев. id совпадает с именем файла ассортимента: data/ghostmarket/merchant_stock/<id>.json */
public enum MerchantType {
    BLOATED("bloated"),
    STITCHED("stitched"),
    FACELESS("faceless"),
    HANGED("hanged");

    private final String id;

    MerchantType(String id) {
        this.id = id;
    }

    public String id() {
        return id;
    }

    @Nullable
    public static MerchantType fromId(String id) {
        for (MerchantType type : values()) {
            if (type.id.equals(id)) {
                return type;
            }
        }
        return null;
    }
}

package com.example.ghostmarket.dimension;

import com.example.ghostmarket.GhostMarket;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import org.jetbrains.annotations.Nullable;

public final class ModDimensions {
    /** Один и тот же id у измерения, типа измерения, биома, настроек шума и клиентских эффектов. */
    public static final ResourceLocation MARKET_ID = new ResourceLocation(GhostMarket.MODID, "ghost_market");

    public static final ResourceKey<Level> GHOST_MARKET = ResourceKey.create(Registries.DIMENSION, MARKET_ID);

    public static boolean isMarket(@Nullable LevelAccessor level) {
        return level instanceof Level l && l.dimension().equals(GHOST_MARKET);
    }

    private ModDimensions() {
    }
}

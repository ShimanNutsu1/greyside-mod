package com.example.ghostmarket.dimension;

import com.example.ghostmarket.GhostMarket;
import com.example.ghostmarket.config.GhostMarketConfig;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.BucketItem;
import net.minecraft.world.item.FireChargeItem;
import net.minecraft.world.item.FlintAndSteelItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.event.entity.EntityMobGriefingEvent;
import net.minecraftforge.event.entity.player.FillBucketEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.level.ExplosionEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Правила рынка: нельзя ломать и ставить блоки. Творческий режим и операторы обходят запреты по настройкам.
 * Решение принимается по одним и тем же правилам на клиенте и на сервере, чтобы не было «призрачных» блоков.
 */
@Mod.EventBusSubscriber(modid = GhostMarket.MODID)
public final class MarketProtectionEvents {

    private static boolean active(LevelAccessor level) {
        return GhostMarketConfig.SPEC.isLoaded() && ModDimensions.isMarket(level);
    }

    private static boolean bypasses(Player player) {
        if (player == null) {
            return false;
        }
        if (GhostMarketConfig.CREATIVE_BYPASS.get() && player.isCreative()) {
            return true;
        }
        return GhostMarketConfig.OP_BYPASS.get() && player.hasPermissions(GhostMarketConfig.OP_BYPASS_LEVEL.get());
    }

    private static boolean breakingDenied(LevelAccessor level, Player player) {
        return active(level) && GhostMarketConfig.BLOCK_BREAKING.get() && !bypasses(player);
    }

    private static boolean placingDenied(LevelAccessor level, Player player) {
        return active(level) && GhostMarketConfig.BLOCK_PLACING.get() && !bypasses(player);
    }

    @SubscribeEvent
    public static void onBreak(BlockEvent.BreakEvent event) {
        if (breakingDenied(event.getLevel(), event.getPlayer())) {
            event.setCanceled(true);
        }
    }

    /** Отменяет сам удар по блоку, чтобы клиент даже не начинал ломать. */
    @SubscribeEvent
    public static void onLeftClickBlock(PlayerInteractEvent.LeftClickBlock event) {
        if (breakingDenied(event.getLevel(), event.getEntity())) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onPlace(BlockEvent.EntityPlaceEvent event) {
        if (event.getEntity() instanceof Player player && placingDenied(event.getLevel(), player)) {
            event.setCanceled(true);
        }
    }

    /**
     * Предмет в руке не используется для постановки блоков, но сам блок под курсором работает как обычно
     * (двери, сундуки, будущие прилавки продавцов).
     */
    @SubscribeEvent
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (!placingDenied(event.getLevel(), event.getEntity())) {
            return;
        }
        Item item = event.getItemStack().getItem();
        if (item instanceof BlockItem || item instanceof BucketItem
                || item instanceof FlintAndSteelItem || item instanceof FireChargeItem) {
            event.setUseItem(Event.Result.DENY);
        }
    }

    @SubscribeEvent
    public static void onFillBucket(FillBucketEvent event) {
        if (placingDenied(event.getLevel(), event.getEntity())) {
            event.setCanceled(true);
        }
    }

    /** Топор, лопата, мотыга: стесать кору, сделать тропинку, вспахать. */
    @SubscribeEvent
    public static void onToolModification(BlockEvent.BlockToolModificationEvent event) {
        Player player = event.getPlayer();
        if (breakingDenied(event.getLevel(), player) || placingDenied(event.getLevel(), player)) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onExplosion(ExplosionEvent.Detonate event) {
        if (active(event.getLevel()) && GhostMarketConfig.BLOCK_BREAKING.get()) {
            event.getAffectedBlocks().clear();
        }
    }

    @SubscribeEvent
    public static void onMobGriefing(EntityMobGriefingEvent event) {
        Entity entity = event.getEntity();
        if (entity != null && active(entity.level()) && GhostMarketConfig.BLOCK_BREAKING.get()) {
            event.setResult(Event.Result.DENY);
        }
    }

    private MarketProtectionEvents() {
    }
}

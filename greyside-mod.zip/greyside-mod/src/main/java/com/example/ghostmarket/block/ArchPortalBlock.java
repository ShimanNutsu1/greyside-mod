package com.example.ghostmarket.block;

import com.example.ghostmarket.dimension.ModDimensions;
import com.example.ghostmarket.session.MarketSessions;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraft.server.level.ServerPlayer;

/**
 * Полотно портал-арки на рынке. Не имеет коллизии: игрок проходит сквозь него и покидает рынок.
 * Сама телепортация выполняется в конце тика (MarketSessions.requestArchExit).
 */
public class ArchPortalBlock extends Block {
    private static final VoxelShape SHAPE = Block.box(0.0D, 0.0D, 7.0D, 16.0D, 16.0D, 9.0D);

    public ArchPortalBlock(Properties properties) {
        super(properties);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (level.isClientSide() || !ModDimensions.isMarket(level)) {
            return;
        }
        if (entity instanceof ServerPlayer player && !(player instanceof FakePlayer)) {
            MarketSessions.requestArchExit(player.getUUID());
        }
    }

    @Override
    public ItemStack getCloneItemStack(BlockGetter level, BlockPos pos, BlockState state) {
        return ItemStack.EMPTY;
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        if (random.nextInt(4) != 0) {
            return;
        }
        double x = pos.getX() + random.nextDouble();
        double y = pos.getY() + random.nextDouble();
        double z = pos.getZ() + 0.35D + random.nextDouble() * 0.3D;
        level.addParticle(ParticleTypes.SOUL, x, y, z, 0.0D, 0.02D, 0.0D);
        if (random.nextInt(3) == 0) {
            level.addParticle(ParticleTypes.REVERSE_PORTAL, x, y, z, 0.0D, 0.0D, 0.0D);
        }
    }
}

package com.example.ghostmarket.trade;

import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/** Заглушка: выдаёт обычный предмет. */
public class ItemGood implements Good {
    private final ResourceLocation id;
    private final Item item;
    private final int count;

    public ItemGood(ResourceLocation id, Item item, int count) {
        this.id = id;
        this.item = item;
        this.count = count;
    }

    @Override
    public ResourceLocation id() {
        return id;
    }

    /** Считаем место только в основных слотах: это строже, чем реальное добавление, и дюпа не даёт. */
    @Override
    public boolean canGive(ServerPlayer player) {
        int max = new ItemStack(item).getMaxStackSize();
        int room = 0;
        for (ItemStack stack : player.getInventory().items) {
            if (stack.isEmpty()) {
                room += max;
            } else if (stack.is(item) && !stack.hasTag() && stack.getCount() < max) {
                room += max - stack.getCount();
            }
            if (room >= count) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean give(ServerPlayer player) {
        Inventory inventory = player.getInventory();
        ItemStack stack = new ItemStack(item, count);
        inventory.add(stack);
        inventory.setChanged();
        return stack.isEmpty();
    }

    @Override
    public Component describe() {
        return Component.translatable("screen.ghostmarket.merchant.gives", count, item.getDescription());
    }
}

package com.example.ghostmarket.network;

import com.example.ghostmarket.GhostMarket;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class GhostMarketNetwork {
    private static final String PROTOCOL = "2";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(GhostMarket.MODID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private static boolean registered;

    /** Вызывается один раз из FMLCommonSetupEvent. */
    public static synchronized void register() {
        if (registered) {
            return;
        }
        registered = true;
        int id = 0;
        CHANNEL.messageBuilder(MarketTimerPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(MarketTimerPacket::encode)
                .decoder(MarketTimerPacket::decode)
                .consumerMainThread(MarketTimerPacket::handle)
                .add();
        CHANNEL.messageBuilder(OfferStatePacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(OfferStatePacket::encode)
                .decoder(OfferStatePacket::decode)
                .consumerMainThread(OfferStatePacket::handle)
                .add();
        CHANNEL.messageBuilder(BuyRequestPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(BuyRequestPacket::encode)
                .decoder(BuyRequestPacket::decode)
                .consumerMainThread(BuyRequestPacket::handle)
                .add();
    }

    private GhostMarketNetwork() {
    }
}

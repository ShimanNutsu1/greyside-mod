package com.example.ghostmarket;

import com.example.ghostmarket.config.GhostMarketClientConfig;
import com.example.ghostmarket.config.GhostMarketConfig;
import com.example.ghostmarket.config.MerchantConfig;
import com.example.ghostmarket.network.GhostMarketNetwork;
import com.example.ghostmarket.registry.ModBlocks;
import com.example.ghostmarket.registry.ModEntities;
import com.example.ghostmarket.registry.ModItems;
import com.example.ghostmarket.registry.ModLootModifiers;
import com.example.ghostmarket.registry.ModMenus;
import com.example.ghostmarket.registry.ModSounds;
import com.mojang.logging.LogUtils;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(GhostMarket.MODID)
public class GhostMarket {
    public static final String MODID = "ghostmarket";
    public static final Logger LOGGER = LogUtils.getLogger();

    public GhostMarket() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();

        ModBlocks.register(modBus);
        ModItems.register(modBus);
        ModEntities.register(modBus);
        ModSounds.register(modBus);
        ModMenus.register(modBus);
        ModLootModifiers.register(modBus);
        modBus.addListener(this::onCommonSetup);

        ModLoadingContext.get().registerConfig(ModConfig.Type.SERVER, GhostMarketConfig.SPEC);
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, GhostMarketClientConfig.SPEC);
        // Этап 4А: отдельный файл настроек торговцев, чтобы не раздувать основной конфиг.
        ModLoadingContext.get().registerConfig(ModConfig.Type.SERVER, MerchantConfig.SPEC, "ghostmarket-merchants.toml");
    }

    private void onCommonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(GhostMarketNetwork::register);
    }
}

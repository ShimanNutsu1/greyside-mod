package com.example.ghostmarket.key;

import com.example.ghostmarket.GhostMarket;
import com.example.ghostmarket.config.GhostMarketConfig;
import com.example.ghostmarket.dimension.ModDimensions;
import com.example.ghostmarket.registry.ModItems;
import com.example.ghostmarket.registry.ModSounds;
import com.example.ghostmarket.session.MarketSessions;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = GhostMarket.MODID)
public final class StrangeKeyEvents {

    @SubscribeEvent
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        ItemStack stack = event.getItemStack();
        if (!stack.is(ModItems.STRANGE_KEY.get()) || !GhostMarketConfig.SPEC.isLoaded()) {
            return;
        }

        Level level = event.getLevel();
        // На самом рынке ключ не работает: двери там открываются как обычно.
        if (ModDimensions.isMarket(level)) {
            return;
        }

        BlockPos pos = event.getPos();
        if (!KeyRules.isValidTarget(level.getBlockState(pos))) {
            return;
        }

        KeyRules.State state = KeyRules.evaluate(level.getDayTime(), KeyRules.getLastUsedNight(stack));
        if (state.status() != KeyRules.Status.WHISPERING) {
            // Не время или кулдаун: ключ ничего не делает, дверь ведёт себя как обычно.
            return;
        }

        // Время верное: ключ забирает на себя это взаимодействие, дверь не переключается.
        // Решение принимается и на клиенте, и на сервере, чтобы дверь не дёргалась.
        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.sidedSuccess(level.isClientSide()));

        if (level.isClientSide()) {
            return;
        }
        if (!(event.getEntity() instanceof ServerPlayer player) || player instanceof FakePlayer) {
            return;
        }

        // Если измерения рынка нет, ключ не тратится.
        if (player.server.getLevel(ModDimensions.GHOST_MARKET) == null) {
            player.displayClientMessage(Component.translatable("message.ghostmarket.market_unavailable"), false);
            return;
        }

        stack.getOrCreateTag().putLong(KeyRules.TAG_LAST_USED_NIGHT, state.currentNight());

        level.playSound(null, pos, ModSounds.KEY_DOOR_OPEN.get(), SoundSource.BLOCKS,
                GhostMarketConfig.DOOR_SOUND_VOLUME.get().floatValue(),
                GhostMarketConfig.DOOR_SOUND_PITCH.get().floatValue());

        player.displayClientMessage(Component.translatable("message.ghostmarket.door_opened"), false);

        // Точка возврата запоминается внутри enter(): это позиция игрока в момент использования ключа.
        MarketSessions.enter(player);
    }

    private StrangeKeyEvents() {
    }
}

package com.example.ghostmarket.entity;

import com.example.ghostmarket.config.MerchantConfig;
import com.example.ghostmarket.registry.ModSounds;
import com.example.ghostmarket.trade.MerchantType;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * Базовый торговец рынка призраков (Этап 4А).
 *
 * Это обычная Entity, а не живое существо: у неё нет здоровья, воздуха, ИИ и спавн-яйца.
 * Поэтому её нельзя убить уроном, а ванильные ограничения (яйцо только для Mob) обходятся без костылей.
 * Всё, что делает торговца неубиваемым и неподвижным, собрано в блоке "Неуязвимость и неподвижность" ниже.
 *
 * КРЮЧОК ЭТАПА 4Б: {@link #onTradeRequested(ServerPlayer)}.
 */
public abstract class MerchantEntity extends Entity implements GeoEntity {
    private static final String TAG_SLOT = "Slot";
    private static final String TAG_HOME_X = "HomeX";
    private static final String TAG_HOME_Y = "HomeY";
    private static final String TAG_HOME_Z = "HomeZ";

    /** Ниже этой отметки относительно дна мира торговец возвращается на своё место (защита от пустоты). */
    private static final int VOID_RESCUE_MARGIN = 16;

    private final MerchantType kind;
    private final AnimatableInstanceCache animationCache = GeckoLibUtil.createInstanceCache(this);

    /** Ключ места на рынке, например "bloated:0". Есть только у торговцев, расставленных автоматически. */
    @Nullable
    private String slotKey;
    @Nullable
    private Vec3 home;

    private int idleSoundCountdown = -1;
    private long lastInteractTick = Long.MIN_VALUE / 2;

    protected MerchantEntity(EntityType<? extends MerchantEntity> type, Level level, MerchantType kind) {
        super(type, level);
        this.kind = kind;
        this.setInvulnerable(true);
    }

    // ------------------------------------------------------------------ вид и место

    public MerchantType getMerchantType() {
        return kind;
    }

    /** id вида: bloated, stitched, faceless, hanged. Совпадает с merchant_stock/<id>.json и с именами файлов ассетов. */
    public String getKindId() {
        return kind.id();
    }

    @Nullable
    public String getSlotKey() {
        return slotKey;
    }

    @Nullable
    public Vec3 getHome() {
        return home;
    }

    /** Ставит торговца на место рынка и запоминает его. Вызывается расстановкой (MerchantPlacement). */
    public void placeAt(String slotKey, Vec3 pos, float yaw) {
        this.slotKey = slotKey;
        this.home = pos;
        this.moveTo(pos.x, pos.y, pos.z, yaw, 0.0F);
    }

    /** Запоминает место, не двигая торговца (для сохранений без записи о месте). */
    public void rememberHome(Vec3 pos) {
        this.home = pos;
    }

    // ------------------------------------------------------------------ КРЮЧОК ЭТАПА 4Б

    /**
     * КРЮЧОК ЭТАПА 4Б. Вызывается на сервере, когда игрок нажал ПКМ по торговцу (после шёпота и паузы).
     * Сейчас: сообщение-заглушка. В 4Б замени тело метода одной строкой:
     *     MerchantTrade.open(player, this, getMerchantType());
     * (MerchantTrade уже лежит в trade/, он сам проверит расстояние, измерение и сеанс).
     */
    protected void onTradeRequested(ServerPlayer player) {
        player.sendSystemMessage(Component.translatable("message.ghostmarket.merchant_stub." + kind.id()));
    }

    // ------------------------------------------------------------------ взаимодействие

    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) {
            return InteractionResult.PASS;
        }
        if (this.level().isClientSide) {
            return InteractionResult.SUCCESS;
        }
        if (player instanceof ServerPlayer serverPlayer && MerchantConfig.SPEC.isLoaded()) {
            long now = this.level().getGameTime();
            if (now - lastInteractTick >= MerchantConfig.INTERACT_COOLDOWN_TICKS.get()) {
                lastInteractTick = now;
                playVoice(ModSounds.MERCHANT_WHISPER.get(), MerchantConfig.WHISPER_VOLUME.get().floatValue());
                onTradeRequested(serverPlayer);
            }
        }
        return InteractionResult.CONSUME;
    }

    /**
     * Удар по торговцу. Урона нет ни у кого, включая игроков в творческом режиме.
     * Единственное исключение: оператор, бьющий присев, убирает торговца (если это не выключено в конфиге).
     */
    @Override
    public boolean skipAttackInteraction(Entity attacker) {
        if (!this.level().isClientSide && attacker instanceof ServerPlayer player && MerchantConfig.SPEC.isLoaded()
                && MerchantConfig.OPERATOR_REMOVAL_ENABLED.get()
                && player.isShiftKeyDown()
                && player.hasPermissions(MerchantConfig.OPERATOR_PERMISSION_LEVEL.get())) {
            player.sendSystemMessage(Component.translatable("message.ghostmarket.merchant_removed", this.getDisplayName()));
            this.discard();
        }
        return true;
    }

    // ------------------------------------------------------------------ тик: взгляд, звуки, пустота

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide || !MerchantConfig.SPEC.isLoaded()) {
            return;
        }
        rescueFromVoid();
        lookAtNearestPlayer();
        tickIdleSound();
    }

    private void rescueFromVoid() {
        if (home != null && this.getY() < this.level().getMinBuildHeight() - VOID_RESCUE_MARGIN) {
            this.moveTo(home.x, home.y, home.z, this.getYRot(), 0.0F);
        }
    }

    private void lookAtNearestPlayer() {
        Player target = this.level().getNearestPlayer(this, MerchantConfig.LOOK_RADIUS.get());
        if (target == null) {
            return;
        }
        double dx = target.getX() - this.getX();
        double dz = target.getZ() - this.getZ();
        if (dx * dx + dz * dz < 1.0E-4D) {
            return;
        }
        float targetYaw = (float) (Mth.atan2(dz, dx) * (180.0D / Math.PI)) - 90.0F;
        float diff = Mth.wrapDegrees(targetYaw - this.getYRot());
        float maxStep = MerchantConfig.LOOK_TURN_SPEED.get().floatValue();
        this.setYRot(this.getYRot() + Mth.clamp(diff, -maxStep, maxStep));
    }

    private void tickIdleSound() {
        if (!MerchantConfig.SOUNDS_ENABLED.get()) {
            return;
        }
        if (idleSoundCountdown < 0) {
            idleSoundCountdown = rollIdleDelay();
            return;
        }
        if (--idleSoundCountdown > 0) {
            return;
        }
        idleSoundCountdown = rollIdleDelay();
        boolean crunch = this.random.nextDouble() < MerchantConfig.CRUNCH_CHANCE.get();
        SoundEvent sound = crunch ? ModSounds.MERCHANT_CRUNCH.get() : ModSounds.MERCHANT_MURMUR.get();
        playVoice(sound, MerchantConfig.IDLE_VOLUME.get().floatValue());
    }

    private int rollIdleDelay() {
        int min = MerchantConfig.IDLE_MIN_SECONDS.get();
        int max = Math.max(min, MerchantConfig.IDLE_MAX_SECONDS.get());
        return (min + this.random.nextInt(max - min + 1)) * 20;
    }

    // ------------------------------------------------------------------ звук

    /** Играет звук голосом этого вида. У Сшитого поверх звучит второй голос с другой высотой тона. */
    private void playVoice(SoundEvent sound, float volume) {
        float jitter = MerchantConfig.PITCH_JITTER.get().floatValue();
        float pitch = (float) MerchantConfig.pitch(kind) + (this.random.nextFloat() * 2.0F - 1.0F) * jitter;
        playAt(sound, volume, pitch);
        if (kind == MerchantType.STITCHED) {
            playAt(sound,
                    volume * MerchantConfig.STITCHED_SECOND_VOICE_VOLUME.get().floatValue(),
                    pitch * MerchantConfig.STITCHED_SECOND_VOICE_PITCH_RATIO.get().floatValue());
        }
    }

    private void playAt(SoundEvent sound, float volume, float pitch) {
        this.level().playSound(null, this.getX(), this.getY() + this.getBbHeight() * 0.6D, this.getZ(),
                sound, SoundSource.NEUTRAL, volume, Mth.clamp(pitch, 0.5F, 2.0F));
    }

    // ------------------------------------------------------------------ Неуязвимость и неподвижность

    /** Любой урон, включая /kill (generic_kill), пустоту и удар игрока в творческом режиме. */
    @Override
    public boolean isInvulnerableTo(DamageSource source) {
        return true;
    }

    @Override
    public boolean isInvulnerable() {
        return true;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return false;
    }

    /** /kill вызывает именно этот метод. Ничего не делаем. */
    @Override
    public void kill() {
    }

    @Override
    public boolean fireImmune() {
        return true;
    }

    @Override
    public boolean ignoreExplosion() {
        return true;
    }

    @Override
    public boolean isNoGravity() {
        return true;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public void push(Entity entity) {
    }

    @Override
    public void push(double x, double y, double z) {
    }

    @Override
    public boolean isPushedByFluid() {
        return false;
    }

    @Override
    public PushReaction getPistonPushReaction() {
        return PushReaction.IGNORE;
    }

    @Override
    public boolean canChangeDimensions() {
        return false;
    }

    /** Без этого в сущность нельзя прицелиться: ни ПКМ, ни удар оператора. */
    @Override
    public boolean isPickable() {
        return !this.isRemoved();
    }

    /** Модели могут выступать за хитбокс (брюхо, крюк), поэтому не отсекаем их раньше времени. */
    @Override
    public AABB getBoundingBoxForCulling() {
        return this.getBoundingBox().inflate(1.5D);
    }

    // ------------------------------------------------------------------ сохранение и сеть

    @Override
    protected void defineSynchedData() {
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        this.slotKey = tag.contains(TAG_SLOT, Tag.TAG_STRING) ? tag.getString(TAG_SLOT) : null;
        this.home = tag.contains(TAG_HOME_X, Tag.TAG_DOUBLE)
                ? new Vec3(tag.getDouble(TAG_HOME_X), tag.getDouble(TAG_HOME_Y), tag.getDouble(TAG_HOME_Z))
                : null;
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        if (slotKey != null) {
            tag.putString(TAG_SLOT, slotKey);
        }
        if (home != null) {
            tag.putDouble(TAG_HOME_X, home.x);
            tag.putDouble(TAG_HOME_Y, home.y);
            tag.putDouble(TAG_HOME_Z, home.z);
        }
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }

    // ------------------------------------------------------------------ GeckoLib

    /** Имя анимации покоя в animation.json: animation.<id>.idle */
    public static String idleAnimationName(MerchantType kind) {
        return "animation." + kind.id() + ".idle";
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        RawAnimation idle = RawAnimation.begin().thenLoop(idleAnimationName(kind));
        controllers.add(new AnimationController<>(this, "main", 0, state -> state.setAndContinue(idle)));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return animationCache;
    }
}

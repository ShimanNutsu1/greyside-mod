package com.example.ghostmarket.trade;

import com.example.ghostmarket.GhostMarket;
import com.example.ghostmarket.config.GhostMarketConfig;
import com.example.ghostmarket.currency.CurrencyAccess;
import com.example.ghostmarket.dimension.ModDimensions;
import com.example.ghostmarket.network.GhostMarketNetwork;
import com.example.ghostmarket.network.OfferStatePacket;
import com.example.ghostmarket.registry.ModMenus;
import com.example.ghostmarket.registry.ModSounds;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.DataSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.PacketDistributor;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Окно торговца: слотов нет, только данные. На сервере хранит живые позиции визита и решает всё сам.
 * Клиент присылает только номер позиции (BuyRequestPacket).
 */
public class MerchantMenu extends AbstractContainerMenu {
    private final MerchantType type;
    @Nullable
    private final UUID merchantUuid;
    private final long visitId;
    private final List<Offer> offers;
    private final Player player;
    private final DataSlot balance = DataSlot.standalone();

    private long lastBuyTick = Long.MIN_VALUE / 2;
    private boolean processing;

    /** Сервер. */
    public MerchantMenu(int id, Inventory inventory, MerchantType type, UUID merchantUuid, long visitId, List<Offer> offers) {
        this(id, inventory, type, merchantUuid, visitId, offers, true);
    }

    private MerchantMenu(int id, Inventory inventory, MerchantType type, @Nullable UUID merchantUuid, long visitId,
                         List<Offer> offers, boolean unused) {
        super(ModMenus.MERCHANT.get(), id);
        this.type = type;
        this.merchantUuid = merchantUuid;
        this.visitId = visitId;
        this.offers = offers;
        this.player = inventory.player;
        addDataSlot(balance);
        refreshBalance();
    }

    /** Клиент: данные пришли в буфере открытия. */
    public static MerchantMenu fromNetwork(int id, Inventory inventory, FriendlyByteBuf buf) {
        MerchantType type = MerchantType.fromId(buf.readUtf());
        int count = buf.readVarInt();
        List<Offer> offers = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            ResourceLocation good = buf.readResourceLocation();
            int price = buf.readVarInt();
            boolean sold = buf.readBoolean();
            offers.add(new Offer(good, price, true, sold));
        }
        return new MerchantMenu(id, inventory, type == null ? MerchantType.BLOATED : type, null, 0L, offers, true);
    }

    public static void writeOpenData(FriendlyByteBuf buf, MerchantType type, List<Offer> offers) {
        buf.writeUtf(type.id());
        buf.writeVarInt(offers.size());
        for (Offer offer : offers) {
            buf.writeResourceLocation(offer.good());
            buf.writeVarInt(offer.price());
            buf.writeBoolean(offer.isSold());
        }
    }

    public MerchantType getMerchantType() {
        return type;
    }

    public List<Offer> getOffers() {
        return offers;
    }

    /** Баланс передаётся через DataSlot (короткое число), поэтому показывается не больше 32767. */
    public int getBalance() {
        return balance.get();
    }

    public void applySoldMask(int mask) {
        for (int i = 0; i < offers.size(); i++) {
            offers.get(i).setSold((mask & (1 << i)) != 0);
        }
    }

    private int soldMask() {
        int mask = 0;
        for (int i = 0; i < offers.size(); i++) {
            if (offers.get(i).isSold()) {
                mask |= 1 << i;
            }
        }
        return mask;
    }

    private void refreshBalance() {
        if (merchantUuid != null && player instanceof ServerPlayer serverPlayer) {
            long value = CurrencyAccess.get().getBalance(serverPlayer);
            balance.set((int) Math.min(value, Short.MAX_VALUE));
        }
    }

    @Override
    public void broadcastChanges() {
        refreshBalance();
        super.broadcastChanges();
    }

    /** Проверяется сервером каждый тик: окно закроется само, если игрок ушёл, умер или торговец пропал. */
    @Override
    public boolean stillValid(Player player) {
        if (merchantUuid == null) {
            return true;
        }
        if (!(player instanceof ServerPlayer serverPlayer) || !serverPlayer.isAlive()) {
            return false;
        }
        if (!(serverPlayer.level() instanceof ServerLevel level) || !ModDimensions.isMarket(level)) {
            return false;
        }
        Entity merchant = level.getEntity(merchantUuid);
        if (merchant == null || merchant.isRemoved()) {
            return false;
        }
        double max = GhostMarketConfig.TRADE_DISTANCE.get();
        return serverPlayer.distanceToSqr(merchant) <= max * max;
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        return ItemStack.EMPTY;
    }

    // ---------------------------------------------------------------- покупка

    /** Вызывается только на сервере. Все проверки и вся логика здесь. */
    public void tryBuy(ServerPlayer buyer, int index) {
        if (merchantUuid == null || processing) {
            return;
        }
        processing = true;
        try {
            buy(buyer, index);
        } finally {
            processing = false;
        }
    }

    private void buy(ServerPlayer buyer, int index) {
        if (buyer != player || buyer.containerMenu != this || !stillValid(buyer)) {
            fail(buyer, "message.ghostmarket.trade_far");
            return;
        }
        if (TradeData.currentVisitId(buyer) != visitId) {
            buyer.closeContainer();
            fail(buyer, "message.ghostmarket.trade_unavailable");
            return;
        }
        long now = buyer.level().getGameTime();
        if (now - lastBuyTick < GhostMarketConfig.TRADE_PURCHASE_COOLDOWN_TICKS.get()) {
            return;
        }
        if (index < 0 || index >= offers.size()) {
            return;
        }

        Offer offer = offers.get(index);
        if (offer.isSold()) {
            fail(buyer, "message.ghostmarket.trade_sold");
            sendState(buyer);
            return;
        }
        Good good = GoodRegistry.get(offer.good());
        if (good == null) {
            fail(buyer, "message.ghostmarket.trade_unavailable");
            return;
        }
        if (!good.canGive(buyer)) {
            fail(buyer, "message.ghostmarket.trade_no_space");
            return;
        }

        CurrencyAccess currency = CurrencyAccess.get();
        long price = offer.price();
        if (currency.getBalance(buyer) < price) {
            fail(buyer, "message.ghostmarket.trade_no_funds");
            return;
        }

        long taken = currency.withdraw(buyer, price);
        if (taken != price) {
            currency.deposit(buyer, taken);
            fail(buyer, "message.ghostmarket.trade_failed");
            return;
        }

        boolean given;
        try {
            given = good.give(buyer);
        } catch (RuntimeException e) {
            GhostMarket.LOGGER.error("Не удалось выдать товар {}", offer.good(), e);
            given = false;
        }
        if (!given) {
            currency.deposit(buyer, price);
            fail(buyer, "message.ghostmarket.trade_failed");
            return;
        }

        if (offer.isSingleUse()) {
            offer.setSold(true);
            TradeData.get(buyer.server).setDirty();
        }
        lastBuyTick = now;

        buyer.level().playSound(null, buyer.getX(), buyer.getY(), buyer.getZ(), ModSounds.TRADE_BUY.get(),
                SoundSource.NEUTRAL,
                GhostMarketConfig.TRADE_SOUND_VOLUME.get().floatValue(),
                GhostMarketConfig.TRADE_SOUND_PITCH.get().floatValue());
        buyer.displayClientMessage(Component.translatable("message.ghostmarket.trade_bought",
                Component.translatable(offer.nameKey())), true);
        sendState(buyer);
        broadcastChanges();
    }

    private void fail(ServerPlayer buyer, String key) {
        buyer.displayClientMessage(Component.translatable(key), true);
    }

    private void sendState(ServerPlayer buyer) {
        GhostMarketNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> buyer),
                new OfferStatePacket(containerId, soldMask()));
    }
}

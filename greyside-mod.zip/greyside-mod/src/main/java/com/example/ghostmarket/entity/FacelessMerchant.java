package com.example.ghostmarket.entity;

import com.example.ghostmarket.trade.MerchantType;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

public class FacelessMerchant extends MerchantEntity {
    public FacelessMerchant(EntityType<FacelessMerchant> type, Level level) {
        super(type, level, MerchantType.FACELESS);
    }
}

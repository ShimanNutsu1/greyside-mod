package com.example.ghostmarket.client;

import com.example.ghostmarket.entity.MerchantEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

/** Один рендерер на все виды: модель выбирается по id вида (см. MerchantModel). */
public class MerchantRenderer extends GeoEntityRenderer<MerchantEntity> {

    public MerchantRenderer(EntityRendererProvider.Context context, float shadowRadius) {
        super(context, new MerchantModel());
        this.shadowRadius = shadowRadius;
    }
}

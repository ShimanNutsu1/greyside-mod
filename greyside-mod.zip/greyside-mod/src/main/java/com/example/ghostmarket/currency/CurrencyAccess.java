package com.example.ghostmarket.currency;

import net.minecraft.server.level.ServerPlayer;

/**
 * Единственная точка, через которую остальной код мода трогает баланс валюты «Последний вздох».
 * Сейчас валюта это предметы в инвентаре (InventoryCurrencyAccess). Когда появится хранилище
 * баланса (счёт у торговца, данные игрока), достаточно вызвать CurrencyAccess.set(...) с новой реализацией.
 */
public interface CurrencyAccess {

    /** Сколько единиц валюты сейчас у игрока. */
    long getBalance(ServerPlayer player);

    /**
     * Забирает до amount единиц валюты.
     *
     * @return сколько забрано на самом деле (не больше баланса)
     */
    long withdraw(ServerPlayer player, long amount);

    /** Возвращает игроку amount единиц валюты (для отката покупки). Что не влезло в инвентарь, падает под ноги. */
    long deposit(ServerPlayer player, long amount);

    static CurrencyAccess get() {
        return Holder.current;
    }

    static void set(CurrencyAccess access) {
        Holder.current = access;
    }

    final class Holder {
        private static volatile CurrencyAccess current = new InventoryCurrencyAccess();

        private Holder() {
        }
    }
}

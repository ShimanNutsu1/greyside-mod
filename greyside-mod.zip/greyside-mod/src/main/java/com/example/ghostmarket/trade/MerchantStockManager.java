package com.example.ghostmarket.trade;

import com.example.ghostmarket.GhostMarket;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimpleJsonResourceReloadListener;
import net.minecraft.util.GsonHelper;
import net.minecraft.util.profiling.ProfilerFiller;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * Читает ассортимент из data/ghostmarket/merchant_stock/<вид>.json (перезагружается командой /reload).
 *
 * Схема файла:
 * { "entries": [ { "good": "ghostmarket:rotten_gift", "price_min": 3, "price_max": 5,
 *                  "weight": 10, "always": true, "single_use": true } ] }
 * price_max (по умолчанию = price_min), weight (1), always (false), single_use (true) необязательны.
 */
public class MerchantStockManager extends SimpleJsonResourceReloadListener {
    private static final Gson GSON = new GsonBuilder().create();
    public static final MerchantStockManager INSTANCE = new MerchantStockManager();

    private volatile Map<MerchantType, List<StockEntry>> stock = new EnumMap<>(MerchantType.class);

    private MerchantStockManager() {
        super(GSON, "merchant_stock");
    }

    public List<StockEntry> get(MerchantType type) {
        return stock.getOrDefault(type, List.of());
    }

    @Override
    protected void apply(Map<ResourceLocation, JsonElement> files, ResourceManager manager, ProfilerFiller profiler) {
        Map<MerchantType, List<StockEntry>> loaded = new EnumMap<>(MerchantType.class);

        for (Map.Entry<ResourceLocation, JsonElement> file : files.entrySet()) {
            ResourceLocation fileId = file.getKey();
            MerchantType type = fileId.getNamespace().equals(GhostMarket.MODID) ? MerchantType.fromId(fileId.getPath()) : null;
            if (type == null) {
                GhostMarket.LOGGER.warn("Ассортимент {}: неизвестный вид торговца, файл пропущен.", fileId);
                continue;
            }
            List<StockEntry> entries = new ArrayList<>();
            try {
                JsonObject root = GsonHelper.convertToJsonObject(file.getValue(), "root");
                for (JsonElement element : GsonHelper.getAsJsonArray(root, "entries")) {
                    parseEntry(fileId, element, entries);
                }
            } catch (JsonParseException e) {
                GhostMarket.LOGGER.error("Ассортимент {}: ошибка разбора: {}", fileId, e.getMessage());
            }
            loaded.put(type, List.copyOf(entries));
        }

        stock = loaded;
        GhostMarket.LOGGER.info("Ассортимент торговцев загружен: {}", loaded.keySet());
    }

    private static void parseEntry(ResourceLocation fileId, JsonElement element, List<StockEntry> out) {
        try {
            JsonObject obj = GsonHelper.convertToJsonObject(element, "entry");
            ResourceLocation good = ResourceLocation.tryParse(GsonHelper.getAsString(obj, "good"));
            if (good == null || GoodRegistry.get(good) == null) {
                GhostMarket.LOGGER.warn("Ассортимент {}: неизвестный товар '{}', позиция пропущена.", fileId, good);
                return;
            }
            int min = Math.max(0, GsonHelper.getAsInt(obj, "price_min"));
            int max = Math.max(min, GsonHelper.getAsInt(obj, "price_max", min));
            int weight = Math.max(1, GsonHelper.getAsInt(obj, "weight", 1));
            out.add(new StockEntry(good, min, max, weight,
                    GsonHelper.getAsBoolean(obj, "always", false),
                    GsonHelper.getAsBoolean(obj, "single_use", true)));
        } catch (JsonParseException e) {
            GhostMarket.LOGGER.error("Ассортимент {}: плохая позиция: {}", fileId, e.getMessage());
        }
    }
}

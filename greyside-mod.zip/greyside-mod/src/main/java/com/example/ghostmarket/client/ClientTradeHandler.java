package com.example.ghostmarket.client;

import com.example.ghostmarket.trade.MerchantMenu;
import net.minecraft.client.Minecraft;

public final class ClientTradeHandler {

    public static void onOfferState(int containerId, int soldMask) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && mc.player.containerMenu instanceof MerchantMenu menu && menu.containerId == containerId) {
            menu.applySoldMask(soldMask);
        }
    }

    private ClientTradeHandler() {
    }
}

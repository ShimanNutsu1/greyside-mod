package com.example.ghostmarket.client;

import com.example.ghostmarket.GhostMarket;
import com.example.ghostmarket.config.GhostMarketConfig;
import com.example.ghostmarket.dimension.ModDimensions;
import com.example.ghostmarket.registry.ModSounds;
import com.mojang.blaze3d.shaders.FogShape;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.FogRenderer;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.material.FogType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.client.event.sound.PlaySoundEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = GhostMarket.MODID, value = Dist.CLIENT)
public final class ClientMarketEvents {

    /**
     * Туман рынка: дальность задаётся в конфиге. За время предупреждения перед закрытием
     * туман плавно сгущается до fogWarningNear / fogWarningFar. Слепота и тьма от эффектов остаются ванильными.
     */
    @SubscribeEvent
    public static void onRenderFog(ViewportEvent.RenderFog event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || !ModDimensions.isMarket(mc.level) || !GhostMarketConfig.SPEC.isLoaded()) {
            return;
        }
        if (event.getMode() != FogRenderer.FogMode.FOG_TERRAIN) {
            return;
        }
        if (event.getCamera().getFluidInCamera() != FogType.NONE) {
            return;
        }
        Entity cameraEntity = event.getCamera().getEntity();
        if (cameraEntity instanceof LivingEntity living
                && (living.hasEffect(MobEffects.BLINDNESS) || living.hasEffect(MobEffects.DARKNESS))) {
            return;
        }

        float danger = ClientMarketTimer.warningProgress();
        float near = Mth.lerp(danger,
                GhostMarketConfig.FOG_NEAR.get().floatValue(),
                GhostMarketConfig.FOG_WARNING_NEAR.get().floatValue());
        float far = Mth.lerp(danger,
                GhostMarketConfig.FOG_FAR.get().floatValue(),
                GhostMarketConfig.FOG_WARNING_FAR.get().floatValue());
        far = Math.max(near + 1.0F, far);

        event.setNearPlaneDistance(near);
        event.setFarPlaneDistance(far);
        event.setFogShape(FogShape.SPHERE);
        event.setCanceled(true);
    }

    /** Выключатель музыки рынка из конфига. */
    @SubscribeEvent
    public static void onPlaySound(PlaySoundEvent event) {
        SoundInstance sound = event.getSound();
        if (sound == null || !GhostMarketConfig.SPEC.isLoaded() || GhostMarketConfig.MUSIC_ENABLED.get()) {
            return;
        }
        if (sound.getLocation().equals(ModSounds.MARKET_MUSIC.getId())) {
            event.setSound(null);
        }
    }

    /** Таймер отсчитывается каждый клиентский тик, пока игра не стоит на паузе. */
    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase == TickEvent.Phase.END && !Minecraft.getInstance().isPaused()) {
            ClientMarketTimer.tick();
        }
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        ClientMarketTimer.reset();
    }

    private ClientMarketEvents() {
    }
}

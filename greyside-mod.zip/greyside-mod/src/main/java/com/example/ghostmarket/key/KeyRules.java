package com.example.ghostmarket.key;

import com.example.ghostmarket.config.GhostMarketConfig;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

public final class KeyRules {
    public static final String TAG_LAST_USED_NIGHT = "LastUsedNight";
    public static final long NEVER_USED = Long.MIN_VALUE;
    public static final long TICKS_PER_DAY = 24000L;
    public static final long TICKS_PER_MINUTE = 1200L;

    private static final TagKey<Block> WOODEN_FENCE_GATES =
            TagKey.create(Registries.BLOCK, new ResourceLocation("forge", "fence_gates/wooden"));

    public enum Status {
        SLEEPING,
        WHISPERING
    }

    /**
     * @param status       можно ли использовать ключ прямо сейчас
     * @param waitTicks    сколько тиков до ближайшего окна, когда ключ можно использовать (0, если можно сейчас)
     * @param nightsLeft   сколько ночей осталось отдыхать (0, если кулдаун не действует)
     * @param currentNight индекс текущей ночи (для записи в ключ при использовании)
     */
    public record State(Status status, long waitTicks, long nightsLeft, long currentNight) {
    }

    public static boolean isValidTarget(BlockState state) {
        if (state.is(BlockTags.WOODEN_DOORS)) {
            return true;
        }
        if (GhostMarketConfig.ALLOW_TRAPDOORS.get() && state.is(BlockTags.WOODEN_TRAPDOORS)) {
            return true;
        }
        return GhostMarketConfig.ALLOW_FENCE_GATES.get() && state.is(WOODEN_FENCE_GATES);
    }

    public static long getLastUsedNight(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        if (tag == null || !tag.contains(TAG_LAST_USED_NIGHT, Tag.TAG_LONG)) {
            return NEVER_USED;
        }
        return tag.getLong(TAG_LAST_USED_NIGHT);
    }

    public static State evaluate(long dayTime, long lastUsedNight) {
        long start = GhostMarketConfig.WINDOW_START_TICK.get();
        long end = GhostMarketConfig.WINDOW_END_TICK.get();
        long cooldown = GhostMarketConfig.COOLDOWN_NIGHTS.get();
        boolean wraps = start > end;

        long day = Math.floorDiv(dayTime, TICKS_PER_DAY);
        long timeOfDay = Math.floorMod(dayTime, TICKS_PER_DAY);

        boolean inWindow;
        long currentNight = day;
        if (!wraps) {
            inWindow = timeOfDay >= start && timeOfDay <= end;
        } else if (timeOfDay >= start) {
            inWindow = true;
        } else if (timeOfDay <= end) {
            inWindow = true;
            currentNight = day - 1;
        } else {
            inWindow = false;
        }

        // Если время откатили командой /time set, отсчёт кулдауна идёт от текущей ночи.
        long last = lastUsedNight;
        if (last != NEVER_USED && last > currentNight) {
            last = currentNight;
        }
        long earliestNight = (last == NEVER_USED) ? Long.MIN_VALUE : last + cooldown;

        if (inWindow && currentNight >= earliestNight) {
            return new State(Status.WHISPERING, 0L, 0L, currentNight);
        }

        long night = Math.max(earliestNight, day - 1);
        while (night * TICKS_PER_DAY + start <= dayTime) {
            night++;
        }
        long waitTicks = night * TICKS_PER_DAY + start - dayTime;

        boolean onCooldown = last != NEVER_USED && earliestNight > currentNight;
        long nightsLeft = onCooldown ? night - currentNight : 0L;

        return new State(Status.SLEEPING, waitTicks, nightsLeft, currentNight);
    }

    private KeyRules() {
    }
}

package com.example.ghostmarket.registry;

import com.example.ghostmarket.GhostMarket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.List;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUND_EVENTS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, GhostMarket.MODID);

    public static final RegistryObject<SoundEvent> KEY_DOOR_OPEN = register("key_door_open");
    public static final RegistryObject<SoundEvent> LAST_BREATH_PICKUP = register("last_breath_pickup");
    public static final RegistryObject<SoundEvent> PET_DEATH_DOG = register("pet_death_dog");
    public static final RegistryObject<SoundEvent> PET_DEATH_CAT = register("pet_death_cat");
    public static final RegistryObject<SoundEvent> PET_DEATH_GENERIC = register("pet_death_generic");
    /** Мерзкий звук покупки у торговца (Этап 4Б). */
    public static final RegistryObject<SoundEvent> TRADE_BUY = register("trade_buy");

    // ===== Этап 2А: Рынок призраков =====
    /** Фоновая петля биома рынка (подключена в биоме, настройки громкости у ванильного звука). */
    public static final RegistryObject<SoundEvent> MARKET_LOOP = register("market_loop");
    /** Музыка биома рынка (подключена в биоме). */
    public static final RegistryObject<SoundEvent> MARKET_MUSIC = register("market_music");
    /** Шёпот. Пригодится в Этапе 2Б для предупреждения за минуту до конца. */
    public static final RegistryObject<SoundEvent> MARKET_WHISPER = register("market_whisper");
    public static final RegistryObject<SoundEvent> MARKET_CREAK = register("market_creak");
    public static final RegistryObject<SoundEvent> MARKET_WAIL = register("market_wail");
    public static final RegistryObject<SoundEvent> MARKET_CHAINS = register("market_chains");

    /** Звуки, которые случайно звучат вокруг игрока на рынке (см. MarketAmbienceEvents). */
    public static final List<RegistryObject<SoundEvent>> MARKET_ONE_SHOTS =
            List.of(MARKET_WHISPER, MARKET_CREAK, MARKET_WAIL, MARKET_CHAINS);

    // ===== Этап 4А: торговцы =====
    /** Влажное бормотание: фоновый звук торговцев. */
    public static final RegistryObject<SoundEvent> MERCHANT_MURMUR = register("merchant_murmur");
    /** Хруст: редкий фоновый звук торговцев. */
    public static final RegistryObject<SoundEvent> MERCHANT_CRUNCH = register("merchant_crunch");
    /** Шёпот цен: отклик на ПКМ по торговцу. */
    public static final RegistryObject<SoundEvent> MERCHANT_WHISPER = register("merchant_whisper");

    private static RegistryObject<SoundEvent> register(String name) {
        return SOUND_EVENTS.register(name,
                () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(GhostMarket.MODID, name)));
    }

    public static void register(IEventBus modBus) {
        SOUND_EVENTS.register(modBus);
    }

    private ModSounds() {
    }
}

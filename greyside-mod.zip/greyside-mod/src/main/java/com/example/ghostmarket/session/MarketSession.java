package com.example.ghostmarket.session;

import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;

/**
 * Один сеанс игрока на рынке: куда вернуть и когда рынок закроется.
 * Конец сеанса задан двумя часами сразу: временем суток главного мира (рассвет)
 * и игровыми тиками (страховка, если цикл дня выключен или время откатили командой).
 */
public final class MarketSession {
    private final ResourceKey<Level> returnDimension;
    private final double x;
    private final double y;
    private final double z;
    private final float yaw;
    private final float pitch;
    private final long endDayTime;
    private final long limitGameTime;
    private boolean warned;

    public MarketSession(ResourceKey<Level> returnDimension, double x, double y, double z, float yaw, float pitch,
                         long endDayTime, long limitGameTime) {
        this.returnDimension = returnDimension;
        this.x = x;
        this.y = y;
        this.z = z;
        this.yaw = yaw;
        this.pitch = pitch;
        this.endDayTime = endDayTime;
        this.limitGameTime = limitGameTime;
    }

    public ResourceKey<Level> returnDimension() {
        return returnDimension;
    }

    public double x() {
        return x;
    }

    public double y() {
        return y;
    }

    public double z() {
        return z;
    }

    public float yaw() {
        return yaw;
    }

    public float pitch() {
        return pitch;
    }

    /** Идентификатор визита: у каждого входа на рынок свой (по нему торговцы перебрасывают ассортимент). */
    public long visitId() {
        return limitGameTime;
    }

    public boolean isWarned() {
        return warned;
    }

    public void setWarned(boolean warned) {
        this.warned = warned;
    }

    /** Сколько тиков осталось. Меньше или равно нулю: рынок закрыт. */
    public long remaining(long overworldDayTime, long overworldGameTime) {
        return Math.min(endDayTime - overworldDayTime, limitGameTime - overworldGameTime);
    }

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        tag.putString("Dim", returnDimension.location().toString());
        tag.putDouble("X", x);
        tag.putDouble("Y", y);
        tag.putDouble("Z", z);
        tag.putFloat("Yaw", yaw);
        tag.putFloat("Pitch", pitch);
        tag.putLong("EndDay", endDayTime);
        tag.putLong("LimitGame", limitGameTime);
        tag.putBoolean("Warned", warned);
        return tag;
    }

    public static MarketSession load(CompoundTag tag) {
        ResourceLocation id = ResourceLocation.tryParse(tag.getString("Dim"));
        if (id == null) {
            id = new ResourceLocation("minecraft", "overworld");
        }
        MarketSession session = new MarketSession(
                ResourceKey.create(Registries.DIMENSION, id),
                tag.getDouble("X"), tag.getDouble("Y"), tag.getDouble("Z"),
                tag.getFloat("Yaw"), tag.getFloat("Pitch"),
                tag.getLong("EndDay"), tag.getLong("LimitGame"));
        session.warned = tag.getBoolean("Warned");
        return session;
    }
}

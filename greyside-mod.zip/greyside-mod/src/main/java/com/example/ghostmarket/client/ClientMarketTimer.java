package com.example.ghostmarket.client;

import com.example.ghostmarket.config.GhostMarketConfig;

/** Клиентская копия таймера рынка: сервер присылает остаток, между пакетами клиент отсчитывает сам. */
public final class ClientMarketTimer {
    private static boolean active;
    private static int remainingTicks;

    public static void sync(boolean isActive, int remaining) {
        active = isActive;
        remainingTicks = isActive ? Math.max(0, remaining) : 0;
    }

    public static void tick() {
        if (active && remainingTicks > 0) {
            remainingTicks--;
        }
    }

    public static void reset() {
        active = false;
        remainingTicks = 0;
    }

    public static boolean isActive() {
        return active;
    }

    public static int getRemainingTicks() {
        return remainingTicks;
    }

    /** 0.0 пока до конца далеко, плавно растёт до 1.0 за время предупреждения. */
    public static float warningProgress() {
        if (!active || !GhostMarketConfig.SPEC.isLoaded()) {
            return 0.0F;
        }
        int warning = GhostMarketConfig.WARNING_TICKS.get();
        if (warning <= 0 || remainingTicks >= warning) {
            return 0.0F;
        }
        return 1.0F - remainingTicks / (float) warning;
    }

    private ClientMarketTimer() {
    }
}

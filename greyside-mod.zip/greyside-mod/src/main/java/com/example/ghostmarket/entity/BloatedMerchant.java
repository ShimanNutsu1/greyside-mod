package com.example.ghostmarket.entity;

import com.example.ghostmarket.trade.MerchantType;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

public class BloatedMerchant extends MerchantEntity {
    public BloatedMerchant(EntityType<BloatedMerchant> type, Level level) {
        super(type, level, MerchantType.BLOATED);
    }
}

package com.example.ghostmarket.dimension;

import com.example.ghostmarket.GhostMarket;
import com.example.ghostmarket.config.GhostMarketConfig;
import com.example.ghostmarket.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CandleBlock;
import net.minecraft.world.level.block.LanternBlock;
import net.minecraft.world.level.block.SkullBlock;
import net.minecraft.world.level.block.SlabBlock;
import net.minecraft.world.level.block.WallTorchBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.SlabType;
import net.minecraft.world.level.levelgen.structure.BoundingBox;

/**
 * Процедурная платформа рынка: квадратная площадь, стены, лавки, цепи с фонарями,
 * портал-арка на помосте и отметка точки появления.
 *
 * ПЛАН ЗАМЕНЫ НА СТРУКТУРУ (nbt): см. описание в ответе к этапу. Вся постройка собрана в одном
 * методе build(), его тело заменяется на StructureTemplate.placeInWorld без изменений в остальном коде.
 */
public final class MarketPlatformBuilder {
    /** 2 = отправить клиентам, 16 = не пересчитывать формы соседей (чтобы не ломать вручную заданные состояния). */
    private static final int FLAGS = Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE;

    // Декоративная раскладка. Это не игровой баланс, а геометрия постройки.
    private static final int[] TORCH_X = {-8, -4, 0, 4, 8};
    private static final int[] CHAIN_LINE_Z = {-3, 3};
    private static final int[] LAMP_X = {-6, -3, 0, 3, 6};

    public static void ensureBuilt(ServerLevel level) {
        if (!GhostMarketConfig.SPEC.isLoaded()) {
            GhostMarket.LOGGER.warn("Конфиг ещё не загружен, платформа рынка не построена.");
            return;
        }

        MarketLayout layout = MarketLayout.fromConfig();
        MarketSavedData data = MarketSavedData.get(level);
        if (data.isBuilt() && data.getSignature() == layout.signature()) {
            return;
        }

        BoundingBox previous = data.getLastBox();
        if (data.isBuilt() && previous != null) {
            clear(level, previous);
        }
        BoundingBox bounds = layout.buildBounds();
        clear(level, bounds);

        build(level, layout);

        data.markBuilt(layout.signature(), bounds);
        GhostMarket.LOGGER.info("Платформа рынка призраков построена: центр {}, арка {}, точка появления {}.",
                layout.center().toShortString(), layout.arch().toShortString(), layout.spawn().toShortString());
    }

    private static void clear(ServerLevel level, BoundingBox box) {
        BlockState air = Blocks.AIR.defaultBlockState();
        for (BlockPos pos : BlockPos.betweenClosed(box.minX(), box.minY(), box.minZ(), box.maxX(), box.maxY(), box.maxZ())) {
            if (!level.getBlockState(pos).isAir()) {
                level.setBlock(pos, air, FLAGS);
            }
        }
    }

    private static void build(ServerLevel level, MarketLayout l) {
        buildFloor(level, l);
        buildWalls(level, l);
        buildTorches(level, l);
        for (int side = -1; side <= 1; side += 2) {
            for (int i = 0; i < MarketLayout.STALL_Z.length; i++) {
                buildStall(level, l, side, MarketLayout.STALL_Z[i], Math.floorMod(i + (side > 0 ? 1 : 0), 3));
            }
        }
        buildHangingLanterns(level, l);
        buildArch(level, l);
    }

    // ------------------------------------------------------------------ пол

    private static void buildFloor(ServerLevel level, MarketLayout l) {
        int cx = l.center().getX();
        int fy = l.center().getY();
        int cz = l.center().getZ();
        for (int dx = -l.half(); dx <= l.half(); dx++) {
            for (int dz = -l.half(); dz <= l.half(); dz++) {
                set(level, cx + dx, fy, cz + dz, floorBlock(l, dx, dz));
                set(level, cx + dx, fy - 1, cz + dz,
                        ((dx + dz) & 1) == 0 ? Blocks.DEEPSLATE_BRICKS.defaultBlockState()
                                : Blocks.DEEPSLATE_TILES.defaultBlockState());
            }
        }
    }

    private static BlockState floorBlock(MarketLayout l, int dx, int dz) {
        // Отметка точки появления игрока: 3x3 тёмной земли душ.
        if (Math.abs(dx - l.spawnDx()) <= 1 && Math.abs(dz - l.spawnDz()) <= 1) {
            return Blocks.SOUL_SOIL.defaultBlockState();
        }

        // Помост под портал-арку Этапа 2Б.
        int ax = dx - l.archDx();
        int az = dz - l.archDz();
        if (Math.abs(ax) <= MarketLayout.ARCH_HALF_WIDTH && Math.abs(az) <= MarketLayout.ARCH_HALF_DEPTH) {
            boolean corner = Math.abs(ax) == MarketLayout.ARCH_HALF_WIDTH && Math.abs(az) == MarketLayout.ARCH_HALF_DEPTH;
            return corner ? Blocks.CRYING_OBSIDIAN.defaultBlockState() : Blocks.POLISHED_BLACKSTONE.defaultBlockState();
        }

        // Дорожка от помоста к точке появления.
        if (Math.abs(ax) <= 1 && dz > l.archDz() + MarketLayout.ARCH_HALF_DEPTH && dz < l.spawnDz() - 1) {
            return Blocks.POLISHED_DEEPSLATE.defaultBlockState();
        }

        int h = Math.floorMod((dx * 73856093) ^ (dz * 19349663), 11);
        if (h == 0) {
            return Blocks.CRACKED_POLISHED_BLACKSTONE_BRICKS.defaultBlockState();
        }
        if (h <= 2) {
            return Blocks.BLACKSTONE.defaultBlockState();
        }
        return Blocks.POLISHED_BLACKSTONE_BRICKS.defaultBlockState();
    }

    // ---------------------------------------------------------------- стены

    private static void buildWalls(ServerLevel level, MarketLayout l) {
        int cx = l.center().getX();
        int fy = l.center().getY();
        int cz = l.center().getZ();
        int half = l.half();
        int wh = l.wallHeight();

        for (int dx = -half; dx <= half; dx++) {
            for (int dz = -half; dz <= half; dz++) {
                if (Math.max(Math.abs(dx), Math.abs(dz)) != half) {
                    continue;
                }
                boolean corner = Math.abs(dx) == half && Math.abs(dz) == half;
                int top = corner ? wh + 2 : wh;
                for (int y = 1; y <= top; y++) {
                    BlockState state;
                    if (corner) {
                        state = Blocks.POLISHED_BLACKSTONE_BRICKS.defaultBlockState();
                    } else if (Math.floorMod((dx * 31) ^ (dz * 17) ^ (y * 13), 7) == 0) {
                        state = Blocks.CRACKED_DEEPSLATE_BRICKS.defaultBlockState();
                    } else {
                        state = Blocks.DEEPSLATE_BRICKS.defaultBlockState();
                    }
                    set(level, cx + dx, fy + y, cz + dz, state);
                }
                if (corner) {
                    set(level, cx + dx, fy + wh + 3, cz + dz, soulLantern(false));
                }
            }
        }
    }

    private static void buildTorches(ServerLevel level, MarketLayout l) {
        int cx = l.center().getX();
        int fy = l.center().getY();
        int cz = l.center().getZ();
        int half = l.half();

        for (int tx : TORCH_X) {
            // Южная стена: факел смотрит на север.
            set(level, cx + tx, fy + 3, cz + half - 1, soulWallTorch(Direction.NORTH));
            // Северная стена: факел смотрит на юг, но не рядом с аркой.
            if (Math.abs(tx - l.archDx()) > MarketLayout.ARCH_HALF_WIDTH) {
                set(level, cx + tx, fy + 3, cz - half + 1, soulWallTorch(Direction.SOUTH));
            }
        }
    }

    // ---------------------------------------------------------------- лавки

    /**
     * @param side    -1 западная стена, +1 восточная
     * @param zc      смещение центра лавки по Z от центра площади
     * @param variant 0 череп, 1 цветок-в-горшке, 2 свечи
     */
    private static void buildStall(ServerLevel level, MarketLayout l, int side, int zc, int variant) {
        int cx = l.center().getX();
        int fy = l.center().getY();
        int cz = l.center().getZ();
        int half = l.half();

        int frontX = side * (half - 3);
        int midX = side * (half - MarketLayout.STALL_SELLER_INSET);
        int backX = side * (half - 1);

        BlockState fence = Blocks.DARK_OAK_FENCE.defaultBlockState();
        for (int y = 1; y <= 3; y++) {
            for (int dz = zc - 1; dz <= zc + 1; dz += 2) {
                set(level, cx + frontX, fy + y, cz + dz, fence);
                set(level, cx + backX, fy + y, cz + dz, fence);
            }
        }

        // Прилавок и то, что на нём лежит.
        set(level, cx + frontX, fy + 1, cz + zc, Blocks.DARK_OAK_PLANKS.defaultBlockState());
        BlockState decor = switch (variant) {
            case 0 -> Blocks.SKELETON_SKULL.defaultBlockState().setValue(SkullBlock.ROTATION, side > 0 ? 4 : 12);
            case 1 -> Blocks.POTTED_WITHER_ROSE.defaultBlockState();
            default -> Blocks.BLACK_CANDLE.defaultBlockState().setValue(CandleBlock.CANDLES, 3);
        };
        set(level, cx + frontX, fy + 2, cz + zc, decor);

        // Крыша из перевёрнутых плит.
        BlockState roof = Blocks.DARK_OAK_SLAB.defaultBlockState().setValue(SlabBlock.TYPE, SlabType.TOP);
        for (int x : new int[]{frontX, midX, backX}) {
            for (int dz = zc - 1; dz <= zc + 1; dz++) {
                set(level, cx + x, fy + 4, cz + dz, roof);
            }
        }

        // Подвешенный фонарь над местом продавца и паутина в углах.
        set(level, cx + midX, fy + 3, cz + zc, soulLantern(true));
        set(level, cx + midX, fy + 3, cz + zc - 1, Blocks.COBWEB.defaultBlockState());
        set(level, cx + midX, fy + 3, cz + zc + 1, Blocks.COBWEB.defaultBlockState());
    }

    // ------------------------------------------------------ подвесные фонари

    private static void buildHangingLanterns(ServerLevel level, MarketLayout l) {
        int cx = l.center().getX();
        int fy = l.center().getY();
        int cz = l.center().getZ();
        int half = l.half();
        int wh = l.wallHeight();

        BlockState chainAlongX = Blocks.CHAIN.defaultBlockState().setValue(BlockStateProperties.AXIS, Direction.Axis.X);
        BlockState chainVertical = Blocks.CHAIN.defaultBlockState();

        for (int lineZ : CHAIN_LINE_Z) {
            for (int dx = -(half - 1); dx <= half - 1; dx++) {
                set(level, cx + dx, fy + wh, cz + lineZ, chainAlongX);
            }
            for (int i = 0; i < LAMP_X.length; i++) {
                int lanternY = fy + (i % 2 == 0 ? 4 : 3);
                for (int y = fy + wh - 1; y > lanternY; y--) {
                    set(level, cx + LAMP_X[i], y, cz + lineZ, chainVertical);
                }
                set(level, cx + LAMP_X[i], lanternY, cz + lineZ, soulLantern(true));
            }
        }
    }

    // ------------------------------------------------------- портал-арка

    /**
     * Портал-арка Этапа 2Б в объёме MarketLayout.archReservedBox(): две колонны, перемычка и полотно
     * ArchPortalBlock в проёме. Проход по X от -1 до +1, высота 4. Игрок, вошедший в полотно, покидает рынок.
     */
    private static void buildArch(ServerLevel level, MarketLayout l) {
        int ax = l.arch().getX();
        int fy = l.arch().getY();
        int az = l.arch().getZ();

        for (int y = 1; y <= 4; y++) {
            set(level, ax - 2, fy + y, az, Blocks.CHISELED_POLISHED_BLACKSTONE.defaultBlockState());
            set(level, ax + 2, fy + y, az, Blocks.CHISELED_POLISHED_BLACKSTONE.defaultBlockState());
        }
        for (int dx = -2; dx <= 2; dx++) {
            set(level, ax + dx, fy + 5, az,
                    dx == 0 ? Blocks.GILDED_BLACKSTONE.defaultBlockState()
                            : Blocks.POLISHED_BLACKSTONE_BRICKS.defaultBlockState());
        }

        BlockState portal = ModBlocks.ARCH_PORTAL.get().defaultBlockState();
        for (int dx = -1; dx <= 1; dx++) {
            for (int y = 1; y <= 4; y++) {
                set(level, ax + dx, fy + y, az, portal);
            }
        }
    }

    // ---------------------------------------------------------- помощники

    private static BlockState soulLantern(boolean hanging) {
        return Blocks.SOUL_LANTERN.defaultBlockState().setValue(LanternBlock.HANGING, hanging);
    }

    private static BlockState soulWallTorch(Direction facing) {
        return Blocks.SOUL_WALL_TORCH.defaultBlockState().setValue(WallTorchBlock.FACING, facing);
    }

    private static void set(ServerLevel level, int x, int y, int z, BlockState state) {
        level.setBlock(new BlockPos(x, y, z), state, FLAGS);
    }

    private MarketPlatformBuilder() {
    }
}

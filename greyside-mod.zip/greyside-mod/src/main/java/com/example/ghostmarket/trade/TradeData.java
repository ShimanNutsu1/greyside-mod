package com.example.ghostmarket.trade;

import com.example.ghostmarket.config.GhostMarketConfig;
import com.example.ghostmarket.session.MarketSession;
import com.example.ghostmarket.session.MarketSessionData;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Ассортимент игрока на время одного визита (сеанса из Этапа 2Б). Хранится на сервере и переживает перезаход.
 * Новый визит (другой visitId) сбрасывает набор, и он перебрасывается заново при первом открытии окна.
 */
public class TradeData extends SavedData {
    public static final long NO_VISIT = Long.MIN_VALUE;
    private static final String NAME = "ghostmarket_trade";

    private static final class PlayerStock {
        long visitId;
        final Map<MerchantType, List<Offer>> offers = new EnumMap<>(MerchantType.class);
    }

    private final Map<UUID, PlayerStock> players = new HashMap<>();

    public static TradeData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(TradeData::load, TradeData::new, NAME);
    }

    /** Идентификатор текущего визита игрока или NO_VISIT, если сеанса на рынке нет. */
    public static long currentVisitId(ServerPlayer player) {
        MarketSession session = MarketSessionData.get(player.server).getSession(player.getUUID());
        return session == null ? NO_VISIT : session.visitId();
    }

    /** Набор позиций торговца для этого визита. Живые объекты: изменение Offer.sold сохраняется через setDirty(). */
    public List<Offer> getOffers(UUID player, MerchantType type, long visitId, RandomSource random) {
        PlayerStock stock = players.get(player);
        if (stock == null || stock.visitId != visitId) {
            stock = new PlayerStock();
            stock.visitId = visitId;
            players.put(player, stock);
            setDirty();
        }
        List<Offer> offers = stock.offers.get(type);
        if (offers == null) {
            offers = roll(type, random);
            stock.offers.put(type, offers);
            setDirty();
        }
        return offers;
    }

    /** Часть позиций (1 - randomShare) берётся из «всегда в наличии», остальные выбираются по весам. */
    private static List<Offer> roll(MerchantType type, RandomSource random) {
        List<StockEntry> pool = new ArrayList<>(MerchantStockManager.INSTANCE.get(type));
        int slots = GhostMarketConfig.TRADE_SLOTS.get();
        int randomCount = Mth.clamp(Math.round((float) (slots * GhostMarketConfig.TRADE_RANDOM_SHARE.get())), 0, slots);
        int fixedCount = slots - randomCount;

        List<StockEntry> chosen = new ArrayList<>();
        for (StockEntry entry : List.copyOf(pool)) {
            if (chosen.size() >= fixedCount) {
                break;
            }
            if (entry.always()) {
                chosen.add(entry);
                pool.remove(entry);
            }
        }
        while (chosen.size() < slots && !pool.isEmpty()) {
            int total = 0;
            for (StockEntry entry : pool) {
                total += entry.weight();
            }
            int roll = random.nextInt(total);
            for (StockEntry entry : pool) {
                roll -= entry.weight();
                if (roll < 0) {
                    chosen.add(entry);
                    pool.remove(entry);
                    break;
                }
            }
        }

        List<Offer> offers = new ArrayList<>();
        for (StockEntry entry : chosen) {
            int price = entry.priceMin() + random.nextInt(entry.priceMax() - entry.priceMin() + 1);
            offers.add(new Offer(entry.good(), price, entry.singleUse(), false));
        }
        return offers;
    }

    public static TradeData load(CompoundTag tag) {
        TradeData data = new TradeData();
        ListTag list = tag.getList("Players", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag p = list.getCompound(i);
            if (!p.hasUUID("Player")) {
                continue;
            }
            PlayerStock stock = new PlayerStock();
            stock.visitId = p.getLong("Visit");
            ListTag types = p.getList("Types", Tag.TAG_COMPOUND);
            for (int t = 0; t < types.size(); t++) {
                CompoundTag typeTag = types.getCompound(t);
                MerchantType type = MerchantType.fromId(typeTag.getString("Type"));
                if (type == null) {
                    continue;
                }
                List<Offer> offers = new ArrayList<>();
                ListTag offerList = typeTag.getList("Offers", Tag.TAG_COMPOUND);
                for (int o = 0; o < offerList.size(); o++) {
                    CompoundTag ot = offerList.getCompound(o);
                    ResourceLocation good = ResourceLocation.tryParse(ot.getString("Good"));
                    if (good != null) {
                        offers.add(new Offer(good, ot.getInt("Price"), ot.getBoolean("SingleUse"), ot.getBoolean("Sold")));
                    }
                }
                stock.offers.put(type, offers);
            }
            data.players.put(p.getUUID("Player"), stock);
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (Map.Entry<UUID, PlayerStock> e : players.entrySet()) {
            CompoundTag p = new CompoundTag();
            p.putUUID("Player", e.getKey());
            p.putLong("Visit", e.getValue().visitId);
            ListTag types = new ListTag();
            for (Map.Entry<MerchantType, List<Offer>> te : e.getValue().offers.entrySet()) {
                CompoundTag typeTag = new CompoundTag();
                typeTag.putString("Type", te.getKey().id());
                ListTag offerList = new ListTag();
                for (Offer offer : te.getValue()) {
                    CompoundTag ot = new CompoundTag();
                    ot.putString("Good", offer.good().toString());
                    ot.putInt("Price", offer.price());
                    ot.putBoolean("SingleUse", offer.isSingleUse());
                    ot.putBoolean("Sold", offer.isSold());
                    offerList.add(ot);
                }
                typeTag.put("Offers", offerList);
                types.add(typeTag);
            }
            p.put("Types", types);
            list.add(p);
        }
        tag.put("Players", list);
        return tag;
    }
}

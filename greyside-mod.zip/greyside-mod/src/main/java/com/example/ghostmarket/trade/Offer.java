package com.example.ghostmarket.trade;

import net.minecraft.resources.ResourceLocation;

/** Одна позиция в окне торговца. Цена и товар заданы сервером при ротации и дальше не меняются. */
public final class Offer {
    private final ResourceLocation good;
    private final int price;
    private final boolean singleUse;
    private boolean sold;

    public Offer(ResourceLocation good, int price, boolean singleUse, boolean sold) {
        this.good = good;
        this.price = price;
        this.singleUse = singleUse;
        this.sold = sold;
    }

    public ResourceLocation good() {
        return good;
    }

    public int price() {
        return price;
    }

    public boolean isSingleUse() {
        return singleUse;
    }

    public boolean isSold() {
        return sold;
    }

    public void setSold(boolean sold) {
        this.sold = sold;
    }

    /** Ключ локализации названия товара. */
    public String nameKey() {
        return "good." + good.getNamespace() + "." + good.getPath();
    }
}

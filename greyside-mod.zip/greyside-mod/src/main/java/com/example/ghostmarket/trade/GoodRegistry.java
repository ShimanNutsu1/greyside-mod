package com.example.ghostmarket.trade;

import com.example.ghostmarket.GhostMarket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Items;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;

/** Реестр товаров. Сейчас здесь заглушки. Реальные способности регистрируй через register(...). */
public final class GoodRegistry {
    private static final Map<ResourceLocation, Good> GOODS = new HashMap<>();

    static {
        // общие
        register(new ItemGood(id("rotten_gift"), Items.ROTTEN_FLESH, 4));
        register(new ItemGood(id("bone_dust"), Items.BONE_MEAL, 8));
        register(new MessageGood(id("cold_whisper")));
        // Раздутый
        register(new MessageGood(id("swollen_womb")));
        register(new ItemGood(id("belly_bottle"), Items.GLASS_BOTTLE, 2));
        // Сшитый
        register(new ItemGood(id("stitch_thread"), Items.STRING, 6));
        register(new ItemGood(id("spare_eye"), Items.SPIDER_EYE, 2));
        // Безлицый
        register(new MessageGood(id("smooth_mask")));
        register(new ItemGood(id("silent_ink"), Items.INK_SAC, 3));
        // Висельник
        register(new ItemGood(id("hook_rope"), Items.LEAD, 2));
        register(new ItemGood(id("hanged_coin"), Items.GOLD_NUGGET, 5));
    }

    private static ResourceLocation id(String path) {
        return new ResourceLocation(GhostMarket.MODID, path);
    }

    public static void register(Good good) {
        GOODS.put(good.id(), good);
    }

    @Nullable
    public static Good get(ResourceLocation id) {
        return GOODS.get(id);
    }

    private GoodRegistry() {
    }
}

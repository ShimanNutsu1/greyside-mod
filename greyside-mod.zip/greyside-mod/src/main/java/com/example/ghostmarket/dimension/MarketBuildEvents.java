package com.example.ghostmarket.dimension;

import com.example.ghostmarket.GhostMarket;
import net.minecraft.server.level.ServerLevel;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = GhostMarket.MODID)
public final class MarketBuildEvents {

    @SubscribeEvent
    public static void onServerStarted(ServerStartedEvent event) {
        ServerLevel level = event.getServer().getLevel(ModDimensions.GHOST_MARKET);
        if (level == null) {
            GhostMarket.LOGGER.warn("Измерение {} не найдено, платформа рынка не построена. "
                    + "Проверь data/ghostmarket/dimension и dimension_type в jar мода.", ModDimensions.MARKET_ID);
            return;
        }
        MarketPlatformBuilder.ensureBuilt(level);
    }

    private MarketBuildEvents() {
    }
}

package com.example.ghostmarket.trade;

import com.example.ghostmarket.config.GhostMarketConfig;
import com.example.ghostmarket.dimension.ModDimensions;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.network.NetworkHooks;

import java.util.List;

/**
 * ТОЧКА ПОДКЛЮЧЕНИЯ К ТОРГОВЦУ ИЗ ЭТАПА 4А.
 * В обработчике ПКМ базового класса торговца (на сервере) вызови:
 *     MerchantTrade.open(serverPlayer, this, MerchantType.fromId(kindId));
 */
public final class MerchantTrade {

    public static void open(ServerPlayer player, Entity merchant, MerchantType type) {
        if (type == null || !GhostMarketConfig.SPEC.isLoaded()) {
            return;
        }
        if (!ModDimensions.isMarket(player.level()) || merchant.level() != player.level()) {
            return;
        }
        double max = GhostMarketConfig.TRADE_DISTANCE.get();
        if (player.distanceToSqr(merchant) > max * max || player.containerMenu != player.inventoryMenu) {
            return;
        }

        long visit = TradeData.currentVisitId(player);
        List<Offer> offers = visit == TradeData.NO_VISIT ? List.of()
                : TradeData.get(player.server).getOffers(player.getUUID(), type, visit, player.getRandom());
        if (offers.isEmpty()) {
            player.displayClientMessage(Component.translatable("message.ghostmarket.trade_unavailable"), true);
            return;
        }

        NetworkHooks.openScreen(player,
                new SimpleMenuProvider((id, inventory, p) ->
                        new MerchantMenu(id, inventory, type, merchant.getUUID(), visit, offers),
                        Component.translatable("merchant.ghostmarket." + type.id())),
                buf -> MerchantMenu.writeOpenData(buf, type, offers));
    }

    private MerchantTrade() {
    }
}

package com.example.ghostmarket.trade;

import com.example.ghostmarket.GhostMarket;
import net.minecraftforge.event.AddReloadListenerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = GhostMarket.MODID)
public final class TradeEvents {

    @SubscribeEvent
    public static void onAddReloadListeners(AddReloadListenerEvent event) {
        event.addListener(MerchantStockManager.INSTANCE);
    }

    private TradeEvents() {
    }
}

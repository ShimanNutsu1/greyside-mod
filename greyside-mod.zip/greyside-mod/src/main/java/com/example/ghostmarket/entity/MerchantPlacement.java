package com.example.ghostmarket.entity;

import com.example.ghostmarket.GhostMarket;
import com.example.ghostmarket.config.MerchantConfig;
import com.example.ghostmarket.dimension.MarketLayout;
import com.example.ghostmarket.registry.ModEntities;
import com.example.ghostmarket.trade.MerchantType;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Расстановка торговцев у лавок. Вся логика "что должно стоять" берётся из конфига и MarketLayout,
 * поэтому смена размера площади или количества торговцев подхватывается при следующем старте.
 *
 * Каждому автоматически расставленному торговцу записан ключ места ("bloated:0"). По нему:
 *  - недостающие места досоздаются;
 *  - второй торговец с тем же ключом (дубль) убирается;
 *  - торговец, чьего места больше нет (вид выключен, количество уменьшили), убирается;
 *  - торговец, чьё место сместилось (другой размер площади), переносится на новое.
 * Торговцы без ключа (созданные вручную через /summon) не трогаются.
 */
public final class MerchantPlacement {

    /** Одно место на рынке. */
    public record Slot(String key, MerchantType type, Vec3 pos, float yaw) {
    }

    /** Места, которые должны быть заняты согласно конфигу. */
    public static List<Slot> desiredSlots(MarketLayout layout) {
        List<MarketLayout.StallSpot> spots = layout.stallSpots();
        List<Slot> slots = new ArrayList<>();
        int next = 0;
        for (MerchantType type : MerchantType.values()) {
            if (!MerchantConfig.enabled(type)) {
                continue;
            }
            int count = MerchantConfig.count(type);
            for (int i = 0; i < count; i++) {
                if (next >= spots.size()) {
                    GhostMarket.LOGGER.warn("Торговцев в конфиге больше, чем лавок ({}). Вид '{}' №{} не создан.",
                            spots.size(), type.id(), i);
                    return slots;
                }
                MarketLayout.StallSpot spot = spots.get(next++);
                slots.add(new Slot(type.id() + ":" + i, type, spot.pos(), spot.yaw()));
            }
        }
        return slots;
    }

    /**
     * Проверяет и приводит торговцев в порядок.
     *
     * @return true, если все нужные места удалось проверить; false, если чанк какого-то места не загружен
     *         (тогда вызывающий повторит позже)
     */
    public static boolean ensure(ServerLevel level) {
        Map<String, Slot> wanted = new LinkedHashMap<>();
        for (Slot slot : desiredSlots(MarketLayout.fromConfig())) {
            wanted.put(slot.key(), slot);
        }

        Map<String, MerchantEntity> kept = new HashMap<>();
        List<MerchantEntity> surplus = new ArrayList<>();
        for (Entity entity : level.getAllEntities()) {
            if (!(entity instanceof MerchantEntity merchant) || merchant.isRemoved() || merchant.getSlotKey() == null) {
                continue;
            }
            String key = merchant.getSlotKey();
            if (!wanted.containsKey(key) || kept.containsKey(key)) {
                surplus.add(merchant);
            } else {
                kept.put(key, merchant);
            }
        }
        for (MerchantEntity merchant : surplus) {
            GhostMarket.LOGGER.info("Торговец {} ({}) лишний (дубль или место убрано в конфиге), удалён.",
                    merchant.getSlotKey(), merchant.getUUID());
            merchant.discard();
        }

        boolean complete = true;
        int created = 0;
        for (Slot slot : wanted.values()) {
            if (!level.hasChunkAt(BlockPos.containing(slot.pos()))) {
                complete = false;
                continue;
            }
            MerchantEntity existing = kept.get(slot.key());
            if (existing != null) {
                if (existing.position().distanceToSqr(slot.pos()) > 1.0E-4D) {
                    existing.placeAt(slot.key(), slot.pos(), slot.yaw());
                } else if (existing.getHome() == null) {
                    existing.rememberHome(slot.pos());
                }
                continue;
            }
            MerchantEntity fresh = ModEntities.typeOf(slot.type()).create(level);
            if (fresh == null) {
                GhostMarket.LOGGER.error("Не удалось создать торговца {}.", slot.key());
                continue;
            }
            fresh.placeAt(slot.key(), slot.pos(), slot.yaw());
            level.addFreshEntity(fresh);
            created++;
        }

        GhostMarket.LOGGER.info("Торговцы рынка: нужно мест {}, уже стояло {}, создано {}, лишних убрано {}.",
                wanted.size(), kept.size(), created, surplus.size());
        return complete;
    }

    private MerchantPlacement() {
    }
}

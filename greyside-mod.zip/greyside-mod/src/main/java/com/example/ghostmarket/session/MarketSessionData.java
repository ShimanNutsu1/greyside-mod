package com.example.ghostmarket.session;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.saveddata.SavedData;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Серверное хранилище мода в данных главного мира: активные сеансы на рынке и ключи,
 * ждущие возрождения игрока. Не зависит от копирования данных игрока при смерти
 * (поэтому и точка возврата, и ключ переживают смерть, выход из игры и перезапуск сервера).
 */
public class MarketSessionData extends SavedData {
    private static final String NAME = "ghostmarket_sessions";

    private final Map<UUID, MarketSession> sessions = new HashMap<>();
    private final Map<UUID, List<ItemStack>> pendingKeys = new HashMap<>();

    public static MarketSessionData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(MarketSessionData::load, MarketSessionData::new, NAME);
    }

    public static MarketSessionData load(CompoundTag tag) {
        MarketSessionData data = new MarketSessionData();

        ListTag sessionList = tag.getList("Sessions", Tag.TAG_COMPOUND);
        for (int i = 0; i < sessionList.size(); i++) {
            CompoundTag entry = sessionList.getCompound(i);
            if (entry.hasUUID("Player")) {
                data.sessions.put(entry.getUUID("Player"), MarketSession.load(entry.getCompound("Session")));
            }
        }

        ListTag keyList = tag.getList("PendingKeys", Tag.TAG_COMPOUND);
        for (int i = 0; i < keyList.size(); i++) {
            CompoundTag entry = keyList.getCompound(i);
            if (!entry.hasUUID("Player")) {
                continue;
            }
            ItemStack stack = ItemStack.of(entry.getCompound("Item"));
            if (!stack.isEmpty()) {
                data.pendingKeys.computeIfAbsent(entry.getUUID("Player"), id -> new ArrayList<>()).add(stack);
            }
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag sessionList = new ListTag();
        for (Map.Entry<UUID, MarketSession> e : sessions.entrySet()) {
            CompoundTag entry = new CompoundTag();
            entry.putUUID("Player", e.getKey());
            entry.put("Session", e.getValue().save());
            sessionList.add(entry);
        }
        tag.put("Sessions", sessionList);

        ListTag keyList = new ListTag();
        for (Map.Entry<UUID, List<ItemStack>> e : pendingKeys.entrySet()) {
            for (ItemStack stack : e.getValue()) {
                CompoundTag entry = new CompoundTag();
                entry.putUUID("Player", e.getKey());
                entry.put("Item", stack.save(new CompoundTag()));
                keyList.add(entry);
            }
        }
        tag.put("PendingKeys", keyList);
        return tag;
    }

    @Nullable
    public MarketSession getSession(UUID player) {
        return sessions.get(player);
    }

    public void putSession(UUID player, MarketSession session) {
        sessions.put(player, session);
        setDirty();
    }

    @Nullable
    public MarketSession removeSession(UUID player) {
        MarketSession removed = sessions.remove(player);
        if (removed != null) {
            setDirty();
        }
        return removed;
    }

    /** Копия, по которой можно спокойно ходить, пока сеансы добавляются и удаляются. */
    public Map<UUID, MarketSession> snapshot() {
        return new HashMap<>(sessions);
    }

    public void addPendingKey(UUID player, ItemStack key) {
        pendingKeys.computeIfAbsent(player, id -> new ArrayList<>()).add(key);
        setDirty();
    }

    public boolean hasPendingKeys(UUID player) {
        List<ItemStack> list = pendingKeys.get(player);
        return list != null && !list.isEmpty();
    }

    public List<ItemStack> takePendingKeys(UUID player) {
        List<ItemStack> list = pendingKeys.remove(player);
        if (list == null) {
            return List.of();
        }
        setDirty();
        return list;
    }
}

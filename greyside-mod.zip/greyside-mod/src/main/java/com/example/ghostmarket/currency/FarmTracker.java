package com.example.ghostmarket.currency;

import com.example.ghostmarket.config.GhostMarketConfig;
import com.example.ghostmarket.key.KeyRules;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Убывающая отдача для детёнышей и безобидных. Ключ: игрок + тип моба; внутри ключа
 * записи фильтруются по расстоянию, так что «одна зона» это круг радиуса zoneRadius вокруг убийства.
 * <p>
 * Ступени (n = число учтённых убийств в окне и зоне до текущего):
 * n &lt; Y: x1.0; n &lt; Y+S: stage1; n &lt; Y+2S: stage2; иначе 0 и блокировка зоны на lockoutMinutes.
 * <p>
 * Состояние хранится только в памяти и сбрасывается при остановке сервера и выходе игрока.
 * Все вызовы идут из серверного потока.
 */
public final class FarmTracker {

    private record Entry(long tick, ResourceKey<Level> dimension, double x, double z) {
    }

    private record Lock(long until, ResourceKey<Level> dimension, double x, double z) {
    }

    private static final Map<UUID, Map<ResourceLocation, List<Entry>>> ENTRIES = new HashMap<>();
    private static final Map<UUID, Map<ResourceLocation, List<Lock>>> LOCKS = new HashMap<>();

    /**
     * Регистрирует убийство и возвращает множитель награды (0.0 - 1.0).
     */
    public static double evaluate(UUID playerId, LivingEntity victim) {
        ResourceLocation typeId = ForgeRegistries.ENTITY_TYPES.getKey(victim.getType());
        if (typeId == null) {
            return 1.0D;
        }

        final Level level = victim.level();
        final long now = level.getGameTime();
        final ResourceKey<Level> dimension = level.dimension();
        final double x = victim.getX();
        final double z = victim.getZ();
        final long windowTicks = GhostMarketConfig.FARM_WINDOW_MINUTES.get() * KeyRules.TICKS_PER_MINUTE;
        final long lockoutTicks = GhostMarketConfig.FARM_LOCKOUT_MINUTES.get() * KeyRules.TICKS_PER_MINUTE;
        final double radius = GhostMarketConfig.FARM_ZONE_RADIUS.get();
        final double radiusSq = radius * radius;

        List<Lock> locks = LOCKS
                .computeIfAbsent(playerId, id -> new HashMap<>())
                .computeIfAbsent(typeId, id -> new ArrayList<>());
        locks.removeIf(lock -> lock.until() <= now);
        for (Lock lock : locks) {
            if (isNear(lock.dimension(), lock.x(), lock.z(), dimension, x, z, radiusSq)) {
                return 0.0D;
            }
        }

        List<Entry> entries = ENTRIES
                .computeIfAbsent(playerId, id -> new HashMap<>())
                .computeIfAbsent(typeId, id -> new ArrayList<>());
        entries.removeIf(entry -> entry.tick() > now || now - entry.tick() > windowTicks);

        int count = 0;
        for (Entry entry : entries) {
            if (isNear(entry.dimension(), entry.x(), entry.z(), dimension, x, z, radiusSq)) {
                count++;
            }
        }

        int fullKills = GhostMarketConfig.FARM_FULL_REWARD_KILLS.get();
        int stageLength = GhostMarketConfig.FARM_STAGE_LENGTH_KILLS.get();

        if (count >= fullKills + 2 * stageLength) {
            locks.add(new Lock(now + lockoutTicks, dimension, x, z));
            entries.removeIf(entry -> isNear(entry.dimension(), entry.x(), entry.z(), dimension, x, z, radiusSq));
            return 0.0D;
        }

        entries.add(new Entry(now, dimension, x, z));

        if (count < fullKills) {
            return 1.0D;
        }
        if (count < fullKills + stageLength) {
            return GhostMarketConfig.FARM_STAGE1_MULTIPLIER.get();
        }
        return GhostMarketConfig.FARM_STAGE2_MULTIPLIER.get();
    }

    private static boolean isNear(ResourceKey<Level> dimA, double xA, double zA,
                                  ResourceKey<Level> dimB, double xB, double zB, double radiusSq) {
        if (!dimA.equals(dimB)) {
            return false;
        }
        double dx = xA - xB;
        double dz = zA - zB;
        return dx * dx + dz * dz <= radiusSq;
    }

    public static void clearPlayer(UUID playerId) {
        ENTRIES.remove(playerId);
        LOCKS.remove(playerId);
    }

    public static void clearAll() {
        ENTRIES.clear();
        LOCKS.clear();
    }

    private FarmTracker() {
    }
}

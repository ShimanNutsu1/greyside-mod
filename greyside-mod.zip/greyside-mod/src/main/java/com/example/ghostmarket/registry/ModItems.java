package com.example.ghostmarket.registry;

import com.example.ghostmarket.GhostMarket;
import com.example.ghostmarket.item.LastBreathItem;
import com.example.ghostmarket.item.StrangeKeyItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, GhostMarket.MODID);

    public static final RegistryObject<Item> STRANGE_KEY = ITEMS.register("strange_key",
            () -> new StrangeKeyItem(new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));

    public static final RegistryObject<Item> LAST_BREATH = ITEMS.register("last_breath",
            () -> new LastBreathItem(new Item.Properties().stacksTo(64).rarity(Rarity.UNCOMMON)));

    public static void register(IEventBus modBus) {
        ITEMS.register(modBus);
    }

    private ModItems() {
    }
}

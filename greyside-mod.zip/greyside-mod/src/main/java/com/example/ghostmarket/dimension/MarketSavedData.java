package com.example.ghostmarket.dimension;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.saveddata.SavedData;
import org.jetbrains.annotations.Nullable;

/**
 * Хранится в данных самого измерения рынка. Помнит, какая раскладка платформы уже построена,
 * чтобы не строить заново при каждом запуске и перестроить при смене настроек.
 */
public class MarketSavedData extends SavedData {
    private static final String NAME = "ghostmarket_market";

    private boolean built;
    private int signature;
    private int[] box = new int[0];

    public static MarketSavedData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(MarketSavedData::load, MarketSavedData::new, NAME);
    }

    public static MarketSavedData load(CompoundTag tag) {
        MarketSavedData data = new MarketSavedData();
        data.built = tag.getBoolean("Built");
        data.signature = tag.getInt("Signature");
        data.box = tag.getIntArray("Box");
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putBoolean("Built", built);
        tag.putInt("Signature", signature);
        tag.putIntArray("Box", box);
        return tag;
    }

    public boolean isBuilt() {
        return built;
    }

    public int getSignature() {
        return signature;
    }

    /** Объём, который занимала прошлая постройка (чтобы убрать её перед новой). */
    @Nullable
    public BoundingBox getLastBox() {
        if (box.length != 6) {
            return null;
        }
        return new BoundingBox(box[0], box[1], box[2], box[3], box[4], box[5]);
    }

    public void markBuilt(int signature, BoundingBox bounds) {
        this.built = true;
        this.signature = signature;
        this.box = new int[]{bounds.minX(), bounds.minY(), bounds.minZ(), bounds.maxX(), bounds.maxY(), bounds.maxZ()};
        setDirty();
    }
}

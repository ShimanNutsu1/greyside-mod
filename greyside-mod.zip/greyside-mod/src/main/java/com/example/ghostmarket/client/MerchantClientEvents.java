package com.example.ghostmarket.client;

import com.example.ghostmarket.GhostMarket;
import com.example.ghostmarket.entity.MerchantEntity;
import com.example.ghostmarket.registry.ModEntities;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = GhostMarket.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class MerchantClientEvents {

    @SubscribeEvent
    public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.<MerchantEntity>registerEntityRenderer(ModEntities.BLOATED.get(), context -> new MerchantRenderer(context, 0.8F));
        event.<MerchantEntity>registerEntityRenderer(ModEntities.STITCHED.get(), context -> new MerchantRenderer(context, 0.6F));
        event.<MerchantEntity>registerEntityRenderer(ModEntities.FACELESS.get(), context -> new MerchantRenderer(context, 0.4F));
        // У Висельника ноги над полом, тень под ним выглядела бы неправильно.
        event.<MerchantEntity>registerEntityRenderer(ModEntities.HANGED.get(), context -> new MerchantRenderer(context, 0.0F));
    }

    private MerchantClientEvents() {
    }
}

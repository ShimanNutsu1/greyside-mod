package com.example.ghostmarket.entity;

import com.example.ghostmarket.GhostMarket;
import com.example.ghostmarket.config.MerchantConfig;
import com.example.ghostmarket.dimension.MarketLayout;
import com.example.ghostmarket.dimension.ModDimensions;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.TicketType;
import net.minecraft.world.level.ChunkPos;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;

/**
 * При старте сервера держит чанки лавок загруженными, ждёт settleTicks и запускает MerchantPlacement.ensure.
 * Ожидание нужно, потому что сущности чанка подгружаются с диска чуть позже самого чанка:
 * проверка "сразу" не увидела бы уже существующих торговцев и создала бы дубли.
 */
@Mod.EventBusSubscriber(modid = GhostMarket.MODID)
public final class MerchantPlacementEvents {
    /** Технические значения, не геймплей. Билет автоматически истекает, в сохранение мира он не попадает. */
    private static final int TICKET_TIMEOUT_TICKS = 1200;
    private static final int MAX_ATTEMPTS = 5;

    private static final TicketType<ChunkPos> SETUP_TICKET =
            TicketType.create("ghostmarket_merchants", Comparator.comparingLong(ChunkPos::toLong), TICKET_TIMEOUT_TICKS);

    private static int countdown = -1;
    private static int attempts;

    @SubscribeEvent
    public static void onServerStarted(ServerStartedEvent event) {
        countdown = -1;
        attempts = 0;
        ServerLevel level = event.getServer().getLevel(ModDimensions.GHOST_MARKET);
        if (level == null || !MerchantConfig.SPEC.isLoaded()) {
            return;
        }
        schedule(level);
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || countdown < 0) {
            return;
        }
        if (--countdown > 0) {
            return;
        }
        countdown = -1;

        ServerLevel level = event.getServer().getLevel(ModDimensions.GHOST_MARKET);
        if (level == null || !MerchantConfig.SPEC.isLoaded()) {
            return;
        }
        if (MerchantPlacement.ensure(level)) {
            return;
        }
        if (++attempts < MAX_ATTEMPTS) {
            GhostMarket.LOGGER.warn("Чанк лавки ещё не загружен, повторная проверка торговцев ({}/{}).", attempts, MAX_ATTEMPTS);
            schedule(level);
        } else {
            GhostMarket.LOGGER.error("Не удалось загрузить чанки лавок: часть торговцев не проверена.");
        }
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        countdown = -1;
        attempts = 0;
    }

    private static void schedule(ServerLevel level) {
        Set<ChunkPos> chunks = new HashSet<>();
        for (MarketLayout.StallSpot spot : MarketLayout.fromConfig().stallSpots()) {
            chunks.add(new ChunkPos(BlockPos.containing(spot.pos())));
        }
        // Расстояние 2 даёт уровень 31: чанк полностью загружен и тикает сущностей, как у принудительно загруженного.
        for (ChunkPos chunk : chunks) {
            level.getChunkSource().addRegionTicket(SETUP_TICKET, chunk, 2, chunk);
        }
        countdown = MerchantConfig.PLACEMENT_SETTLE_TICKS.get();
    }

    private MerchantPlacementEvents() {
    }
}

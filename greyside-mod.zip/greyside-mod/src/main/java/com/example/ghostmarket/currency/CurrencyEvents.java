package com.example.ghostmarket.currency;

import com.example.ghostmarket.GhostMarket;
import com.example.ghostmarket.config.GhostMarketConfig;
import com.example.ghostmarket.registry.ModItems;
import com.example.ghostmarket.registry.ModSounds;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.OwnableEntity;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.Cat;
import net.minecraft.world.entity.animal.Wolf;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.event.entity.living.AnimalTameEvent;
import net.minecraftforge.event.entity.living.BabyEntitySpawnEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = GhostMarket.MODID)
public final class CurrencyEvents {

    /** Метка: кто и когда приручил животное. MONITOR + пропуск отменённых: метка ставится, только если приручение состоится. */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onAnimalTame(AnimalTameEvent event) {
        if (event.isCanceled()) {
            return;
        }
        Animal animal = event.getAnimal();
        Player tamer = event.getTamer();
        if (animal.level().isClientSide() || tamer == null) {
            return;
        }
        PetMarks.markTamed(animal, tamer.getUUID(), animal.level().getGameTime());
    }

    /** Метка «рождён разведением». Щенок/котёнок от прирученных родителей сразу получает хозяина и время рождения. */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onBabySpawn(BabyEntitySpawnEvent event) {
        if (event.isCanceled()) {
            return;
        }
        AgeableMob child = event.getChild();
        if (child == null || child.level().isClientSide()) {
            return;
        }
        PetMarks.markBred(child);
        if (child instanceof OwnableEntity ownable && ownable.getOwnerUUID() != null) {
            PetMarks.markTamed(child, ownable.getOwnerUUID(), child.level().getGameTime());
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onLivingDeath(LivingDeathEvent event) {
        if (!GhostMarketConfig.SPEC.isLoaded()) {
            return;
        }
        LivingEntity victim = event.getEntity();
        if (!(victim.level() instanceof ServerLevel level)) {
            return;
        }
        if (!(event.getSource().getEntity() instanceof ServerPlayer player) || player instanceof FakePlayer) {
            return;
        }
        if (PetMarks.isRewarded(victim)) {
            return;
        }

        CurrencyRules.Category category = CurrencyRules.classify(victim, player);
        if (category == null) {
            return;
        }
        PetMarks.markRewarded(victim);

        RandomSource random = level.getRandom();
        double amount = CurrencyRules.rollBase(category, random);
        if (category == CurrencyRules.Category.PET) {
            amount += CurrencyRules.bondBonus(victim, level.getGameTime());
        } else {
            amount *= FarmTracker.evaluate(player.getUUID(), victim);
        }
        if (CurrencyRules.isBredReduced(victim, category)) {
            amount *= GhostMarketConfig.BRED_MULTIPLIER.get();
        }
        int total = CurrencyRules.probabilisticRound(amount, random);

        if (category == CurrencyRules.Category.PET) {
            playPetDeathEffects(level, victim, player);
        }
        if (total > 0) {
            dropBreaths(level, victim, total, random);
        }
    }

    private static void playPetDeathEffects(ServerLevel level, LivingEntity pet, ServerPlayer owner) {
        SoundEvent sound;
        if (pet instanceof Wolf) {
            sound = ModSounds.PET_DEATH_DOG.get();
        } else if (pet instanceof Cat) {
            sound = ModSounds.PET_DEATH_CAT.get();
        } else {
            sound = ModSounds.PET_DEATH_GENERIC.get();
        }
        level.playSound(null, pet.getX(), pet.getY(), pet.getZ(), sound, SoundSource.NEUTRAL,
                GhostMarketConfig.PET_DEATH_SOUND_VOLUME.get().floatValue(),
                GhostMarketConfig.PET_DEATH_SOUND_PITCH.get().floatValue());

        int particles = GhostMarketConfig.PET_DEATH_PARTICLE_COUNT.get();
        if (particles > 0) {
            level.sendParticles(CurrencyRules.BLACK_SMOKE,
                    pet.getX(), pet.getY() + pet.getBbHeight() * 0.5D, pet.getZ(),
                    particles, pet.getBbWidth() * 0.4D, pet.getBbHeight() * 0.3D, pet.getBbWidth() * 0.4D, 0.02D);
        }

        owner.displayClientMessage(Component.translatable("message.ghostmarket.pet_death"), true);
    }

    private static void dropBreaths(ServerLevel level, LivingEntity victim, int total, RandomSource random) {
        Item item = ModItems.LAST_BREATH.get();
        int maxStack = item.getMaxStackSize();
        int remaining = total;
        while (remaining > 0) {
            int count = Math.min(remaining, maxStack);
            remaining -= count;
            ItemEntity entity = new ItemEntity(level,
                    victim.getX(), victim.getY() + victim.getBbHeight() * 0.5D, victim.getZ(),
                    new ItemStack(item, count));
            entity.setDeltaMovement(random.nextGaussian() * 0.05D, 0.2D, random.nextGaussian() * 0.05D);
            entity.setDefaultPickUpDelay();
            level.addFreshEntity(entity);
        }
    }

    /** Тихий вздох при подборе. Событие приходит только с сервера. */
    @SubscribeEvent
    public static void onItemPickup(PlayerEvent.ItemPickupEvent event) {
        Player player = event.getEntity();
        if (player.level().isClientSide() || !GhostMarketConfig.SPEC.isLoaded()) {
            return;
        }
        if (!event.getStack().is(ModItems.LAST_BREATH.get())) {
            return;
        }
        player.level().playSound(null, player.getX(), player.getY(), player.getZ(),
                ModSounds.LAST_BREATH_PICKUP.get(), SoundSource.PLAYERS,
                GhostMarketConfig.PICKUP_SOUND_VOLUME.get().floatValue(),
                GhostMarketConfig.PICKUP_SOUND_PITCH.get().floatValue());
    }

    @SubscribeEvent
    public static void onPlayerLoggedOut(PlayerEvent.PlayerLoggedOutEvent event) {
        FarmTracker.clearPlayer(event.getEntity().getUUID());
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        FarmTracker.clearAll();
    }

    private CurrencyEvents() {
    }
}

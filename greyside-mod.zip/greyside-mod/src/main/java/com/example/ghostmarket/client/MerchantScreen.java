package com.example.ghostmarket.client;

import com.example.ghostmarket.GhostMarket;
import com.example.ghostmarket.network.BuyRequestPacket;
import com.example.ghostmarket.network.GhostMarketNetwork;
import com.example.ghostmarket.registry.ModItems;
import com.example.ghostmarket.trade.Good;
import com.example.ghostmarket.trade.GoodRegistry;
import com.example.ghostmarket.trade.MerchantMenu;
import com.example.ghostmarket.trade.Offer;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

import java.util.List;

/** Мрачное окно торговца: список товаров слева, цена в «Последних вздохах» справа, кнопка «Купить». */
public class MerchantScreen extends AbstractContainerScreen<MerchantMenu> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(GhostMarket.MODID, "textures/gui/merchant.png");

    private static final int ROW_X = 8;
    private static final int ROW_Y = 22;
    private static final int ROW_H = 14;
    private static final int ROW_W = 184;

    private static final int COLOR_TEXT = 0xFFCFC4D8;
    private static final int COLOR_TITLE = 0xFFB9A8D6;
    private static final int COLOR_PRICE_OK = 0xFFB9A8D6;
    private static final int COLOR_PRICE_BAD = 0xFFFF5555;
    private static final int COLOR_SOLD = 0xFF6A6A6A;
    private static final int COLOR_HOVER = 0x30FFFFFF;
    private static final int COLOR_SELECTED = 0x60802020;

    private int selected = -1;
    private Button buyButton;

    public MerchantScreen(MerchantMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = 200;
        this.imageHeight = 172;
    }

    @Override
    protected void init() {
        super.init();
        buyButton = addRenderableWidget(Button.builder(Component.translatable("screen.ghostmarket.merchant.buy"),
                button -> onBuy()).bounds(leftPos + 8, topPos + 150, 184, 16).build());
        buyButton.active = false;
    }

    private void onBuy() {
        if (isSelectable(selected)) {
            GhostMarketNetwork.CHANNEL.sendToServer(new BuyRequestPacket(menu.containerId, selected));
        }
    }

    private boolean isSelectable(int index) {
        List<Offer> offers = menu.getOffers();
        return index >= 0 && index < offers.size() && !offers.get(index).isSold();
    }

    @Override
    protected void containerTick() {
        super.containerTick();
        buyButton.active = isSelectable(selected) && menu.getBalance() >= menu.getOffers().get(selected).price();
    }

    private int rowAt(double mouseX, double mouseY) {
        double rx = mouseX - leftPos - ROW_X;
        double ry = mouseY - topPos - ROW_Y;
        if (rx < 0 || rx >= ROW_W || ry < 0) {
            return -1;
        }
        int row = (int) (ry / ROW_H);
        return row < menu.getOffers().size() ? row : -1;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int row = rowAt(mouseX, mouseY);
        if (button == 0 && row >= 0) {
            if (isSelectable(row)) {
                selected = row;
            }
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        graphics.blit(TEXTURE, leftPos, topPos, 0, 0, imageWidth, imageHeight);

        List<Offer> offers = menu.getOffers();
        int hovered = rowAt(mouseX, mouseY);
        for (int i = 0; i < offers.size(); i++) {
            Offer offer = offers.get(i);
            int x = leftPos + ROW_X;
            int y = topPos + ROW_Y + i * ROW_H;

            if (i == selected && !offer.isSold()) {
                graphics.fill(x, y, x + ROW_W, y + ROW_H - 1, COLOR_SELECTED);
            } else if (i == hovered) {
                graphics.fill(x, y, x + ROW_W, y + ROW_H - 1, COLOR_HOVER);
            }

            Component name = Component.translatable(offer.nameKey());
            if (offer.isSold()) {
                graphics.drawString(font, name.copy().withStyle(ChatFormatting.STRIKETHROUGH), x + 4, y + 3, COLOR_SOLD, false);
                Component sold = Component.translatable("screen.ghostmarket.merchant.sold");
                graphics.drawString(font, sold, x + ROW_W - 4 - font.width(sold), y + 3, COLOR_SOLD, false);
                continue;
            }

            graphics.drawString(font, name, x + 4, y + 3, COLOR_TEXT, false);

            boolean affordable = menu.getBalance() >= offer.price();
            String price = String.valueOf(offer.price());
            int iconX = x + ROW_W - 14;
            graphics.pose().pushPose();
            graphics.pose().translate(iconX, y - 1, 0.0F);
            graphics.pose().scale(0.8F, 0.8F, 1.0F);
            graphics.renderItem(new ItemStack(ModItems.LAST_BREATH.get()), 0, 0);
            graphics.pose().popPose();
            graphics.drawString(font, price, iconX - 2 - font.width(price), y + 3,
                    affordable ? COLOR_PRICE_OK : COLOR_PRICE_BAD, false);
        }
    }

    @Override
    protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
        graphics.drawString(font, title, 8, 6, COLOR_TITLE, false);
        graphics.drawString(font, Component.translatable("screen.ghostmarket.merchant.balance", menu.getBalance()),
                8, 138, COLOR_TEXT, false);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);
        super.render(graphics, mouseX, mouseY, partialTick);

        int row = rowAt(mouseX, mouseY);
        if (row >= 0) {
            Offer offer = menu.getOffers().get(row);
            Good good = GoodRegistry.get(offer.good());
            if (good != null) {
                graphics.renderComponentTooltip(font, List.of(
                        Component.translatable(offer.nameKey()),
                        good.describe().copy().withStyle(ChatFormatting.GRAY)), mouseX, mouseY);
            }
        }
    }
}

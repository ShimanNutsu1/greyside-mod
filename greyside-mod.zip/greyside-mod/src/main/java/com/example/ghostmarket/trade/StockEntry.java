package com.example.ghostmarket.trade;

import net.minecraft.resources.ResourceLocation;

/** Позиция из JSON ассортимента (до ротации). */
public record StockEntry(ResourceLocation good, int priceMin, int priceMax, int weight, boolean always, boolean singleUse) {
}

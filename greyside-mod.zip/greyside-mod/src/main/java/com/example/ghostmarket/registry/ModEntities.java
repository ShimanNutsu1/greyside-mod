package com.example.ghostmarket.registry;

import com.example.ghostmarket.GhostMarket;
import com.example.ghostmarket.entity.BloatedMerchant;
import com.example.ghostmarket.entity.FacelessMerchant;
import com.example.ghostmarket.entity.HangedMerchant;
import com.example.ghostmarket.entity.MerchantEntity;
import com.example.ghostmarket.entity.StitchedMerchant;
import com.example.ghostmarket.trade.MerchantType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, GhostMarket.MODID);

    // Размеры (ширина, высота) - размеры хитбокса, не модели. Подгони под свои модели из Blockbench.
    public static final RegistryObject<EntityType<BloatedMerchant>> BLOATED = ENTITY_TYPES.register("bloated_merchant",
            () -> merchantType(BloatedMerchant::new, "bloated_merchant", 1.6F, 2.2F));

    public static final RegistryObject<EntityType<StitchedMerchant>> STITCHED = ENTITY_TYPES.register("stitched_merchant",
            () -> merchantType(StitchedMerchant::new, "stitched_merchant", 1.2F, 2.2F));

    public static final RegistryObject<EntityType<FacelessMerchant>> FACELESS = ENTITY_TYPES.register("faceless_merchant",
            () -> merchantType(FacelessMerchant::new, "faceless_merchant", 0.8F, 2.3F));

    public static final RegistryObject<EntityType<HangedMerchant>> HANGED = ENTITY_TYPES.register("hanged_merchant",
            () -> merchantType(HangedMerchant::new, "hanged_merchant", 0.9F, 3.0F));

    /** Тип сущности по виду торговца (для расстановки на рынке). */
    public static EntityType<? extends MerchantEntity> typeOf(MerchantType kind) {
        return switch (kind) {
            case BLOATED -> BLOATED.get();
            case STITCHED -> STITCHED.get();
            case FACELESS -> FACELESS.get();
            case HANGED -> HANGED.get();
        };
    }

    private static <T extends MerchantEntity> EntityType<T> merchantType(EntityType.EntityFactory<T> factory,
                                                                         String name, float width, float height) {
        return EntityType.Builder.of(factory, MobCategory.MISC)
                .sized(width, height)
                .fireImmune()
                .clientTrackingRange(8)
                .updateInterval(2)
                .build(new ResourceLocation(GhostMarket.MODID, name).toString());
    }

    public static void register(IEventBus modBus) {
        ENTITY_TYPES.register(modBus);
    }

    private ModEntities() {
    }
}

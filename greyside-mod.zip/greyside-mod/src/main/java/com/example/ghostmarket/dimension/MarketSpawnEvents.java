package com.example.ghostmarket.dimension;

import com.example.ghostmarket.GhostMarket;
import com.example.ghostmarket.config.GhostMarketConfig;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.event.entity.living.MobSpawnEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.jetbrains.annotations.Nullable;

/**
 * Враждебные существа в измерении рынка не появляются сами: ни природный спавн, ни спавнеры, ни генерация.
 * Исключения: команда /summon, яйца призыва, раздатчики, вёдра. Ими управляет игрок или код мода.
 */
@Mod.EventBusSubscriber(modid = GhostMarket.MODID)
public final class MarketSpawnEvents {

    private static boolean shouldBlock(LevelAccessor level, Mob mob, @Nullable MobSpawnType type) {
        if (!GhostMarketConfig.SPEC.isLoaded() || !GhostMarketConfig.BLOCK_HOSTILE_SPAWNS.get()) {
            return false;
        }
        if (!ModDimensions.isMarket(level)) {
            return false;
        }
        if (!(mob instanceof Enemy) && mob.getType().getCategory() != MobCategory.MONSTER) {
            return false;
        }
        return type != MobSpawnType.COMMAND
                && type != MobSpawnType.SPAWN_EGG
                && type != MobSpawnType.DISPENSER
                && type != MobSpawnType.BUCKET;
    }

    @SubscribeEvent
    public static void onPositionCheck(MobSpawnEvent.PositionCheck event) {
        if (shouldBlock(event.getLevel(), event.getEntity(), event.getSpawnType())) {
            event.setResult(Event.Result.DENY);
        }
    }

    /** Страховка для путей спавна, которые не проверяют позицию (патрули, подкрепление зомби и т.п.). */
    @SubscribeEvent
    public static void onFinalizeSpawn(MobSpawnEvent.FinalizeSpawn event) {
        if (shouldBlock(event.getLevel(), event.getEntity(), event.getSpawnType())) {
            event.setSpawnCancelled(true);
        }
    }

    private MarketSpawnEvents() {
    }
}

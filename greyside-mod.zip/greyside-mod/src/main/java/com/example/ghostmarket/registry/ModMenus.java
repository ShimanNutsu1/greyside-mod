package com.example.ghostmarket.registry;

import com.example.ghostmarket.GhostMarket;
import com.example.ghostmarket.trade.MerchantMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModMenus {
    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(ForgeRegistries.MENU_TYPES, GhostMarket.MODID);

    public static final RegistryObject<MenuType<MerchantMenu>> MERCHANT = MENUS.register("merchant",
            () -> IForgeMenuType.create(MerchantMenu::fromNetwork));

    public static void register(IEventBus modBus) {
        MENUS.register(modBus);
    }

    private ModMenus() {
    }
}

package com.example.ghostmarket.client;

import net.minecraft.client.renderer.DimensionSpecialEffects;
import net.minecraft.world.phys.Vec3;

/**
 * Клиентский вид неба измерения рынка: SkyType.NONE не рисует ни солнце, ни луну, ни звёзды,
 * ни облака. Фоном служит цвет тумана из биома, без поправки на время суток.
 */
public class GhostMarketDimensionEffects extends DimensionSpecialEffects {

    public GhostMarketDimensionEffects() {
        super(Float.NaN, false, SkyType.NONE, false, false);
    }

    @Override
    public Vec3 getBrightnessDependentFogColor(Vec3 fogColor, float brightness) {
        return fogColor;
    }

    @Override
    public boolean isFoggyAt(int x, int y) {
        return true;
    }
}

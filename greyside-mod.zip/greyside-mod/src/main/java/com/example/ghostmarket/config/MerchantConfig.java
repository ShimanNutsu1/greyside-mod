package com.example.ghostmarket.config;

import com.example.ghostmarket.trade.MerchantType;
import net.minecraftforge.common.ForgeConfigSpec;

import java.util.EnumMap;
import java.util.Map;

/**
 * Настройки торговцев рынка (Этап 4А). Отдельный файл: config/ghostmarket-merchants.toml
 * (для мира: saves/&lt;мир&gt;/serverconfig/ghostmarket-merchants.toml).
 */
public final class MerchantConfig {
    public static final ForgeConfigSpec SPEC;

    // ===== Поведение =====
    public static final ForgeConfigSpec.DoubleValue LOOK_RADIUS;
    public static final ForgeConfigSpec.DoubleValue LOOK_TURN_SPEED;
    public static final ForgeConfigSpec.IntValue INTERACT_COOLDOWN_TICKS;
    public static final ForgeConfigSpec.BooleanValue OPERATOR_REMOVAL_ENABLED;
    public static final ForgeConfigSpec.IntValue OPERATOR_PERMISSION_LEVEL;

    // ===== Звуки =====
    public static final ForgeConfigSpec.BooleanValue SOUNDS_ENABLED;
    public static final ForgeConfigSpec.IntValue IDLE_MIN_SECONDS;
    public static final ForgeConfigSpec.IntValue IDLE_MAX_SECONDS;
    public static final ForgeConfigSpec.DoubleValue IDLE_VOLUME;
    public static final ForgeConfigSpec.DoubleValue CRUNCH_CHANCE;
    public static final ForgeConfigSpec.DoubleValue WHISPER_VOLUME;
    public static final ForgeConfigSpec.DoubleValue PITCH_JITTER;
    public static final ForgeConfigSpec.DoubleValue STITCHED_SECOND_VOICE_PITCH_RATIO;
    public static final ForgeConfigSpec.DoubleValue STITCHED_SECOND_VOICE_VOLUME;

    // ===== Расстановка =====
    public static final ForgeConfigSpec.IntValue PLACEMENT_SETTLE_TICKS;

    private static final Map<MerchantType, ForgeConfigSpec.DoubleValue> PITCH = new EnumMap<>(MerchantType.class);
    private static final Map<MerchantType, ForgeConfigSpec.BooleanValue> ENABLED = new EnumMap<>(MerchantType.class);
    private static final Map<MerchantType, ForgeConfigSpec.IntValue> COUNT = new EnumMap<>(MerchantType.class);

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();

        builder.comment("Торговцы рынка призраков (этап 4А)").push("merchants");

        builder.comment("Поведение").push("behavior");

        LOOK_RADIUS = builder
                .comment("Радиус, в котором торговец поворачивается к ближайшему игроку, блоки.")
                .defineInRange("lookRadius", 12.0D, 1.0D, 64.0D);

        LOOK_TURN_SPEED = builder
                .comment("Максимальная скорость поворота к игроку, градусов за тик.",
                        "Малые значения дают медленный, неотступный поворот; большие - резкий.")
                .defineInRange("lookTurnSpeed", 10.0D, 1.0D, 90.0D);

        INTERACT_COOLDOWN_TICKS = builder
                .comment("Пауза между откликами торговца на ПКМ, тиков (защита от спама шёпотом).")
                .defineInRange("interactCooldownTicks", 20, 0, 400);

        OPERATOR_REMOVAL_ENABLED = builder
                .comment("Торговцы неубиваемы. Единственный способ убрать одного: оператор бьёт его, присев (Shift + ЛКМ).",
                        "Если выключить, убрать торговца можно только правкой данных мира или выключением вида в конфиге.")
                .define("operatorRemovalEnabled", true);

        OPERATOR_PERMISSION_LEVEL = builder
                .comment("Уровень прав, нужный для удаления торговца (2 = обычный оператор, 4 = владелец).")
                .defineInRange("operatorPermissionLevel", 2, 1, 4);

        builder.pop();

        builder.comment("Звуки торговцев (заглушки на ванильных звуках, см. sounds.json)").push("sounds");

        SOUNDS_ENABLED = builder
                .comment("Включить звуки торговцев, когда они стоят без дела.")
                .define("enabled", true);

        IDLE_MIN_SECONDS = builder
                .comment("Минимальная пауза между фоновыми звуками одного торговца, секунд.")
                .defineInRange("idleMinSeconds", 8, 1, 3600);

        IDLE_MAX_SECONDS = builder
                .comment("Максимальная пауза между фоновыми звуками одного торговца, секунд.",
                        "Если меньше минимальной, берётся минимальная.")
                .defineInRange("idleMaxSeconds", 25, 1, 3600);

        IDLE_VOLUME = builder
                .comment("Громкость фонового звука (бормотание или хруст). Радиус слышимости = громкость x 16 блоков.")
                .defineInRange("idleVolume", 0.8D, 0.0D, 10.0D);

        CRUNCH_CHANCE = builder
                .comment("Шанс, что фоновый звук окажется хрустом, а не бормотанием (0.0-1.0).")
                .defineInRange("crunchChance", 0.25D, 0.0D, 1.0D);

        WHISPER_VOLUME = builder
                .comment("Громкость шёпота цен при ПКМ по торговцу.")
                .defineInRange("whisperVolume", 1.0D, 0.0D, 10.0D);

        PITCH_JITTER = builder
                .comment("Случайный разброс высоты тона вокруг базовой для вида (плюс-минус).")
                .defineInRange("pitchJitter", 0.08D, 0.0D, 0.5D);

        STITCHED_SECOND_VOICE_PITCH_RATIO = builder
                .comment("Сшитый говорит несколькими голосами: каждый его звук дублируется вторым голосом.",
                        "Высота второго голоса = высота первого x это число (итог зажимается в 0.5-2.0).")
                .defineInRange("stitchedSecondVoicePitchRatio", 0.6D, 0.25D, 4.0D);

        STITCHED_SECOND_VOICE_VOLUME = builder
                .comment("Громкость второго голоса Сшитого относительно первого (0.0-2.0).")
                .defineInRange("stitchedSecondVoiceVolume", 0.8D, 0.0D, 2.0D);

        builder.comment("Базовая высота тона по видам (0.5-2.0). Общий набор звуков, разная высота.").push("pitch");
        for (MerchantType type : MerchantType.values()) {
            PITCH.put(type, builder
                    .comment("Базовая высота тона вида '" + type.id() + "'.")
                    .defineInRange(type.id(), defaultPitch(type), 0.5D, 2.0D));
        }
        builder.pop();

        builder.pop(); // sounds

        builder.comment("Расстановка на площади. Позиции считаются от MarketLayout (лавки у стен).",
                "Лавок шесть. Виды занимают их по порядку: Раздутый, Сшитый, Безлицый, Висельник.",
                "Если сумма количеств больше шести, лишние торговцы не создаются (в лог пишется предупреждение).",
                "Выключенный вид или лишний торговец, созданный ранее, при следующем старте сервера убирается.").push("placement");

        PLACEMENT_SETTLE_TICKS = builder
                .comment("Сколько тиков после старта сервера ждать, прежде чем проверять и досоздавать торговцев.",
                        "За это время сохранённые торговцы успевают загрузиться вместе с чанками, иначе возможны дубли.",
                        "Если мир большой или диск медленный, увеличь.")
                .defineInRange("settleTicks", 100, 20, 600);

        for (MerchantType type : MerchantType.values()) {
            builder.comment("Вид '" + type.id() + "'").push(type.id());
            ENABLED.put(type, builder
                    .comment("Включить этот вид торговцев.")
                    .define("enabled", true));
            COUNT.put(type, builder
                    .comment("Сколько торговцев этого вида стоит на рынке.")
                    .defineInRange("count", 1, 0, 6));
            builder.pop();
        }

        builder.pop(); // placement

        builder.pop(); // merchants

        SPEC = builder.build();
    }

    private static double defaultPitch(MerchantType type) {
        return switch (type) {
            case BLOATED -> 0.6D;
            case STITCHED -> 0.9D;
            case FACELESS -> 0.8D;
            case HANGED -> 0.7D;
        };
    }

    public static double pitch(MerchantType type) {
        return PITCH.get(type).get();
    }

    public static boolean enabled(MerchantType type) {
        return ENABLED.get(type).get();
    }

    public static int count(MerchantType type) {
        return COUNT.get(type).get();
    }

    private MerchantConfig() {
    }
}

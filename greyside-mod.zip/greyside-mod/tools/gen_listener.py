"""Текстура Слушателя (64x64) под client/ListenerModel. Запуск из корня проекта: python3 tools/gen_listener.py"""
import os, random
from PIL import Image

OUT = os.path.join(os.path.dirname(__file__), "..", "src", "main", "resources", "assets", "greyside", "textures", "entity", "listener.png")
random.seed(11)
img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
px = img.load()

def fill(x0, y0, x1, y1, base, var=4):
    for y in range(y0, y1):
        for x in range(x0, x1):
            v = random.randint(-var, var)
            px[x, y] = tuple(max(0, min(255, b + v)) for b in base) + (255,)

def put(x, y, c):
    px[x, y] = c + (255,)

skin = (76, 74, 80)       # пепельная кожа
dark = (44, 43, 49)       # тёмные участки
ear_in = (122, 108, 112)  # внутренняя часть ушей: бледная, чуть розоватая
vein = (82, 52, 60)

# голова (0..28 x 0..15): гладкая, лица нет
fill(0, 0, 28, 15, skin, var=3)
fill(7, 0, 14, 7, dark, var=2)           # макушка потемнее
# лицевая сторона: x 7..14, y 7..15. Глаз нет: только едва заметные впадины под кожей
for (ex, ey) in ((8, 10), (12, 10)):
    for dx in range(2):
        put(ex + dx, ey, (60, 59, 65))
        put(ex + dx, ey + 1, (66, 65, 71))
# рта тоже нет, зато тонкий шов-шрам поперёк нижней части лица
for x in range(8, 13):
    put(x, 13, (58, 56, 62))

# уши (две развёртки): тёмный край, светлая «воронка», прожилки
def ear(x0, y0):
    fill(x0, y0, x0 + 20, y0 + 13, dark, var=2)
    # большие стороны: левая x0+1..x0+10 и правая x0+11..x0+20, высота 12 (y0+1..y0+13)
    for fx in (x0 + 1, x0 + 11):
        fill(fx + 1, y0 + 2, fx + 8, y0 + 12, ear_in, var=5)
        for i in range(4):  # прожилки расходятся от основания уха
            vx = fx + 1 + i
            for vy in range(y0 + 3, y0 + 11):
                if random.random() < 0.65:
                    put(vx + (vy - y0) // 4, vy, vein)
ear(28, 0)
ear(28, 41)

# торс (0..24 x 16..31): серая кожа, рёбра, тёмная спина
fill(0, 16, 24, 31, skin, var=3)
fill(16, 20, 24, 31, dark, var=3)        # спина
for y in range(21, 30, 2):               # рёбра на груди (лицевая грань x 4..12)
    for x in range(5, 11):
        put(x, y, (58, 56, 62))

# руки (24..48 x 16..39): длинные, к кистям темнеют
fill(24, 16, 48, 39, skin, var=3)
for x0 in (24, 36):
    for y in range(31, 39):
        for x in range(x0, x0 + 12):
            put(x, y, tuple(max(0, c - 10 - (y - 31) * 3) for c in skin))

# хребет (48..54 x 16..26)
fill(48, 16, 54, 26, (96, 92, 96), var=4)

# ноги (0..24 x 32..48)
fill(0, 32, 24, 48, (62, 60, 66), var=3)
for x0 in (0, 12):
    for y in range(44, 48):
        for x in range(x0, x0 + 12):
            put(x, y, dark)

img.save(OUT)
print("ok", OUT)

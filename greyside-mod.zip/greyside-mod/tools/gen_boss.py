"""Текстуры блоков и предметов, связанных с боссом Ионом (сам босс: gen_ion_geo.py). Запуск из корня проекта: python3 tools/gen_boss.py (нужен Pillow).
Маски (mask_ion) рисует gen_masks.py. Здесь: резец, постаменты, голова-трофей."""
import os, random
from PIL import Image

RES = os.path.join(os.path.dirname(__file__), "..", "src", "main", "resources", "assets", "greyside", "textures")
ENT = os.path.join(RES, "entity")
ITEM = os.path.join(RES, "item")
BLOCK = os.path.join(RES, "block")
for d in (ENT, ITEM, BLOCK):
    os.makedirs(d, exist_ok=True)
random.seed(11)

def noisy(base, var):
    v = random.randint(-var, var)
    return tuple(max(0, min(255, b + v)) for b in base) + (255,)

def fill(px, x0, y0, x1, y1, base, var=5, stripe=None):
    for y in range(y0, y1):
        for x in range(x0, x1):
            c = noisy(base, var)
            if stripe and (y % stripe == 0):
                c = tuple(min(255, k + 14) for k in c[:3]) + (255,)
            px[x, y] = c

# резец (16x16)
ic = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
p = ic.load()
for i in range(3, 13):                # лезвие по диагонали
    p[i + 1, 14 - i] = (176, 178, 186, 255)
    p[i, 14 - i] = (120, 122, 132, 255)
    p[i + 2, 14 - i] = (214, 216, 224, 255)
for i in range(1, 4):                 # рукоять
    p[i, 15 - i] = (60, 44, 34, 255)
    p[i + 1, 15 - i] = (88, 66, 50, 255)
p[3, 11] = (245, 245, 235, 255)
ic.save(os.path.join(ITEM, "ion_chisel.png"))

# боковая грань постамента и верхи с масками
side = Image.new("RGBA", (16, 16))
sp = side.load()
for y in range(16):
    for x in range(16):
        sp[x, y] = noisy((24, 24, 30), 4)
for i in range(16):
    for c in ((0, i), (15, i), (i, 0), (i, 15)):
        sp[c] = (46, 46, 54, 255)
for x in range(4, 12):
    sp[x, 7] = (52, 52, 60, 255)
    sp[x, 8] = (52, 52, 60, 255)
side.save(os.path.join(BLOCK, "mask_pedestal_side.png"))

for kind in ("silence", "watcher", "void"):
    icon = Image.open(os.path.join(ITEM, "mask_%s.png" % kind)).convert("RGBA")
    ip = icon.load()
    for filled in (False, True):
        top = Image.new("RGBA", (16, 16))
        tp = top.load()
        for y in range(16):
            for x in range(16):
                tp[x, y] = noisy((18, 18, 24), 3)
        for i in range(16):
            for c in ((0, i), (15, i), (i, 0), (i, 15)):
                tp[c] = (60, 60, 70, 255)
        for y in range(16):
            for x in range(16):
                if ip[x, y][3] > 0:
                    if filled:
                        tp[x, y] = ip[x, y]
                    else:
                        r, g, b, a = ip[x, y]
                        tp[x, y] = (r // 6 + 14, g // 6 + 14, b // 6 + 16, 255)
        top.save(os.path.join(BLOCK, "mask_pedestal_top_%s%s.png" % (kind, "_filled" if filled else "")))

# Голова Иона: гладкое лицо на деревянном блоке
head = Image.new("RGBA", (16, 16))
hp = head.load()
for y in range(16):
    for x in range(16):
        hp[x, y] = noisy((150, 142, 128), 5)
for i in range(16):
    for c in ((0, i), (15, i), (i, 0), (i, 15)):
        hp[c] = (70, 60, 50, 255)
for x in range(4, 7):
    hp[x, 6] = (20, 18, 16, 255)
for x in range(9, 12):
    hp[x, 6] = (20, 18, 16, 255)
for y in range(8, 14):
    hp[8 + ((y * 5) % 3) - 1, y] = (60, 52, 44, 255)
head.save(os.path.join(BLOCK, "ion_head.png"))
print("ok")

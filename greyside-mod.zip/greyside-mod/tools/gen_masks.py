"""Генерирует текстуры масок Безликого: иконки предметов 16x16 и слой брони 64x32 (только голова).
Запуск из корня проекта: python3 tools/gen_masks.py  (нужен Pillow)."""
import os
from PIL import Image

RES = os.path.join(os.path.dirname(__file__), "..", "src", "main", "resources", "assets")
ITEM = os.path.join(RES, "greyside", "textures", "item")
ARMOR = os.path.join(RES, "minecraft", "textures", "models", "armor")
os.makedirs(ITEM, exist_ok=True)
os.makedirs(ARMOR, exist_ok=True)

# цвет основы, тень, детали
STYLES = {
    "mask_silence": dict(base=(222, 218, 205, 255), shade=(170, 166, 154, 255), ink=(28, 28, 30, 255)),
    "mask_watcher": dict(base=(120, 120, 126, 255), shade=(82, 82, 88, 255), ink=(235, 235, 235, 255)),
    "mask_void":    dict(base=(26, 26, 32, 255),    shade=(14, 14, 18, 255),  ink=(210, 210, 220, 255)),
}

def face(kind, st, put, ox, oy, w, h):
    """Рисует лицо маски в прямоугольнике w x h. put(x, y, color)."""
    b, s, k = st["base"], st["shade"], st["ink"]
    for y in range(h):
        for x in range(w):
            put(ox + x, oy + y, b)
    for x in range(w):  # тень по низу
        put(ox + x, oy + h - 1, s)
    for y in range(h):  # тень по бокам
        put(ox, oy + y, s)
        put(ox + w - 1, oy + y, s)
    cx = w // 2
    if kind == "mask_silence":
        # узкие щели глаз и зашитый рот
        for x in (cx - 3, cx - 2, cx + 1, cx + 2):
            put(ox + x, oy + h // 3, k)
        for i in range(-3, 4):
            put(ox + cx + i, oy + (h * 2) // 3, k)
        for i in range(-3, 4, 2):
            put(ox + cx + i, oy + (h * 2) // 3 - 1, k)
            put(ox + cx + i, oy + (h * 2) // 3 + 1, k)
    elif kind == "mask_watcher":
        # один большой глаз по центру
        for dx in range(-2, 2):
            for dy in range(-1, 1):
                put(ox + cx + dx, oy + h // 3 + dy, k)
        put(ox + cx - 1, oy + h // 3 - 1, st["shade"])
        put(ox + cx, oy + h // 3, st["shade"])
        for i in range(-1, 2):
            put(ox + cx + i, oy + (h * 3) // 4, k)
    else:
        # пустые чёрные маски с тонкими светлыми прорезями и трещиной
        for x in (cx - 3, cx - 2, cx + 1, cx + 2):
            put(ox + x, oy + h // 3, k)
        for y in range(h // 2, h - 1):
            put(ox + cx + ((y * 3) % 3) - 1, oy + y, st["shade"] if y % 2 else (60, 60, 68, 255))

def icon(kind, st):
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    px = img.load()
    def put(x, y, c):
        if 0 <= x < 16 and 0 <= y < 16:
            px[x, y] = c
    # овал маски 10 x 13
    for y in range(2, 15):
        half = 5 if 4 <= y <= 11 else (4 if y in (3, 12) else 3)
        if y in (2, 14): half = 2
        for x in range(8 - half, 8 + half):
            px[x, y] = st["base"]
        px[8 - half, y] = st["shade"]
        px[8 + half - 1, y] = st["shade"]
    for x in range(6, 10):
        px[x, 14] = st["shade"]
    face(kind, st, put, 3, 4, 10, 9)
    # вернуть форму: обрезать углы
    for (x, y) in [(3, 4), (12, 4), (3, 12), (12, 12)]:
        pass
    return img

def armor(kind, st):
    img = Image.new("RGBA", (64, 32), (0, 0, 0, 0))
    px = img.load()
    def put(x, y, c):
        px[x, y] = c
    base, shade = st["base"], st["shade"]
    # верх, низ, затылок и бока: сплошная основа
    for (x0, y0, x1, y1) in [(8, 0, 16, 8), (16, 0, 24, 8), (0, 8, 8, 16), (16, 8, 24, 16), (24, 8, 32, 16)]:
        for y in range(y0, y1):
            for x in range(x0, x1):
                px[x, y] = shade if (x + y) % 5 == 0 else base
    face(kind, st, put, 8, 8, 8, 8)  # лицо
    return img

for kind, st in STYLES.items():
    icon(kind, st).save(os.path.join(ITEM, kind + ".png"))
    armor(kind, st).save(os.path.join(ARMOR, "greyside_%s_layer_1.png" % kind))
    print("ok", kind)

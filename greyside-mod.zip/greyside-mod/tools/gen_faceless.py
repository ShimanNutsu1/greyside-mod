"""Текстура Безликого (64x64) под client/FacelessModel. Запуск из корня проекта: python3 tools/gen_faceless.py"""
import os, random
from PIL import Image

OUT = os.path.join(os.path.dirname(__file__), "..", "src", "main", "resources", "assets", "greyside", "textures", "entity", "faceless.png")
random.seed(7)
img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
px = img.load()

def fill(x0, y0, x1, y1, base, var=4, streak=None):
    for y in range(y0, y1):
        for x in range(x0, x1):
            v = random.randint(-var, var)
            c = tuple(max(0, min(255, b + v)) for b in base)
            if streak and x % streak == 0:
                c = tuple(min(255, k + 8) for k in c)
            px[x, y] = c + (255,)

body = (14, 14, 17)
fill(0, 0, 20, 13, (52, 52, 58), var=2)   # голова: гладкая, лица нет совсем
fill(20, 0, 28, 6, (20, 20, 24))          # шея
fill(0, 16, 18, 35, body, streak=3)       # торс
fill(20, 16, 36, 42, body, streak=2)      # руки
fill(0, 40, 16, 60, body, streak=2)       # ноги
for y in range(19, 33, 4):                # бинты на торсе
    for x in range(3, 15):
        px[x, y] = (34, 34, 40, 255)
img.save(OUT)
print("ok", OUT)

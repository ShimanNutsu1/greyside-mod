import os, subprocess, tempfile
import numpy as np
from scipy import signal
from scipy.io import wavfile

SR = 44100
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets", "greyside", "sounds")
os.makedirs(OUT, exist_ok=True)


def t_axis(dur):
    return np.arange(int(SR * dur)) / SR


def noise(dur, rng):
    return rng.standard_normal(int(SR * dur))


def bandpass(x, lo, hi, order=3):
    sos = signal.butter(order, [lo, hi], btype="band", fs=SR, output="sos")
    return signal.sosfilt(sos, x)


def lowpass(x, fc, order=3):
    sos = signal.butter(order, fc, btype="low", fs=SR, output="sos")
    return signal.sosfilt(sos, x)


def highpass(x, fc, order=3):
    sos = signal.butter(order, fc, btype="high", fs=SR, output="sos")
    return signal.sosfilt(sos, x)


def fade(x, a=0.01, b=0.05):
    n = len(x)
    na, nb = int(SR * a), int(SR * b)
    env = np.ones(n)
    if na > 0:
        env[:na] = np.linspace(0, 1, na)
    if nb > 0:
        env[-nb:] *= np.linspace(1, 0, nb)
    return x * env


def sweep(f0, f1, dur, curve=1.0):
    """Sine with frequency going f0 -> f1 (curve shapes the interpolation)."""
    t = t_axis(dur)
    k = (t / dur) ** curve
    f = f0 + (f1 - f0) * k
    phase = 2 * np.pi * np.cumsum(f) / SR
    return np.sin(phase)


def saw_sweep(f0, f1, dur):
    t = t_axis(dur)
    f = f0 + (f1 - f0) * (t / dur)
    phase = np.cumsum(f) / SR
    return 2 * (phase % 1.0) - 1


def reverb(x, rng, tail=1.2, mix=0.3):
    n = int(SR * tail)
    ir = rng.standard_normal(n) * np.exp(-np.linspace(0, 7, n))
    ir = lowpass(ir, 4500)
    total = len(x) + n
    wet = np.zeros(total)
    conv = signal.fftconvolve(x, ir)
    wet[: min(total, len(conv))] = conv[:total]
    dry = np.concatenate([x, np.zeros(n)])
    wet = wet / (np.max(np.abs(wet)) + 1e-9) * np.max(np.abs(dry))
    return dry * (1 - mix) + wet * mix


def click(dur, f, decay, rng, amp=1.0):
    t = t_axis(dur)
    return amp * np.sin(2 * np.pi * f * t) * np.exp(-t * decay) * (1 + 0.3 * rng.standard_normal(len(t)))


def place(buf, snd, at):
    i = int(SR * at)
    end = min(len(buf), i + len(snd))
    if i < len(buf):
        buf[i:end] += snd[: end - i]


def save(name, x, peak=0.8):
    x = np.asarray(x, dtype=np.float64)
    x = x - np.mean(x)
    x = x / (np.max(np.abs(x)) + 1e-9) * peak
    pcm = (x * 32767).astype(np.int16)
    with tempfile.TemporaryDirectory() as d:
        wav = os.path.join(d, name + ".wav")
        wavfile.write(wav, SR, pcm)
        out = os.path.join(OUT, name + ".ogg")
        subprocess.run(
            ["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-c:a", "libvorbis",
             "-q:a", "4", "-ac", "1", "-ar", str(SR), out],
            check=True,
        )
    print("ok", name, f"{len(x) / SR:.2f}s", os.path.getsize(out), "bytes")


# ---------------------------------------------------------------- rift_warning
def rift_warning():
    rng = np.random.default_rng(1)
    dur = 1.4
    t = t_axis(dur)
    # дрожащий растущий тон
    tone = sweep(260, 820, dur, 1.6) * 0.5 + sweep(262 * 1.5, 830 * 1.5, dur, 1.6) * 0.25
    tone *= 0.6 + 0.4 * np.sin(2 * np.pi * (7 + 10 * t / dur) * t)
    # треск рвущейся ткани: импульсы с растущей частотой
    crack = np.zeros(len(t))
    pos = 0.0
    while pos < dur:
        place(crack, click(0.03, rng.uniform(1500, 4500), 180, rng, rng.uniform(0.4, 1.0)), pos)
        pos += rng.exponential(0.14 - 0.11 * pos / dur) + 0.005
    crack = highpass(crack, 800)
    air = bandpass(noise(dur, rng), 2000, 7000) * 0.12 * (t / dur)
    x = tone + crack * 0.9 + air
    env = np.sin(np.pi * np.clip(t / dur, 0, 1)) ** 0.6
    x = reverb(x * env, rng, 0.8, 0.22)
    save("rift_warning", fade(x, 0.02, 0.15))


# ---------------------------------------------------------------- rift_collapse
def rift_collapse():
    rng = np.random.default_rng(2)
    dur = 2.4
    buf = np.zeros(int(SR * dur))
    # всасывание: нарастающий шум
    n = noise(1.3, rng)
    suck = bandpass(n, 300, 3000) * np.linspace(0, 1, len(n)) ** 2
    # нисходящий тон
    drop = sweep(900, 60, 1.3, 0.5) * np.linspace(0.1, 0.8, int(SR * 1.3))
    place(buf, suck * 0.7 + drop * 0.5, 0.0)
    # хлопок и сабы
    t = t_axis(1.1)
    thump = np.sin(2 * np.pi * 52 * t) * np.exp(-t * 4.5)
    thump += np.sin(2 * np.pi * 104 * t) * np.exp(-t * 7) * 0.4
    burst = lowpass(highpass(noise(1.1, rng), 200), 5000) * np.exp(-t * 10)
    place(buf, thump * 1.2 + burst * 0.7, 1.25)
    buf = reverb(buf, rng, 1.0, 0.25)
    save("rift_collapse", fade(buf, 0.01, 0.3))


# ---------------------------------------------------------------- anchor_activate
def anchor_activate():
    rng = np.random.default_rng(3)
    dur = 2.8
    t = t_axis(dur)
    swell = np.sin(np.pi * np.clip(t / dur, 0, 1)) ** 1.5
    drone = (np.sin(2 * np.pi * 55 * t) + 0.5 * np.sin(2 * np.pi * 110.5 * t)
             + 0.25 * np.sin(2 * np.pi * 165 * t)) * swell
    whoosh = bandpass(noise(dur, rng), 200, 1800) * swell * 0.35
    buf = drone * 0.7 + whoosh
    # колокольные неравномерные обертоны
    for f, a, at in [(220, 0.5, 0.9), (607, 0.28, 0.92), (1188, 0.15, 0.95), (330, 0.3, 1.1)]:
        tt = t_axis(1.8)
        bell = np.sin(2 * np.pi * f * tt) * np.exp(-tt * 2.2) * a
        place(buf, bell, at)
    buf = reverb(buf, rng, 1.5, 0.3)
    save("anchor_activate", fade(buf, 0.02, 0.4))


# ---------------------------------------------------------------- anchor_deny
def anchor_deny():
    rng = np.random.default_rng(4)
    dur = 0.55
    t = t_axis(dur)
    thud = sweep(95, 48, dur, 0.4) * np.exp(-t * 9)
    grit = lowpass(noise(dur, rng), 900) * np.exp(-t * 25) * 0.6
    dis = np.sin(2 * np.pi * 136 * t) * np.exp(-t * 12) * 0.25
    save("anchor_deny", fade(thud + grit + dis, 0.002, 0.1))


# ---------------------------------------------------------------- listener
def listener_idle(name, seed):
    rng = np.random.default_rng(seed)
    dur = 1.9
    t = t_axis(dur)
    # хриплое дыхание: низкий шум, медленная амплитудная модуляция
    breath = lowpass(noise(dur, rng), 700) * (0.5 + 0.5 * np.sin(2 * np.pi * 0.85 * t - 1.2)) ** 2
    rasp = bandpass(noise(dur, rng), 1500, 4500) * (0.5 + 0.5 * np.sin(2 * np.pi * 0.85 * t - 1.0)) ** 3 * 0.25
    buf = breath + rasp
    # редкие цокающие щелчки языком
    for at in sorted(rng.uniform(0.2, dur - 0.3, size=rng.integers(2, 4))):
        f = rng.uniform(900, 1700)
        c = click(0.07, f, 55, rng) * 0.9
        place(buf, c, at)
    buf = reverb(buf, rng, 0.7, 0.2)
    save(name, fade(buf, 0.05, 0.25), peak=0.7)


def listener_alert():
    rng = np.random.default_rng(7)
    dur = 1.0
    buf = np.zeros(int(SR * dur))
    pos = 0.0
    gap = 0.09
    while pos < 0.55:
        place(buf, click(0.05, rng.uniform(1800, 2600), 90, rng), pos)
        gap = max(0.025, gap * 0.82)
        pos += gap
    t = t_axis(0.5)
    hiss = bandpass(noise(0.5, rng), 3000, 7500) * np.sin(np.pi * t / 0.5) ** 1.5 * 0.8
    place(buf, hiss, 0.4)
    drone = sweep(110, 190, 0.6, 1.0) * np.hanning(int(SR * 0.6)) * 0.35
    place(buf, drone, 0.3)
    buf = reverb(buf, rng, 0.6, 0.18)
    save("listener_alert", fade(buf, 0.002, 0.15))


def listener_hurt():
    rng = np.random.default_rng(8)
    dur = 0.5
    t = t_axis(dur)
    voice = saw_sweep(190, 95, dur) * np.exp(-t * 6)
    voice = lowpass(voice, 1800)
    rasp = bandpass(noise(dur, rng), 800, 3500) * np.exp(-t * 9) * 0.6
    save("listener_hurt", fade(voice * 0.8 + rasp, 0.003, 0.12))


def listener_death():
    rng = np.random.default_rng(9)
    dur = 1.7
    t = t_axis(dur)
    env = np.exp(-t * 1.9)
    voice = lowpass(saw_sweep(150, 32, dur), 1200) * env
    exhale = bandpass(noise(dur, rng), 400, 3800) * env * (0.4 + 0.6 * np.sin(2 * np.pi * 5 * t) ** 2) * 0.5
    buf = voice * 0.8 + exhale
    place(buf, click(0.08, 1100, 50, rng) * 0.8, 1.45)
    buf = reverb(buf, rng, 0.9, 0.25)
    save("listener_death", fade(buf, 0.005, 0.3))


# ---------------------------------------------------------------- whisper
VOWELS = [(300, 870), (400, 2000), (500, 1500), (650, 1100), (350, 2300), (700, 1200)]


def whisper():
    rng = np.random.default_rng(11)
    segs = []
    n_syll = 9
    for i in range(n_syll):
        dur = rng.uniform(0.14, 0.30)
        f1, f2 = VOWELS[rng.integers(0, len(VOWELS))]
        f1 *= rng.uniform(0.9, 1.1)
        f2 *= rng.uniform(0.9, 1.1)
        n = noise(dur, rng)
        body = bandpass(n, f1 * 0.8, f1 * 1.2) * 1.0 + bandpass(n, f2 * 0.85, f2 * 1.15) * 0.9
        # шипящее начало слога
        sh = highpass(n, 3500) * np.exp(-t_axis(dur) * 30) * 0.7
        env = np.hanning(len(n)) ** 0.7
        segs.append((body + sh) * env)
        gap = rng.uniform(0.02, 0.09) if rng.random() > 0.2 else rng.uniform(0.2, 0.35)
        segs.append(np.zeros(int(SR * gap)))
    x = np.concatenate(segs)
    x = highpass(x, 250)
    x = reverb(x, rng, 1.6, 0.45)
    save("whisper", fade(x, 0.05, 0.4), peak=0.55)


if __name__ == "__main__":
    rift_warning()
    rift_collapse()
    anchor_activate()
    anchor_deny()
    listener_idle("listener_idle1", 5)
    listener_idle("listener_idle2", 6)
    listener_alert()
    listener_hurt()
    listener_death()
    whisper()

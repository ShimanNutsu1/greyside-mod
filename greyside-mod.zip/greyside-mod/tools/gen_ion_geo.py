"""Модель, анимации и текстуры Иона для GeckoLib. Запуск из корня проекта: python3 tools/gen_ion_geo.py (нужен Pillow).
Пишет: assets/greyside/geo/ion.geo.json, animations/ion.animation.json,
textures/entity/ion.png, ion_glowmask.png, ion_enraged.png, ion_enraged_glowmask.png.
Единицы модели: 1 = 1/16 блока, высота около 79 (≈ 4.9 блока). Текстура 512x512, 2 пикселя на единицу."""
import json, os, random, math
from PIL import Image, ImageDraw

ROOT = os.path.join(os.path.dirname(__file__), "..", "src", "main", "resources", "assets", "greyside")
GEO = os.path.join(ROOT, "geo"); ANIM = os.path.join(ROOT, "animations"); TEX = os.path.join(ROOT, "textures", "entity")
for d in (GEO, ANIM, TEX):
    os.makedirs(d, exist_ok=True)
SZ = 512
DENS = 2

# ---------- описание модели ----------
# bone: (имя, родитель, pivot)
BONES = [
    ("root", None, [0, 0, 0]),
    ("legL", "root", [6.5, 28, 0]),
    ("legR", "root", [-6.5, 28, 0]),
    ("body", "root", [0, 28, 0]),
    ("neck", "body", [0, 58, 0]),
    ("head", "neck", [0, 62, 0]),
    ("jaw", "head", [0, 70, -5]),
    ("armL", "body", [15, 56, 0]),
    ("armR", "body", [-15, 56, 0]),
    ("chisel", "armR", [-15.5, 38, 0]),
    ("orbit", "root", [0, 70, 0]),
    ("ragsL", "body", [8, 30, -6]),
    ("ragsR", "body", [-8, 30, -6]),
    ("ragsB", "body", [0, 30, 6]),
]
# cube: (bone, name, origin, size, role)
CUBES = [
    ("legL", "legL", [3, 0, -3.5], [7, 28, 7], "wood"),
    ("legL", "footL", [2.5, 0, -6], [8, 3, 10], "wood"),
    ("legR", "legR", [-10, 0, -3.5], [7, 28, 7], "wood"),
    ("legR", "footR", [-10.5, 0, -6], [8, 3, 10], "wood"),
    ("body", "torso", [-12, 28, -6], [24, 30, 12], "torso"),
    ("body", "wrap1", [-12.5, 31, -6.5], [25, 3, 13], "wrap"),
    ("body", "wrap2", [-12.5, 40, -6.5], [25, 3, 13], "wrap"),
    ("body", "wrap3", [-12.5, 49, -6.5], [25, 3, 13], "wrap"),
    ("neck", "neck", [-3, 58, -3], [6, 5, 6], "wood"),
    ("head", "skull", [-7, 70, -7], [14, 9, 14], "head"),
    ("jaw", "jaw", [-6, 62, -7], [12, 8, 13], "jaw"),
    ("armL", "armL", [12, 12, -3.5], [7, 46, 7], "wood"),
    ("armL", "handL", [11.5, 5, -4], [8, 7, 8], "bone"),
    ("armL", "clawL1", [12, -2, -3.5], [2, 7, 2], "bone"),
    ("armL", "clawL2", [15, -3, -1], [2, 8, 2], "bone"),
    ("armL", "clawL3", [17, -2, 1.5], [2, 7, 2], "bone"),
    ("armR", "armR", [-19, 36, -3.5], [7, 22, 7], "wood"),
    ("chisel", "blade", [-17.5, 0, -1], [4, 38, 2], "blade"),
    ("chisel", "guard", [-20, 36, -2.5], [9, 2, 5], "wood"),
    ("orbit", "plate0", [-5, 63, -20], [10, 14, 2], "plate"),
    ("orbit", "plate1", [18, 63, -5], [2, 14, 10], "plate"),
    ("orbit", "plate2", [-5, 63, 18], [10, 14, 2], "plate"),
    ("orbit", "plate3", [-20, 63, -5], [2, 14, 10], "plate"),
    ("ragsL", "ragL", [6, 12, -7], [5, 18, 1], "rag"),
    ("ragsR", "ragR", [-11, 12, -7], [5, 18, 1], "rag"),
    ("ragsB", "ragB", [-3, 8, 6.5], [6, 22, 1], "rag"),
]
FACES = ("north", "east", "south", "west", "up", "down")

def face_size(size, f):
    sx, sy, sz = size
    if f in ("north", "south"): return sx, sy
    if f in ("east", "west"): return sz, sy
    return sx, sz

# ---------- укладка граней в атлас (полки) ----------
rects = []  # (cube_index, face, pw, ph)
for ci, c in enumerate(CUBES):
    for f in FACES:
        w, h = face_size(c[3], f)
        rects.append((ci, f, max(2, int(round(w * DENS))), max(2, int(round(h * DENS)))))
rects.sort(key=lambda r: -r[3])
placed = {}
x = y = shelf = 0
for ci, f, pw, ph in rects:
    if x + pw > SZ:
        x = 0; y += shelf + 1; shelf = 0
    assert y + ph <= SZ, "атлас переполнен"
    placed[(ci, f)] = (x, y, pw, ph)
    x += pw + 1
    shelf = max(shelf, ph)

# ---------- geo.json ----------
bones_out = []
for name, parent, pivot in BONES:
    b = {"name": name, "pivot": pivot}
    if parent: b["parent"] = parent
    cubes = []
    for ci, c in enumerate(CUBES):
        if c[0] != name: continue
        uv = {}
        for f in FACES:
            u, v, pw, ph = placed[(ci, f)]
            uv[f] = {"uv": [u, v], "uv_size": [pw, ph]}
        cubes.append({"origin": c[2], "size": c[3], "uv": uv})
    if cubes: b["cubes"] = cubes
    bones_out.append(b)
geo = {"format_version": "1.12.0", "minecraft:geometry": [{
    "description": {"identifier": "geometry.ion", "texture_width": SZ, "texture_height": SZ,
                    "visible_bounds_width": 6, "visible_bounds_height": 7, "visible_bounds_offset": [0, 2.5, 0]},
    "bones": bones_out}]}
json.dump(geo, open(os.path.join(GEO, "ion.geo.json"), "w"), indent=1)

# ---------- анимации ----------
def kf(*pairs):
    return {str(t): v for t, v in pairs}
A = {}
A["animation.ion.idle"] = {"loop": True, "animation_length": 4.0, "bones": {
    "body": {"rotation": kf((0.0, [0, 0, 0]), (2.0, [2.5, 0, 1]), (4.0, [0, 0, 0]))},
    "head": {"rotation": kf((0.0, [0, 0, 3]), (2.0, [4, 0, -4]), (4.0, [0, 0, 3]))},
    "armL": {"rotation": kf((0.0, [0, 0, -2]), (2.0, [3, 0, -5]), (4.0, [0, 0, -2]))},
}}
A["animation.ion.walk"] = {"loop": True, "animation_length": 1.2, "bones": {
    "legL": {"rotation": kf((0.0, [0, 0, 0]), (0.3, [32, 0, 0]), (0.6, [0, 0, 0]), (0.9, [-32, 0, 0]), (1.2, [0, 0, 0]))},
    "legR": {"rotation": kf((0.0, [0, 0, 0]), (0.3, [-32, 0, 0]), (0.6, [0, 0, 0]), (0.9, [32, 0, 0]), (1.2, [0, 0, 0]))},
    "body": {"rotation": kf((0.0, [4, 0, 2]), (0.6, [4, 0, -2]), (1.2, [4, 0, 2])),
             "position": kf((0.0, [0, 0, 0]), (0.3, [0, 1.2, 0]), (0.6, [0, 0, 0]), (0.9, [0, 1.2, 0]), (1.2, [0, 0, 0]))},
    "head": {"rotation": kf((0.0, [-4, 0, 0]), (0.6, [-8, 0, 0]), (1.2, [-4, 0, 0]))},
}}
A["animation.ion.attack"] = {"loop": "play_once", "animation_length": 0.9, "bones": {
    "armR": {"rotation": kf((0.0, [0, 0, 0]), (0.25, [-120, 0, -10]), (0.45, [45, 0, 0]), (0.9, [0, 0, 0]))},
    "jaw": {"rotation": kf((0.0, [0, 0, 0]), (0.25, [38, 0, 0]), (0.45, [14, 0, 0]), (0.9, [0, 0, 0]))},
    "head": {"rotation": kf((0.0, [0, 0, 0]), (0.25, [-14, 0, 0]), (0.45, [16, 0, 0]), (0.9, [0, 0, 0]))},
}}
A["animation.ion.slam"] = {"loop": "play_once", "animation_length": 1.1, "bones": {
    "armL": {"rotation": kf((0.0, [0, 0, 0]), (0.9, [-165, 0, 12]), (1.0, [25, 0, 0]), (1.1, [0, 0, 0]))},
    "armR": {"rotation": kf((0.0, [0, 0, 0]), (0.9, [-165, 0, -12]), (1.0, [25, 0, 0]), (1.1, [0, 0, 0]))},
    "jaw": {"rotation": kf((0.0, [0, 0, 0]), (0.9, [45, 0, 0]), (1.0, [5, 0, 0]), (1.1, [0, 0, 0]))},
    "head": {"rotation": kf((0.0, [0, 0, 0]), (0.9, [-22, 0, 0]), (1.0, [18, 0, 0]), (1.1, [0, 0, 0]))},
}}
A["animation.ion.ambient"] = {"loop": True, "animation_length": 8.0, "bones": {
    "orbit": {"rotation": kf((0.0, [0, 0, 0]), (8.0, [0, 360, 0]))},
    "ragsL": {"rotation": kf((0.0, [4, 0, 2]), (2.0, [-6, 0, -3]), (4.0, [4, 0, 2]), (6.0, [-6, 0, -3]), (8.0, [4, 0, 2]))},
    "ragsR": {"rotation": kf((0.0, [-5, 0, -2]), (2.0, [6, 0, 3]), (4.0, [-5, 0, -2]), (6.0, [6, 0, 3]), (8.0, [-5, 0, -2]))},
    "ragsB": {"rotation": kf((0.0, [6, 0, 0]), (3.0, [-8, 0, 2]), (6.0, [6, 0, -2]), (8.0, [6, 0, 0]))},
}}
json.dump({"format_version": "1.8.0", "animations": A}, open(os.path.join(ANIM, "ion.animation.json"), "w"), indent=1)

# ---------- текстуры ----------
PALE = (176, 168, 150)
WOOD = (44, 35, 30)
WRAP = (142, 136, 124)
STAIN = (84, 30, 26)

def noise(tile, base, var, vstreak=0):
    p = tile.load()
    for yy in range(tile.height):
        for xx in range(tile.width):
            v = random.randint(-var, var)
            if vstreak and (xx // vstreak) % 2 == 0: v -= 7
            p[xx, yy] = tuple(max(0, min(255, b + v)) for b in base) + (255,)

def cracks(tile, glow, n, col, glowcol=None):
    d = ImageDraw.Draw(tile); g = ImageDraw.Draw(glow)
    for _ in range(n):
        cx, cy = random.randint(0, tile.width - 1), random.randint(0, tile.height - 1)
        for _ in range(random.randint(5, 16)):
            nx = cx + random.choice((-1, 0, 0, 1)); ny = cy + random.choice((0, 1, 1))
            d.line((cx, cy, nx, ny), fill=col)
            if glowcol: g.line((cx, cy, nx, ny), fill=glowcol)
            cx, cy = nx, ny

def stains(tile, n):
    d = ImageDraw.Draw(tile)
    for _ in range(n):
        cx, cy = random.randint(0, tile.width), random.randint(0, tile.height)
        r = random.randint(2, max(3, tile.width // 6))
        d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=STAIN + (255,))
        d.line((cx, cy, cx, min(tile.height, cy + random.randint(3, 14))), fill=STAIN + (255,))

def mask_face(tile, glow, pw, ph, eye_col, enraged):
    """Бледная маска с чёрными глазницами, светящимися точками и растянутым чёрным ртом."""
    d = ImageDraw.Draw(tile); g = ImageDraw.Draw(glow)
    d.rectangle((0, 0, pw, ph), fill=PALE + (255,))
    noise_over = tile.load()
    for yy in range(ph):
        for xx in range(pw):
            r, gg, b, a = noise_over[xx, yy]
            v = random.randint(-6, 6)
            noise_over[xx, yy] = (r + v, gg + v, b + v, 255)
    ex1, ex2, ey = int(pw * 0.30), int(pw * 0.70), int(ph * 0.34)
    rx, ry = max(2, int(pw * 0.14)), max(3, int(ph * 0.12))
    for ex in (ex1, ex2):
        d.ellipse((ex - rx, ey - ry, ex + rx, ey + ry), fill=(6, 5, 5, 255))
        d.line((ex, ey + ry, ex + random.randint(-2, 2), min(ph - 1, ey + ry + int(ph * 0.22))), fill=(20, 16, 14, 255))
        g.ellipse((ex - 1, ey + ry // 3 - 1, ex + 1, ey + ry // 3 + 1), fill=eye_col + (255,))
    mx0, mx1 = int(pw * 0.26), int(pw * 0.74)
    my0, my1 = int(ph * 0.62), int(ph * 0.90)
    d.ellipse((mx0, my0, mx1, my1), fill=(4, 3, 3, 255))
    for i in range(mx0 + 2, mx1 - 1, 3):
        d.line((i, my0 + 1, i, my0 + 3), fill=PALE + (255,))
        d.line((i + 1, my1 - 3, i + 1, my1 - 1), fill=PALE + (255,))
    cracks(tile, glow, 4, (60, 52, 44, 255), (255, 70, 40, 255) if enraged else None)

def small_faces(tile, glow, enraged):
    """Много маленьких лиц, вдавленных в дерево торса."""
    d = ImageDraw.Draw(tile); g = ImageDraw.Draw(glow)
    spots = []
    for _ in range(90):
        w, h = random.randint(8, 12), random.randint(11, 16)
        x0, y0 = random.randint(1, tile.width - w - 1), random.randint(1, tile.height - h - 1)
        if any(abs(x0 - sx) < 11 and abs(y0 - sy) < 14 for sx, sy in spots): continue
        spots.append((x0, y0))
        shade = random.randint(-14, 8)
        d.ellipse((x0, y0, x0 + w, y0 + h), fill=(PALE[0] + shade, PALE[1] + shade, PALE[2] + shade, 255), outline=(30, 24, 20, 255))
        for ex in (x0 + w // 4, x0 + (w * 3) // 4):
            d.rectangle((ex - 1, y0 + h // 3, ex + 1, y0 + h // 3 + 2), fill=(5, 4, 4, 255))
            if random.random() < 0.6:
                g.point((ex, y0 + h // 3 + 2), fill=((255, 60, 40, 255) if enraged else (210, 210, 200, 255)))
        mw = random.randint(2, 4)
        d.rectangle((x0 + w // 2 - mw, y0 + (h * 2) // 3, x0 + w // 2 + mw, y0 + (h * 2) // 3 + random.randint(1, 3)), fill=(5, 4, 4, 255))

def paint(role, cube, face, pw, ph, enraged):
    tile = Image.new("RGBA", (pw, ph), (0, 0, 0, 0))
    glow = Image.new("RGBA", (pw, ph), (0, 0, 0, 0))
    eye = (255, 40, 30) if enraged else (235, 235, 225)
    if role == "wood" or role == "torso":
        noise(tile, WOOD, 6, vstreak=3)
        cracks(tile, glow, max(3, pw * ph // 400), (10, 8, 7, 255), (255, 70, 30, 255) if enraged else None)
        if role == "torso" and face == "north":
            small_faces(tile, glow, enraged)
        elif role == "torso" and face == "south":
            stains(tile, 5)
    elif role == "wrap":
        noise(tile, WRAP, 7)
        d = ImageDraw.Draw(tile)
        for yy in range(0, ph, 4):
            d.line((0, yy, pw, yy), fill=(104, 98, 88, 255))
        stains(tile, 4)
    elif role == "bone":
        noise(tile, (156, 148, 130), 6)
        cracks(tile, glow, 3, (50, 44, 38, 255))
    elif role == "blade":
        noise(tile, (86, 88, 94), 9, vstreak=2)
        d = ImageDraw.Draw(tile); g = ImageDraw.Draw(glow)
        d.line((pw // 2, 0, pw // 2, ph), fill=(150, 152, 160, 255))
        stains(tile, 6)
        if enraged:
            g.line((pw // 2, 0, pw // 2, ph), fill=(255, 60, 30, 255))
    elif role == "rag":
        noise(tile, (128, 122, 110), 8)
        stains(tile, 3)
        d = ImageDraw.Draw(tile)
        for xx in range(0, pw, 5):
            d.polygon([(xx, ph), (xx + 2, ph - random.randint(4, 12)), (xx + 4, ph)], fill=(0, 0, 0, 0))
    elif role == "head":
        if face == "north":
            mask_face(tile, glow, pw, ph, eye, enraged)
        elif face == "south":
            noise(tile, WOOD, 6, vstreak=3); cracks(tile, glow, 8, (10, 8, 7, 255))
        else:
            noise(tile, (96, 88, 76), 7); cracks(tile, glow, 5, (24, 20, 16, 255), (255, 70, 30, 255) if enraged else None)
    elif role == "jaw":
        if face == "up":
            d = ImageDraw.Draw(tile); d.rectangle((0, 0, pw, ph), fill=(3, 2, 2, 255))
            for xx in range(2, pw - 2, 5):                      # занозы-зубы
                d.polygon([(xx, 0), (xx + 3, 0), (xx + 1, random.randint(5, 9))], fill=PALE + (255,))
                d.polygon([(xx, ph), (xx + 3, ph), (xx + 1, ph - random.randint(5, 9))], fill=PALE + (255,))
        else:
            noise(tile, PALE if face == "north" else (96, 88, 76), 6)
            d = ImageDraw.Draw(tile)
            if face == "north":                                 # зашитый рот
                my = ph // 3
                d.line((2, my, pw - 3, my), fill=(10, 8, 7, 255), width=1)
                for xx in range(4, pw - 3, 4):
                    d.line((xx, my - 3, xx + 1, my + 3), fill=(10, 8, 7, 255))
                    d.line((xx, my + 2, xx, my + ph // 2), fill=(70, 20, 18, 255))
            cracks(tile, glow, 3, (50, 44, 38, 255))
    elif role == "plate":
        big = face in ("north", "south", "east", "west") and (pw >= 16 and ph >= 24)
        if big:
            mask_face(tile, glow, pw, ph, eye, enraged)
        else:
            noise(tile, WOOD, 6); cracks(tile, glow, 2, (10, 8, 7, 255))
    else:
        noise(tile, WOOD, 6)
    return tile, glow

def build(enraged, name):
    random.seed(77 if not enraged else 78)
    atlas = Image.new("RGBA", (SZ, SZ), (0, 0, 0, 0))
    gatlas = Image.new("RGBA", (SZ, SZ), (0, 0, 0, 0))
    for ci, c in enumerate(CUBES):
        for f in FACES:
            u, v, pw, ph = placed[(ci, f)]
            tile, glow = paint(c[4], c[1], f, pw, ph, enraged)
            atlas.paste(tile, (u, v)); gatlas.paste(glow, (u, v))
    if enraged:
        # общий тёмно-красный налёт на всё, кроме светящихся трещин
        px = atlas.load()
        for yy in range(SZ):
            for xx in range(SZ):
                r, g, b, a = px[xx, yy]
                if a:
                    px[xx, yy] = (min(255, r + 10), max(0, g - 6), max(0, b - 6), a)
    atlas.save(os.path.join(TEX, name + ".png"))
    gatlas.save(os.path.join(TEX, name + "_glowmask.png"))

build(False, "ion")
build(True, "ion_enraged")
print("ok: geo, animations, textures")

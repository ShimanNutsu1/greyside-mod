"""Текстура Серого фантома (64x64) под client/GreyPhantomModel. Запуск из корня проекта: python3 tools/gen_grey_phantom.py
Прозрачные пиксели в крыльях дают рваные края (рендер с отсечением по альфе)."""
import os, random
from PIL import Image

OUT = os.path.join(os.path.dirname(__file__), "..", "src", "main", "resources", "assets", "greyside", "textures", "entity", "grey_phantom.png")
random.seed(23)
img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
px = img.load()

def fill(x0, y0, x1, y1, base, var=3, hole=0.0):
    for y in range(y0, y1):
        for x in range(x0, x1):
            if hole and random.random() < hole:
                px[x, y] = (0, 0, 0, 0)
                continue
            v = random.randint(-var, var)
            px[x, y] = tuple(max(0, min(255, b + v)) for b in base) + (255,)

def put(x, y, c):
    px[x, y] = c + (255,)

body = (22, 22, 27)
skin = (58, 58, 65)
membrane = (30, 30, 37)
vein = (62, 60, 70)

# тело (0..34 x 0..16): тёмное, на спине светлее полосы рёбер
fill(0, 0, 34, 16, body, var=2)
for x in range(12, 28, 3):
    for y in range(0, 12):
        put(x, y, (34, 34, 40))

# голова (0..22 x 16..27): гладкая, лица нет; только узкая тёмная щель там, где был бы рот
fill(0, 16, 22, 27, skin, var=2)
fill(5, 16, 11, 21, (40, 40, 46), var=2)          # верх головы
for y in range(25, 27):
    put(8, y, (24, 24, 29))
# гребень (22..34 x 16..23)
fill(22, 16, 34, 23, (80, 78, 86), var=3)

# хвост (34..58 x 0..24)
fill(34, 0, 58, 12, body, var=2)
fill(34, 12, 58, 24, (18, 18, 22), var=2)

# крыло: основа (0..38 x 28..39), лоскуты (0..30 x 40..44, 0..24 x 44..48, 0..18 x 48..52)
fill(0, 28, 38, 39, membrane, var=3, hole=0.10)
fill(0, 40, 30, 44, membrane, var=3, hole=0.22)
fill(0, 44, 24, 48, membrane, var=3, hole=0.22)
fill(0, 48, 18, 52, membrane, var=3, hole=0.22)
# жилки вдоль крыла
for y in range(29, 38):
    for x in range(1, 38):
        if (x + 2 * y) % 5 == 0 and px[x, y][3]:
            put(x, y, vein)
for (x0, x1, y0, y1) in ((0, 30, 40, 44), (0, 24, 44, 48), (0, 18, 48, 52)):
    for y in range(y0, y1):
        for x in range(x0, x1):
            if (x + y) % 6 == 0 and px[x, y][3]:
                put(x, y, vein)

img.save(OUT)
print("ok", OUT)

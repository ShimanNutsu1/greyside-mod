package com.example.ghostmarket.session;

import com.example.ghostmarket.config.GhostMarketConfig;
import com.example.ghostmarket.currency.CurrencyAccess;
import com.example.ghostmarket.dimension.MarketLayout;
import com.example.ghostmarket.dimension.MarketPlatformBuilder;
import com.example.ghostmarket.dimension.ModDimensions;
import com.example.ghostmarket.key.KeyRules;
import com.example.ghostmarket.network.GhostMarketNetwork;
import com.example.ghostmarket.network.MarketTimerPacket;
import com.example.ghostmarket.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.players.PlayerList;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;
import org.jetbrains.annotations.Nullable;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Вся логика сеанса на рынке: вход, таймер, предупреждение, выход (арка, время, перезаход), штраф.
 * Всё выполняется на сервере в основном потоке.
 */
public final class MarketSessions {

    public enum ExitReason {
        ARCH,
        TIMEOUT,
        LOGIN
    }

    private record Target(ServerLevel level, Vec3 pos, float yaw, float pitch) {
    }

    /** Игроки, вошедшие в арку: телепортируем в конце тика, а не прямо в середине движения игрока. */
    private static final Set<UUID> ARCH_REQUESTS = new LinkedHashSet<>();
    /** Игроки, зашедшие в игру: возвращаем со следующего тика, когда соединение уже полностью готово. */
    private static final Set<UUID> LOGIN_RETURNS = new LinkedHashSet<>();

    public static void requestArchExit(UUID player) {
        ARCH_REQUESTS.add(player);
    }

    public static void queueLoginReturn(UUID player) {
        LOGIN_RETURNS.add(player);
    }

    public static void clearTransient() {
        ARCH_REQUESTS.clear();
        LOGIN_RETURNS.clear();
    }

    // ------------------------------------------------------------------ вход

    /**
     * Запоминает точку возврата и переносит игрока на рынок.
     *
     * @return false, если измерения рынка нет (ничего не изменено)
     */
    public static boolean enter(ServerPlayer player) {
        MinecraftServer server = player.server;
        ServerLevel market = server.getLevel(ModDimensions.GHOST_MARKET);
        if (market == null) {
            return false;
        }

        MarketPlatformBuilder.ensureBuilt(market);
        MarketLayout layout = MarketLayout.fromConfig();

        ServerLevel overworld = server.overworld();
        long dayTime = overworld.getDayTime();
        long gameTime = overworld.getGameTime();
        long duration = computeDuration(dayTime);

        MarketSession session = new MarketSession(
                player.level().dimension(),
                player.getX(), player.getY(), player.getZ(),
                player.getYRot(), player.getXRot(),
                dayTime + duration, gameTime + duration);
        MarketSessionData.get(server).putSession(player.getUUID(), session);

        Vec3 spawn = layout.spawnPos();
        player.teleportTo(market, spawn.x, spawn.y, spawn.z, layout.spawnYaw(), 0.0F);
        player.fallDistance = 0.0F;
        player.setDeltaMovement(Vec3.ZERO);

        sendTimer(player, duration, true);
        player.displayClientMessage(Component.translatable("message.ghostmarket.market_enter")
                .withStyle(ChatFormatting.DARK_PURPLE, ChatFormatting.ITALIC), false);
        return true;
    }

    /** До рассвета главного мира, но не меньше минимума и не больше максимума из конфига. */
    static long computeDuration(long overworldDayTime) {
        long toDawn = Math.floorMod(GhostMarketConfig.SESSION_DAWN_TICK.get() - overworldDayTime, KeyRules.TICKS_PER_DAY);
        long min = GhostMarketConfig.SESSION_MIN_TICKS.get();
        long max = Math.max(min, GhostMarketConfig.SESSION_MAX_TICKS.get());
        return Mth.clamp(toDawn, min, max);
    }

    // ----------------------------------------------------------------- выход

    /**
     * Возвращает игрока из рынка на точку возврата и закрывает сеанс.
     *
     * @param penalty применить штраф за опоздание
     */
    public static void exit(ServerPlayer player, ExitReason reason, boolean penalty) {
        MinecraftServer server = player.server;
        MarketSessionData data = MarketSessionData.get(server);
        MarketSession session = data.removeSession(player.getUUID());

        Target target = resolveTarget(server, session, player);
        Vec3 pos = target.pos();
        player.teleportTo(target.level(), pos.x, pos.y, pos.z, target.yaw(), target.pitch());
        player.fallDistance = 0.0F;
        player.setDeltaMovement(Vec3.ZERO);

        sendTimer(player, 0L, false);

        if (penalty) {
            player.displayClientMessage(Component.translatable("message.ghostmarket.market_exit_late")
                    .withStyle(ChatFormatting.DARK_RED), false);
            applyPenalty(player);
        } else if (reason == ExitReason.LOGIN) {
            player.displayClientMessage(Component.translatable("message.ghostmarket.market_exit_login")
                    .withStyle(ChatFormatting.DARK_PURPLE, ChatFormatting.ITALIC), false);
        } else {
            player.displayClientMessage(Component.translatable("message.ghostmarket.market_exit_arch")
                    .withStyle(ChatFormatting.DARK_PURPLE, ChatFormatting.ITALIC), false);
        }
    }

    private static void applyPenalty(ServerPlayer player) {
        int minutes = GhostMarketConfig.PENALTY_WEAKNESS_MINUTES.get();
        if (minutes > 0) {
            player.addEffect(new MobEffectInstance(MobEffects.WEAKNESS,
                    minutes * (int) KeyRules.TICKS_PER_MINUTE,
                    GhostMarketConfig.PENALTY_WEAKNESS_AMPLIFIER.get()));
        }

        int percent = GhostMarketConfig.PENALTY_CURRENCY_PERCENT.get();
        if (percent > 0) {
            CurrencyAccess currency = CurrencyAccess.get();
            long balance = currency.getBalance(player);
            long loss = (long) Math.ceil(balance * percent / 100.0D);
            long taken = currency.withdraw(player, loss);
            if (taken > 0L) {
                player.displayClientMessage(Component.translatable("message.ghostmarket.penalty_currency", taken)
                        .withStyle(ChatFormatting.DARK_RED), false);
            }
        }
    }

    // --------------------------------------------------- точка возврата

    private static Target resolveTarget(MinecraftServer server, @Nullable MarketSession session, ServerPlayer player) {
        if (session != null) {
            ServerLevel level = server.getLevel(session.returnDimension());
            if (level != null) {
                Vec3 safe = findSafe(level, new Vec3(session.x(), session.y(), session.z()), player);
                if (safe != null) {
                    return new Target(level, safe, session.yaw(), session.pitch());
                }
            }
        }
        return fallbackTarget(server);
    }

    /** Ищет свободное для игрока место в точке и выше неё. Загружает чанк, чтобы проверка была честной. */
    @Nullable
    private static Vec3 findSafe(ServerLevel level, Vec3 pos, ServerPlayer player) {
        BlockPos base = BlockPos.containing(pos);
        if (level.isOutsideBuildHeight(base)) {
            return null;
        }
        level.getChunk(base);

        EntityDimensions dimensions = player.getDimensions(Pose.STANDING);
        int search = GhostMarketConfig.RETURN_SEARCH_HEIGHT.get();
        for (int dy = 0; dy <= search; dy++) {
            Vec3 candidate = pos.add(0.0D, dy, 0.0D);
            if (candidate.y + dimensions.height > level.getMaxBuildHeight()) {
                break;
            }
            AABB box = dimensions.makeBoundingBox(candidate);
            if (level.noCollision(box)) {
                return candidate;
            }
        }
        return null;
    }

    private static Target fallbackTarget(MinecraftServer server) {
        ServerLevel overworld = server.overworld();
        BlockPos spawn = overworld.getSharedSpawnPos();
        overworld.getChunk(spawn);
        BlockPos top = overworld.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, spawn);
        return new Target(overworld, Vec3.atBottomCenterOf(top), 0.0F, 0.0F);
    }

    // ------------------------------------------------------- тик сервера

    public static void tick(MinecraftServer server) {
        MarketSessionData data = MarketSessionData.get(server);
        PlayerList players = server.getPlayerList();
        ServerLevel overworld = server.overworld();
        long dayTime = overworld.getDayTime();
        long gameTime = overworld.getGameTime();

        processLoginReturns(data, players, dayTime, gameTime);
        processArchRequests(data, players);
        adoptStrayPlayers(server, data, dayTime, gameTime);
        processSessions(server, data, players, dayTime, gameTime);
    }

    private static void processLoginReturns(MarketSessionData data, PlayerList players, long dayTime, long gameTime) {
        if (LOGIN_RETURNS.isEmpty()) {
            return;
        }
        for (UUID id : List.copyOf(LOGIN_RETURNS)) {
            LOGIN_RETURNS.remove(id);
            ServerPlayer player = players.getPlayer(id);
            if (player == null || !ModDimensions.isMarket(player.level())) {
                continue;
            }
            // Пока игрока не было, рассвет мог наступить: тогда это опоздание.
            MarketSession session = data.getSession(id);
            boolean late = session != null && session.remaining(dayTime, gameTime) <= 0L;
            exit(player, ExitReason.LOGIN, late);
        }
    }

    private static void processArchRequests(MarketSessionData data, PlayerList players) {
        if (ARCH_REQUESTS.isEmpty()) {
            return;
        }
        for (UUID id : List.copyOf(ARCH_REQUESTS)) {
            ARCH_REQUESTS.remove(id);
            ServerPlayer player = players.getPlayer(id);
            if (player == null || !player.isAlive() || !ModDimensions.isMarket(player.level())) {
                continue;
            }
            if (data.getSession(id) == null) {
                continue;
            }
            exit(player, ExitReason.ARCH, false);
        }
    }

    /**
     * Игрок оказался на рынке не через ключ (команда /tp, /execute и т.п.): рынок всё равно закроется по таймеру,
     * вернуть его будет на точку мирового спавна.
     */
    private static void adoptStrayPlayers(MinecraftServer server, MarketSessionData data, long dayTime, long gameTime) {
        ServerLevel market = server.getLevel(ModDimensions.GHOST_MARKET);
        if (market == null) {
            return;
        }
        for (ServerPlayer player : List.copyOf(market.players())) {
            if (!player.isAlive() || data.getSession(player.getUUID()) != null || LOGIN_RETURNS.contains(player.getUUID())) {
                continue;
            }
            Target fallback = fallbackTarget(server);
            long duration = computeDuration(dayTime);
            Vec3 pos = fallback.pos();
            data.putSession(player.getUUID(), new MarketSession(
                    fallback.level().dimension(), pos.x, pos.y, pos.z, fallback.yaw(), fallback.pitch(),
                    dayTime + duration, gameTime + duration));
            sendTimer(player, duration, true);
        }
    }

    private static void processSessions(MinecraftServer server, MarketSessionData data, PlayerList players,
                                        long dayTime, long gameTime) {
        int warningTicks = GhostMarketConfig.WARNING_TICKS.get();
        int syncInterval = GhostMarketConfig.TIMER_SYNC_INTERVAL_TICKS.get();
        boolean syncNow = server.getTickCount() % syncInterval == 0;

        for (Map.Entry<UUID, MarketSession> entry : data.snapshot().entrySet()) {
            ServerPlayer player = players.getPlayer(entry.getKey());
            if (player == null || !player.isAlive() || LOGIN_RETURNS.contains(entry.getKey())) {
                continue;
            }
            MarketSession session = entry.getValue();

            if (!ModDimensions.isMarket(player.level())) {
                // Игрока убрали с рынка снаружи (команда, плагин): сеанс больше не нужен.
                data.removeSession(entry.getKey());
                sendTimer(player, 0L, false);
                continue;
            }

            long remaining = session.remaining(dayTime, gameTime);
            if (remaining <= 0L) {
                exit(player, ExitReason.TIMEOUT, true);
                continue;
            }

            if (!session.isWarned() && remaining <= warningTicks) {
                session.setWarned(true);
                data.setDirty();
                warn(player);
                sendTimer(player, remaining, true);
            } else if (syncNow) {
                sendTimer(player, remaining, true);
            }
        }
    }

    private static void warn(ServerPlayer player) {
        player.displayClientMessage(Component.translatable("message.ghostmarket.market_warning")
                .withStyle(ChatFormatting.DARK_RED, ChatFormatting.ITALIC), false);
        player.playNotifySound(ModSounds.MARKET_WHISPER.get(), SoundSource.AMBIENT,
                GhostMarketConfig.WARNING_SOUND_VOLUME.get().floatValue(),
                GhostMarketConfig.WARNING_SOUND_PITCH.get().floatValue());
    }

    public static void sendTimer(ServerPlayer player, long remainingTicks, boolean active) {
        int ticks = (int) Mth.clamp(remainingTicks, 0L, Integer.MAX_VALUE);
        GhostMarketNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new MarketTimerPacket(active, ticks));
    }

    // ----------------------------------------------------- ключ после смерти

    /** Отдаёт ключи, спасённые от смерти на рынке. Если инвентарь полон, ключ падает под ноги. */
    public static void restoreKeys(ServerPlayer player) {
        MarketSessionData data = MarketSessionData.get(player.server);
        if (!data.hasPendingKeys(player.getUUID())) {
            return;
        }
        for (ItemStack key : data.takePendingKeys(player.getUUID())) {
            if (!player.getInventory().add(key)) {
                player.drop(key, false);
            }
        }
        player.displayClientMessage(Component.translatable("message.ghostmarket.key_returned")
                .withStyle(ChatFormatting.DARK_PURPLE, ChatFormatting.ITALIC), false);
    }

    private MarketSessions() {
    }
}

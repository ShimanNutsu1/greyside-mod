package com.example.ghostmarket.session;

import com.example.ghostmarket.GhostMarket;
import com.example.ghostmarket.config.GhostMarketConfig;
import com.example.ghostmarket.dimension.ModDimensions;
import com.example.ghostmarket.registry.ModItems;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Iterator;

@Mod.EventBusSubscriber(modid = GhostMarket.MODID)
public final class MarketSessionEvents {

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !GhostMarketConfig.SPEC.isLoaded()) {
            return;
        }
        MarketSessions.tick(event.getServer());
    }

    /** Игрок зашёл в игру прямо на рынке: вернём его на следующем тике. */
    @SubscribeEvent
    public static void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || player instanceof FakePlayer) {
            return;
        }
        if (!GhostMarketConfig.SPEC.isLoaded()) {
            return;
        }
        if (ModDimensions.isMarket(player.level())) {
            MarketSessions.queueLoginReturn(player.getUUID());
        }
        // Если игрок вышел, пока был мёртв, ключ ждёт его с прошлой смерти.
        if (player.isAlive()) {
            MarketSessions.restoreKeys(player);
        }
    }

    /** Смерть на рынке закрывает сеанс: возрождение идёт по обычным правилам, точка возврата не нужна. */
    @SubscribeEvent(priority = EventPriority.MONITOR)
    public static void onPlayerDeath(LivingDeathEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || player instanceof FakePlayer) {
            return;
        }
        if (!GhostMarketConfig.SPEC.isLoaded() || !ModDimensions.isMarket(player.level())) {
            return;
        }
        MarketSessionData.get(player.server).removeSession(player.getUUID());
    }

    /**
     * Ключ не выпадает при смерти на рынке, даже если keepInventory выключен.
     * Мы забираем его из списка выпавшего до того, как предметы появятся в мире.
     * При keepInventory = true предметы и так остаются у игрока, и здесь ничего не происходит.
     */
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onPlayerDrops(LivingDropsEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || player instanceof FakePlayer) {
            return;
        }
        if (!GhostMarketConfig.SPEC.isLoaded() || !GhostMarketConfig.KEEP_KEY_ON_MARKET_DEATH.get()) {
            return;
        }
        if (!ModDimensions.isMarket(player.level())) {
            return;
        }

        MarketSessionData data = MarketSessionData.get(player.server);
        Iterator<ItemEntity> drops = event.getDrops().iterator();
        while (drops.hasNext()) {
            ItemEntity drop = drops.next();
            if (drop.getItem().is(ModItems.STRANGE_KEY.get())) {
                data.addPendingKey(player.getUUID(), drop.getItem().copy());
                drops.remove();
            }
        }
    }

    @SubscribeEvent
    public static void onPlayerRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || player instanceof FakePlayer) {
            return;
        }
        if (!GhostMarketConfig.SPEC.isLoaded()) {
            return;
        }
        MarketSessions.restoreKeys(player);
        MarketSessions.sendTimer(player, 0L, false);
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        MarketSessions.clearTransient();
    }

    private MarketSessionEvents() {
    }
}
